import { Component } from '@angular/core';
import { ModalController, Events, NavController, App} from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ConnectService } from '../../../providers/connect-service';

@Component({
  selector: 'page-shop-assistant-qrcode',
  templateUrl: 'shop-assistant-qrcode.html',
  providers: []
})
export class ShopAssistantQrcodePage{
  
  public storeUserName: string = '';
  public storeName: string = '';
  public storeUserCompany: string = '';

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public events: Events,
    public storage: Storage,
    public appCtrl: App,
    public connectService: ConnectService
  ){

  }
  ionViewDidLoad(){
    let loginStatus: any = this.connectService.getData('loginStatus');
    this.storeUserName = loginStatus.storeUserName;
    this.storeName = loginStatus.storeName;
    this.storeUserCompany = loginStatus.storeUserCompany;
    console.log('into qrPage')
  }
  ionViewDidLeave(){
    console.log("pop qrPage");
  }
 
}
