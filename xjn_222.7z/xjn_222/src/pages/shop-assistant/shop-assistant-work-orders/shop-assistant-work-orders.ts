import { Component } from '@angular/core';
import { NavController, NavParams, Events, LoadingController } from 'ionic-angular';
import { TestdataService } from '../../../providers/testdata-service';
import { ConnectService } from '../../../providers/connect-service';
import { ToolService } from '../../../providers/tool-service';

@Component({
  selector: 'page-shop-assistant-work-orders',
  templateUrl: 'shop-assistant-work-orders.html'
})
export class ShopAssistantWorkOrdersPage{
  
  public orderStatus:string = 'unChecked';  //判断segment在已处理or未处理，预设值影响默认展示页

  public listData: any = this.testdataService.workOrdersList.data;
  public orderDateExist: string[] = [];
  public displayOrders: any = [];
  
  constructor(
    public navCtrl: NavController,
    public navParam: NavParams,
    public testdataService: TestdataService,
    public events: Events,
    public connectService: ConnectService,
    public toolService: ToolService,
    public loadingCtrl: LoadingController
  ) {
    
  }
  
  ionViewDidLoad(){
    console.log(this.listData)
    this.refreshDisplayOrders(this.listData)
  }
  ionViewWillEnter(){
    this.connectService.commonData.orderDateExist = [];
    this.connectService.commonData.displayOrders = [];
    this.refreshDisplayOrders(this.listData)
  }
  
  //点击切换segment触发方法
  public selectSegment(status:string): void{
    console.log(`当前标签为：${status}`)
    this.orderStatus = status;

    let loading = this.loadingCtrl.create({
      content: '加载中...'
    });
    loading.present();

    setTimeout(() => {
      this.connectService.commonData.orderDateExist = [];
      this.connectService.commonData.displayOrders = [];
      this.refreshDisplayOrders(this.listData)
      loading.dismiss()
    }, 2000);
     
  }
  
  //上拉加载触发方法
  public doInfinite(infiniteScroll){
    if(this.listData.length < 10){
      infiniteScroll.enable(false);
      return
    }
    setTimeout(() => {
      this.refreshDisplayOrders(this.listData)
      infiniteScroll.complete();
    }, 2000);
  }

  //下拉刷新触发方法
  public doRefresh(refresher){
    setTimeout(() => {
      this.connectService.commonData.orderDateExist = [];
      this.connectService.commonData.displayOrders = [];
      this.refreshDisplayOrders(this.listData)
      refresher.complete();
    }, 2000);
  }

  //刷新工单数据
  public refreshDisplayOrders(listData){
      this.toolService.getOrdersByDate(listData)
      this.events.subscribe('getOrdersByDateComplete',(orderDateExist, displayOrders) => {
        this.orderDateExist = orderDateExist;
        this.displayOrders = displayOrders;
      })
      console.warn('工单数据刷新完毕')
      console.log(this.displayOrders)
  }

}
