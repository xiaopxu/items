import { Component, Input } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ConfigService } from '../../../config-servise';
import { HttpService } from '../../../providers/http-service';
import { ToolService } from '../../../providers/tool-service';
import { ConnectService } from '../../../providers/connect-service';

/*
  Generated class for the ValidationCode page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-validation-code',
  templateUrl: 'validation-code.html'
})
export class ValidationCodePage {
  @Input() phoneNumber: string = '';
  //用setter/getter，将接收到的businessType做二次处理
  private _businessType: string;
  @Input()
  private set businessType(businessType: string){
    if(businessType == 'register'){
      this._businessType = '1';
    }else if(businessType == 'findPwd'){
      this._businessType = '2';
    }else if(businessType == 'checkContract'){
     this._businessType = '3';
    }else if(businessType == 'checkFls'){
      this._businessType = '4';
    }
  }
  private get businessType(){
    return this._businessType;
  }
  
  private vCodeStep: string = 'notSend';  //初始为未发送
  private limitTime: number = 60;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public config: ConfigService,
    public http: HttpService,
    public toolService: ToolService,
    public connectService: ConnectService
  ) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad ValidationCodePage');
  }
  /**
   * @Title: getValidationCode
   * @Description: 发送验证码请求
   * @param {string} phoneNumber
   * @returns void
   * @memberOf FindPwdPage
   * 
   * @auther: xjn
   * @date: 2017年3月14日
   */
  public getValidationCode(phoneNumber: string): void{
    //参数校验
    if(!this.toolService.checkPhone(phoneNumber, '手机号')){ return }
    //设置查询验证码进度状态，设置为发送中
    if(this.vCodeStep == 'notSend' || this.vCodeStep == 'reSend'){
      this.vCodeStep = 'sending'
    }
    //启动定时器
    this.vCodeTimer();
    //设置请求参数
    let param: any = {
        url: `${this.config.baseHost}/new/partnerApp/common/sendMessage/`,
        params: {
            smsPhone: phoneNumber || '',
            smsType: '',
            smsBusinessType: this.businessType
        }
    }
    //发送请求
    if(!this.config.devMode){
      this.http.post(param)
      .then(data=>{
          console.log('验证码发送成功')
      })
      .catch(data => {
          console.log(data);
          if(typeof(data)=="undefined"|| data === null ){
              this.connectService.getData('loading').dismiss();
              return;
          }
          this.connectService.getData('loading').dismiss();
          this.toolService.showAlert(data)
      })
    }
    
  }
  //验证码倒计时定时器
  private vCodeTimer(){
    this.limitTime = 60;
    let vCodeTimer = setInterval(() => {
      if(this.limitTime <= 1){
        clearInterval(vCodeTimer)
        this.vCodeStep = 'reSend';  //设置状态为重新发送
      }
      this.limitTime--
    }, 1000);
  }

}
