import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ToolService } from '../../../providers/tool-service';

/*
  Generated class for the Register page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-register',
  templateUrl: 'register.html'
})
export class RegisterPage {
  
  public userName: string = '';
  public phoneNumber: string = '';
  public validationCode: string = '';
  public userPwd: string = '';
  public checkPwd: string = '';
  public idCard: string = '';
  public idName: string = '';

  constructor(public navCtrl: NavController, public navParams: NavParams, public toolService: ToolService) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad RegisterPage');
  }

  submit(){
    if(!this.toolService.checkUserName(this.userName, '用户名')){ return };  //用户名
    if(!this.toolService.checkPwd(this.userPwd, '密码')){ return };  //密码
    if(!this.toolService.checkCheckPwd(this.checkPwd, '确认密码')){ return };  //确认密码
    if(!this.toolService.checkIdName(this.idName, '姓名')){ return };  //姓名
    if(!this.toolService.checkIdCard(this.idCard, '身份证号码')){ return };  //身份证号码
    if(!this.toolService.checkPhone(this.phoneNumber, '手机号')){ return };  //手机号
    if(!this.toolService.checkValidationCode(this.validationCode, '验证码')){ return };  //验证码

    this.navCtrl.pop();
  }

}
