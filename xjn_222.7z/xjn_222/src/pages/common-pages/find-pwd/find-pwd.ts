import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HttpService } from '../../../providers/http-service';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';
import { ConnectService } from '../../../providers/connect-service';

/*
  Generated class for the FindPwd page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-find-pwd',
  templateUrl: 'find-pwd.html'
})
export class FindPwdPage {
  public userName:string = '';
  public phoneNumber:string = '';
  public validationCode:string = '';
  public newPwd:string = '';

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public http: HttpService, 
    public toolService: ToolService,
    public config: ConfigService,
    public connectService: ConnectService
  ) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad FindPwdPage');
  }

  public submit(): void{
    if(!this.toolService.checkUserName(this.userName, '账号')){ return };
    if(!this.toolService.checkPhone(this.phoneNumber, '手机号')){ return };
    if(!this.toolService.checkValidationCode(this.validationCode, '验证码')){ return };
    if(!this.toolService.checkPwd(this.newPwd, '密码')){ return };

    this.navCtrl.pop();
  }

}
