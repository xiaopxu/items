import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';

/*
  Generated class for the WorkOrderDetail page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-work-order-detail',
  templateUrl: 'work-order-detail.html'
})
export class WorkOrderDetailPage {
  public orderDetailData: any = [];
  public phoneNumber: string = '';
  public validationCode: string = '';
  public goodsNo: string = '';
  constructor(public navCtrl: NavController, public navParams: NavParams, public toolService: ToolService, public configService: ConfigService) {}

  ionViewDidLoad() {
    this.orderDetailData = this.navParams.data;
    console.warn('订单详情')
    console.log(this.orderDetailData)
  }

  public submit(){
    //字段验证
    if(!this.toolService.chenkGoosNo(this.goodsNo, '商品串号')){ return };
    if(!this.toolService.checkPhone(this.phoneNumber, '合约机号')){ return };
    if(!this.toolService.checkValidationCode(this.validationCode, '验证码')){ return };
    if(!this.configService.devMode){

    }else{
      this.navCtrl.pop();
    }
    
  }

}
