import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the OperatorManagerStatistic page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-operator-manager-statistic',
  templateUrl: 'operator-manager-statistic.html'
})
export class OperatorManagerStatisticPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad OperatorManagerStatisticPage');
  }

}
