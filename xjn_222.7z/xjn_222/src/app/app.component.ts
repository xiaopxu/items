import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar, Splashscreen } from 'ionic-native';

import { LoginPage } from '../pages/common-pages/login/login';
import { ConfigService } from '../config-servise';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  //指定根组件
  rootPage = LoginPage

  constructor(platform: Platform, configService: ConfigService) {
    if(configService.devMode){
      this.rootPage = configService.rootPage
    }
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      StatusBar.styleDefault();
      Splashscreen.hide();
    });
  }
}
