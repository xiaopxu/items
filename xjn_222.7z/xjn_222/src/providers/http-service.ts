import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { AlertController, LoadingController } from 'ionic-angular';
import { ToolService } from './tool-service';
import 'rxjs/add/operator/map';
import { ConfigService } from '../config-servise';
import { ConnectService } from './connect-service';

/**
 * @Description: http服务封装，统一处理返回结果
 * @export
 * @class HttpService
 * 
 * @auther: xjn
 * @date: 2017年3月6日
 */
@Injectable()
export class HttpService {

  constructor(
    public _http: Http,
    public alertCtrl: AlertController,
    public toolService: ToolService,
    public configService: ConfigService,
    public loadingCtrl: LoadingController,
    public connectService: ConnectService
  ){
    console.log('Hello HomeService Provider');
  }
  
  /**
   * @Title: post
   * @Description: post请求，统一处理异常情况
   * @param: {*} param 请求参数
   * @returns {*}
   * @memberOf: HttpService
   * 
   * @auther: xjn
   * @date: 2017年3月6日
   */
  public post(param: any): any{

    let loading = this.loadingCtrl.create({
      content: '加载中...'
    });
    this.connectService.saveData('loading',loading)
    loading.present();

    let headers: Headers = new Headers({
        'Content-Type': 'application/json'
    });
    let options: RequestOptions = new RequestOptions({headers: headers});
    let appVersion:string = '';
    let apiVersion:string = '';
    let data:Object = {
        appVersion: appVersion || '20161230',
        apiVersion: apiVersion || '1.0',
        sessionToken: param.sessionToken ||'650932d734cb824518faa3d8c850a5ff',
        accountId: param.accountId || '',
        accountSysRole: param.accountSysRole || '9999',
        optionsMethod: param.optionsMethod || '',
        body: JSON.stringify(param.params || {}),
    }
    return new Promise((resolve, reject) => {
      
      this._http.post(param.url, JSON.stringify(data), options)
        .map(res => res.json())
        .subscribe(res => {
          console.log(res)
          //统一处理请求结果
          if(typeof(res)=="undefined"|| res === null){
            reject('请求数据异常')
          }else{
            if(typeof(res.data)=="undefined"|| res.data === null){
              reject('请求数据异常')
            }else{
              if(res.code == 2000){  //请求成功
                resolve(res.data)
              }else if(res.code == 4000){  //请求失败
                reject(res.message)
              }else if(res.code == 4001){  //登陆超时
                // logOut()
              }
            }
          }
         
        }, err => reject('服务器错误！'))

    })

  }
}
