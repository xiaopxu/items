//框架自带
import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { Storage } from '@ionic/storage';

//第三方插件模块
import { QRCodeModule } from 'angular2-qrcode';

//App入口
import { MyApp } from './app.component';

//注册页面
import { LoginPage } from '../pages/common-pages/login/login';
import { FindPwdPage } from '../pages/common-pages/find-pwd/find-pwd';
import { RegisterPage } from '../pages/common-pages/register/register';
import { ChangePwdPage } from '../pages/common-pages/change-pwd/change-pwd';

//普通店员
import { ShopAssistantTabsPage } from '../pages/shop-assistant/shopassistant-tabs/shop-assistant-tabs';
import { ShopAssistantQrcodePage } from '../pages/shop-assistant/shop-assistant-qrcode/shop-assistant-qrcode';
import { ShopAssistantWorkOrdersPage } from '../pages/shop-assistant/shop-assistant-work-orders/shop-assistant-work-orders';
import { ShopAssisyantAchievementPage } from '../pages/shop-assistant/shop-assistant-achievement/shop-assistant-achievement';
import { ShopAssistantMePage } from '../pages/shop-assistant/shop-assistant-me/shop-assistant-me';
import { ShopAssistantMePersonalInfomationPage } from '../pages/shop-assistant/shop-assistant-me-personal-infomation/shop-assistant-me-personal-infomation';
//供应商管理员
import { SupplierManagerTabsPage } from '../pages/supplier-manager/supplier-manager-tabs/supplier-manager-tabs';
import { SupplierManagerManagementPage } from '../pages/supplier-manager/supplier-manager-management/supplier-manager-management';
import { SupplierManagerCheckOrderPage } from '../pages/supplier-manager/supplier-manager-check-order/supplier-manager-check-order';
import { SupplierManagerAchievementPage } from '../pages/supplier-manager/supplier-manager-achievement/supplier-manager-achievement';
import { SupplierManagerMePage } from '../pages/supplier-manager/supplier-manager-me/supplier-manager-me';
import { SupplierManagerMePersonalInfomationPage } from '../pages/supplier-manager/supplier-manager-me-personal-infomation/supplier-manager-me-personal-infomation';
//运营商管理员
import { OperatorManagerTabsPage } from '../pages/operator-manager/operator-manager-tabs/operator-manager-tabs';
import { OperatorManagerStatisticPage } from '../pages/operator-manager/operator-manager-statistic/operator-manager-statistic';
import { OperatorManagerMePage } from '../pages/operator-manager/operator-manager-me/operator-manager-me';

//公用组件
import { WorkOrdersListPage } from '../pages/common-pages/work-orders-list/work-orders-list';
import { WorkOrderDetailPage } from '../pages/common-pages/work-order-detail/work-order-detail';
import { ValidationCodePage } from '../pages/common-pages/validation-code/validation-code';
import { OrderListHeaderPage } from '../pages/common-pages/order-list-header/order-list-header';
import { OrderListContentPage } from '../pages/common-pages/order-list-content/order-list-content';
import { AchievementDetailPage } from '../pages/common-pages/achievement-detail/achievement-detail';
import { CheckOrderDetailPage } from '../pages/common-pages/check-order-detail/check-order-detail';
import { CheckClerkDetailPage } from '../pages/common-pages/check-clerk-detail/check-clerk-detail';
import { ClerkDetailPage } from '../pages/common-pages/clerk-detail/clerk-detail';
import { UploadDeliveryPhotoPage } from '../pages/common-pages/upload-delivery-photo/upload-delivery-photo';

//自定义服务
import { ConnectService } from '../providers/connect-service';
import { TestdataService } from '../providers/testdata-service';
import { ToolService } from '../providers/tool-service';
import { HttpService } from '../providers/http-service';
import { ConfigService } from '../config-servise';
import { ValidatorService } from '../providers/validator-service';
import { UploadService } from '../providers/upload-service';
import { BrowserTab } from '@ionic-native/browser-tab';
import { Square } from '../components/square/square';

@NgModule({
    declarations: [  //引入视图类（包括：components、directive、pipe）
        MyApp,
        LoginPage,
        FindPwdPage,
        RegisterPage,
        ChangePwdPage,

        ShopAssistantTabsPage,
        ShopAssistantQrcodePage,
        ShopAssistantWorkOrdersPage,
        ShopAssisyantAchievementPage,
        ShopAssistantMePage,
        ShopAssistantMePersonalInfomationPage,

        SupplierManagerTabsPage,
        SupplierManagerManagementPage,
        SupplierManagerCheckOrderPage,
        SupplierManagerAchievementPage,
        SupplierManagerMePage,
        SupplierManagerMePersonalInfomationPage,

        OperatorManagerTabsPage,
        OperatorManagerStatisticPage,
        OperatorManagerMePage,

        WorkOrdersListPage,
        WorkOrderDetailPage,
        ValidationCodePage,
        OrderListHeaderPage,
        OrderListContentPage,
        AchievementDetailPage,
        CheckOrderDetailPage,
        CheckClerkDetailPage,
        ClerkDetailPage,
        UploadDeliveryPhotoPage,
        //指令
        Square
    ],
    imports: [  //引入依赖模块
        IonicModule.forRoot(MyApp, {
            activator: 'highlight',
            backButtonText: '',
            backButtonIcon: 'ios-arrow-back',
            iconMode: 'ios',
            modalEnter: 'modal-slide-in',
            modalLeave: 'modal-slide-out',
            tabbarPlacement: 'bottom',
            pageTransition: 'ios'
        }),
        HttpModule,
        QRCodeModule
    ],
    bootstrap: [IonicApp],  //指定渲染APP
    entryComponents: [  //与declarations保持一致
        MyApp,
        LoginPage,
        FindPwdPage,
        RegisterPage,
        ChangePwdPage,

        ShopAssistantTabsPage,
        ShopAssistantQrcodePage,
        ShopAssistantWorkOrdersPage,
        ShopAssisyantAchievementPage,
        ShopAssistantMePage,
        ShopAssistantMePersonalInfomationPage,

        SupplierManagerTabsPage,
        SupplierManagerManagementPage,
        SupplierManagerCheckOrderPage,
        SupplierManagerAchievementPage,
        SupplierManagerMePage,
        SupplierManagerMePersonalInfomationPage,

        OperatorManagerTabsPage,
        OperatorManagerStatisticPage,
        OperatorManagerMePage,

        WorkOrdersListPage,
        WorkOrderDetailPage,
        ValidationCodePage,
        OrderListHeaderPage,
        OrderListContentPage,
        AchievementDetailPage,
        CheckOrderDetailPage,
        CheckClerkDetailPage,
        ClerkDetailPage,
        UploadDeliveryPhotoPage,
        //指令
        // Square
    ],
    providers: [  //引入依赖服务
        {
            provide: ErrorHandler,
            useClass: IonicErrorHandler
        },
        Storage,
        ConnectService,
        TestdataService,
        HttpService,
        ToolService,
        ConfigService,
        ValidatorService,
        UploadService,
        BrowserTab
    ]
})
export class AppModule { }
