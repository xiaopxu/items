import { Component, ViewChild } from '@angular/core';
import { Platform, ToastController, IonicApp, Nav } from 'ionic-angular';
import { StatusBar, Splashscreen } from 'ionic-native';
import { LoginPage } from '../pages/common-pages/login/login';

@Component({
    templateUrl: 'app.html'
})
export class MyApp {
    //指定根组件
    rootPage = LoginPage
    //判断返回键是否触发
    backButtonPressed: boolean = false;
    @ViewChild('myNav') nav: Nav;

    constructor(
        public platform: Platform,
        public ionicApp: IonicApp,
        public toastCtrl: ToastController
    ) {
        //初始化根组件
        this.rootPage = LoginPage

        platform.ready().then(() => {
            StatusBar.styleDefault();
            Splashscreen.hide();
            platform.registerBackButtonAction((): any => {  //注册返回按键事件
                //处理弹出层情况
                //如果想点击返回按钮隐藏toast或loading或Overlay就把下面加上
                // this.ionicApp._toastPortal.getActive() || this.ionicApp._loadingPortal.getActive() || this.ionicApp._overlayPortal.getActive()
                let activePortal = this.ionicApp._modalPortal.getActive() || this.ionicApp._overlayPortal.getActive();
                if (activePortal) {
                    activePortal.dismiss().catch(() => { });
                    activePortal.onDidDismiss(() => { });
                    return;
                }
                //处理非弹出层情况
                let activeVC = this.nav.getActive();
                //登陆页情况
                if (activeVC.name == 'LoginPage' || activeVC.name == 'FindPwdPage' || activeVC.name == 'RegisterPage') {
                    if (!activeVC.enableBack()) {
                        this.showExit()
                    } else {
                        this.nav.pop()
                    }
                } else { //tab页情况
                    let tabs = activeVC.instance.tabs;
                    let activeNav = tabs.getSelected();
                    activeNav.canGoBack() ? activeNav.pop() : this.showExit()
                }
            }, 101);
        });
    }

    //双击退出提示框，这里使用Ionic2的ToastController
    private showExit() {
        if (this.backButtonPressed) this.platform.exitApp();  //当触发标志为true时，即2秒内双击返回按键则退出APP
        else {
            console.log(5)
            let toast = this.toastCtrl.create({
                message: '再按一次退出应用',
                duration: 2000,
                position: 'bottom'
            });
            toast.present();
            this.backButtonPressed = true;
            //2秒内没有再次点击返回则将触发标志标记为false
            setTimeout(() => {
                this.backButtonPressed = false;
            }, 2000)
        }
    }
}
