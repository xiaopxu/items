import { Injectable } from '@angular/core';
import { ConfigService } from '../config-servise';


/**
 * @description 存放API请求地址
 * @export
 * @class ApiUrlService
 * @author xjn
 * @date 2017年3月26日
 */
@Injectable()
export class ApiUrlService {

    private static baseHost: string = ConfigService.getConfig('baseHost');  //基础地址
    private static commonHost: string = ConfigService.getConfig('commonHost');  //通用地址
    private static host: string = ApiUrlService.baseHost + ApiUrlService.commonHost;  //基础地址 + 通用地址

    //----------------------照片上传组件------------------------
    private static uploadCloud: string = ApiUrlService.baseHost + '/new/api/iobsToken';

    //----------------------登录组件------------------------
    // private static login: string = ApiUrlService.host + '/common/userLogin';
    private static login: string = ApiUrlService.baseHost + '/new/api/login';  //获取登录信息
    private static getStoreUserInfo: string = ApiUrlService.host + '/common/getStoreUserInfo';  //获取用户信息
    private static checkVersion: string = ApiUrlService.baseHost + '/new/api/checkVersion';  //获取用户信息

    //----------------------登录组件------------------------
    private static logout: string = ApiUrlService.host + '/common/logout';

    //----------------------注册组件------------------------
    private static register: string = ApiUrlService.host + '/common/register';  //注册
    private static getOperators: string = ApiUrlService.host + '/common/getOperators';  //获取运营商
    private static getCompanies: string = ApiUrlService.host + '/common/getCompaniesByOperatorId';  //获取供应商
    private static getStores: string = ApiUrlService.host + '/common/getStoresByCompanyId';  //获取门店

    //----------------------忘记密码组件------------------------
    private static resetPwd: string = ApiUrlService.host + '/common/resetPwd';

    //----------------------修改密码组件------------------------
    private static updatePwd: string = ApiUrlService.host + '/common/updatePwd';

    //----------------------验证码组件------------------------
    private static sendSms: string = ApiUrlService.baseHost + '/new/api/sendSms';


    //****************店员*********************

    //----------------------工单组件------------------------
    private static getClerkOrderList: string = ApiUrlService.host + '/clerk/getClerkOrderList';  //合约机列表
    private static getStageClerkOrderList: string = ApiUrlService.host + '/clerk/getStageClerkOrderList';  //小件均列表
    private static getApplianceClerkOrderList: string = ApiUrlService.host + '/clerk/getApplianceClerkOrderList';  //家电列表

    private static getClerkOrderDetail: string = ApiUrlService.host + '/clerk/getClerkOrderDetail';  //合约机订单详情
    private static getStageOrderDetail: string = ApiUrlService.host + '/clerk/getStageOrderDetail';  //小件均订单详情
    private static getApplianceOrderDetail: string = ApiUrlService.host + '/clerk/getApplianceOrderDetail';  //家电订单详情

    private static clerkCheckInOrder: string = ApiUrlService.host + '/clerk/clerkCheckInOrder';  //合约机登记工单
    private static stageClerkCheckInOrder: string = ApiUrlService.host + '/clerk/stageClerkCheckInOrder';  //小件均登记工单
    private static applianceClerkCheckInOrder: string = ApiUrlService.host + '/clerk/applianceClerkCheckInOrder';  //家电登记工单

    private static stageClerkCheckInOrderTimeOut: string = ApiUrlService.host + '/clerk/stageClerkCheckInOrderTimeOut';  //小件均登记工单
    private static applianceClerkCheckInOrderTimeOut: string = ApiUrlService.host + '/clerk/applianceClerkCheckInOrderTimeOut';  //小件均登记工单

    // private static applianceApproveRefund: string = ApiUrlService.host + '/clerk/applianceApproveRefund';  //同意退款
    // private static applianceRejectRefund: string = ApiUrlService.host + '/clerk/applianceRejectRefund';  //拒绝退款
    private static reimburseCheck: string = ApiUrlService.host + '/clerk/reimburseCheck';  //退款



    //----------------------店员业绩组件------------------------
    private static getClerkPerformance: string = ApiUrlService.host + '/clerk/getClerkPerformance';  //合约机店员发展量
    private static getClerkPerformanceDetail: string = ApiUrlService.host + '/clerk/getClerkPerformanceDetail';  //合约机店员发展量详情


    //****************供应商管理员*********************

    //----------------------店员管理------------------------
    private static getStoresBySupplier: string = ApiUrlService.host + '/supplier/getStores';  //获取门店列表
    private static getNewClerkCount: string = ApiUrlService.host + '/supplier/getNewClerkCount';  //获取待审核店员数量
    private static getClerksByStoreId: string = ApiUrlService.host + '/supplier/getClerksByStoreId';  //获取店员列表
    private static getUncheckClerks: string = ApiUrlService.host + '/supplier/getUncheckClerks';  //获取待审核店员列表
    private static clerkCheck: string = ApiUrlService.host + '/supplier/clerkCheck';  //审核店员

    //----------------------验单组件------------------------
    private static getStageOrdersConfirm: string = ApiUrlService.host + '/supplier/getStageOrdersConfirm';  //小件均验单列表
    private static getStageOrdersConfirmDetail: string = ApiUrlService.host + '/supplier/getStageOrdersConfirmDetail';  //小件均验单详情
    private static stageOrdersConfirm: string = ApiUrlService.host + '/supplier/stageOrdersConfirm';  //小件均验单确认

    private static getApplianceOrdersConfirm: string = ApiUrlService.host + '/supplier/getApplianceOrdersConfirm';  //小件均验单列表
    private static getApplianceOrdersConfirmDetail: string = ApiUrlService.host + '/supplier/getApplianceOrdersConfirmDetail';  //小件均验单详情
    private static applianceOrdersConfirm: string = ApiUrlService.host + '/supplier/applianceOrdersConfirm';  //小件均验单确认

    private static getOrdersConfirm: string = ApiUrlService.host + '/supplier/getOrdersConfirm';  //合约机验单列表
    private static getOrdersConfirmDetail: string = ApiUrlService.host + '/supplier/getOrdersConfirmDetail';  //合约机验单详情
    private static ordersConfirm: string = ApiUrlService.host + '/supplier/ordersConfirm';  //合约机验单确认

    //----------------------管理员业绩组件------------------------
    private static getManagerPerformance: string = ApiUrlService.host + '/supplier/getManagerPerformance';  //合约机店员发展量
    private static getManagerPerformanceDetail: string = ApiUrlService.host + '/supplier/getManagerPerformanceDetail';  //合约机店员发展量详情

    private static getStageClerkPerformance: string = ApiUrlService.host + '/supplier/getStageClerkPerformance';  //小件均店员发展量
    private static getStageClerkPerformanceDetail: string = ApiUrlService.host + '/supplier/getStageClerkPerformanceDetail';  //小件均店员发展量详情

    private static getApplianceClerkPerformance: string = ApiUrlService.host + '/supplier/getApplianceClerkPerformance';  //家电店员发展量
    private static getApplianceClerkPerformanceDetail: string = ApiUrlService.host + '/supplier/getApplianceClerkPerformanceDetail';  //家电店员发展量详情



    constructor() { }

    /**
     * @description 获取API地址
     * @static
     * @returns {ApiUrlService}
     * @memberOf ApiUrlService
     * @author xjn
     * @date 2017年3月26日
     */
    public static getApiUrl(apiUrl: string) {
        return ApiUrlService[apiUrl]
    }

}
