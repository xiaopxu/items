import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { AlertController, LoadingController } from 'ionic-angular';
import { ToolService } from './tool-service';
import 'rxjs/add/operator/map';
import { ConnectService } from './connect-service';
// import * as PaWebJs from '../javascripts/pawebjs.js';
import { LoginPage } from '../pages/common-pages/login/login';
import { ApiUrlService } from './api-url-service';

/**
 * @description http服务封装，统一处理返回结果
 * @export
 * @class HttpService
 * @author xjn
 * @date 2017年3月6日
 */
@Injectable()
export class HttpService {

    private appVersion: string = '';//APP版本
    private apiVersion: string = '';//API版本

    constructor(
        private _http: Http,
        private alertCtrl: AlertController,
        private toolService: ToolService,
        private loadingCtrl: LoadingController,
        private connectService: ConnectService
    ) { }

    /**
     * @description: post请求，统一处理异常情况
     * @param {*} param 请求参数
     * @param {*} event 上拉加载实例 or 下拉刷新实例
     * @param {string} skipPresentLoading 是否跳过弹出加载提示符
     * @param {string} skipDismissLoading 是否跳过关闭加载提示符
     * @returns {Promise}
     * @memberOf HttpService
     * @author xjn
     * @date 2017年3月6日
     */
    public post(param: any, event?: any, skipPresentLoading?: boolean, skipDismissLoading?: boolean): any {
        //开启加载提示符
        if (!event && !skipPresentLoading) {
            //启动加载提示符
            let loading = this.loadingCtrl.create({
                spinner: 'ios',
                content: '加载中...'
            })
            this.connectService.saveData('loading', loading)
            this.connectService.getData('loading').present();
        }
        //设置请求头
        let headers: Headers = new Headers({ 'Content-Type': 'application/json' });
        let options: RequestOptions = new RequestOptions({ headers: headers });
        //设置sparta参数
        // let fp = new PaWebJs.get() || '';
        //设置请求参数
        let requestData: any = {
            appVersion: this.appVersion || '',
            apiVersion: this.apiVersion || '',
            sessionToken: param.sessionToken || this.connectService.getData('loginInfo').userSession || '',
            // sessionToken: '11111111111111111111',
            accountId: param.accountId || this.connectService.getData('loginInfo').userId || '',
            accountRole: param.accountSysRole || '2',
            optionsMethod: param.optionsMethod || '',
            blackBox: '',
            blackBoxType: 'SPARTA',
            body: JSON.stringify(param.params || {}),
        }
        //打印请求地址
        console.warn('======================发起请求==========================')
        console.warn('请求地址')
        console.log(param.url)
        //打印请求参数
        console.warn('请求参数')
        console.log(requestData)

        return new Promise((resolve, reject) => {
            this._http.post(param.url, JSON.stringify(requestData), options)
                .map(res => res.json())
                .subscribe(
                //请求成功
                res => {
                    //打印响应数据
                    console.warn('响应数据')
                    console.log(res)
                    //关闭加载提示符
                    if (!event && !skipDismissLoading) {
                        this.connectService.getData('loading').dismiss();
                    }
                    //统一处理请求结果
                    if (typeof (res) == "undefined" || res === null || typeof (res.data) == "undefined" || res.data === null) {
                        reject('请求数据异常')
                    } else {
                        if (res.code == 2000) {  //2000请求成功
                            resolve(res.data)
                        } else if (res.code == 4000 || res.code == 4001) {  //4000请求失败 4001登录超时
                            if (!event && skipDismissLoading) {
                                this.connectService.getData('loading').dismiss();
                            }
                            reject(res.message)
                        }
                    }
                },
                //请求失败
                err => {
                    //关闭加载提示符
                    if (!event && !skipDismissLoading) {
                        this.connectService.getData('loading').dismiss();
                        reject('服务器错误！')
                    }
                })
        })
    }

    /**
     * @description 请求出错，弹出警告窗口
     * @param {string} err 错误信息
     * @memberOf HttpService
     * @author xjn
     * @date 2017年3月24日
     */
    public handleErr(err: string, navCtrl?: any) {
        console.log(err);
        if (typeof (err) == "undefined" || err === null) {
            err = '请求数据异常';
        }
        if (err != '登录超时，请重新登录！') {
            this.toolService.showAlert(err)
        } else {
            this.toolService.showTimeoutAlert(err, 2000)
            //发起登出请求
            let param = {
                url: ApiUrlService.getApiUrl('logout')
            }
            this.post(param, null, true, true)
                .then(res => {
                    //清空登录数据
                    this.connectService.saveData('loginStatus', '');
                    this.connectService.saveData('userId', '');
                    //打印当前导航信息
                    console.warn('当前导航')
                    console.log(navCtrl)

                    //判断当前是否存弹出层，若存在则将其关闭
                    // let activePortal = this.ionicApp._modalPortal.getActive();
                    // if (activePortal) {
                    //     activePortal.dismiss().catch(() => { });
                    //     activePortal.onDidDismiss(() => { });
                    //     return;
                    // }

                    //根据当前页面在导航中的层级，获取到根导航
                    let navIndex: any = navCtrl.index;
                    if (navIndex) {
                        for (let i = 0; i < navIndex - 1; i++) {
                            navCtrl = navCtrl.parent
                        }
                    }
                    //重新回到登陆页面
                    navCtrl.parent.parent.setRoot(LoginPage)
                })
                .catch(err => {
                    console.log(err);
                    console.log(err.message);
                    this.handleErr(err.message);
                })
        }
    }
}
