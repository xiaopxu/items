import { Injectable } from '@angular/core';
import { ToolService } from './tool-service';


/**
 * @description 存放校验规则及校验方法的服务
 * @export
 * @class ValidatorService
 * @author xjn
 * @date 2017年3月25日
 */
@Injectable()
export class ValidatorService {
    //校验规则
    private phoneRegExp: any = /^1[34578]\d{9}$/;  //手机号
    private userNameRegExp: any = /^[a-zA-Z0-9][a-zA-Z0-9_]{5,}$/;  //用户名
    private pwdRegExp: any = /^(?!([a-zA-Z]+|\d+)$)[a-zA-Z\d]{8,}$/;  //密码
    private validationCodeRegExp: any = /^\d{6}$/;  //验证码
    private idCardRegExp: any = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  //身份证号
    private nameRegExp: any = /^[\u4e00-\u9fa5]{2,}$/;  //姓名
    private goodsNoRegExp: any = /^[0-9a-zA-Z]*$/;  //商品串号
    private invoiceNumberRegExp: any = /^\d{8}$/;  //发票号

    constructor(
        private toolService: ToolService
    ) {

    }

    //校验手机号
    public checkPhone(phone: string, type: string): boolean {
        if (phone) {
            if (this.phoneRegExp.test(phone)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }
    //校验用户名
    public checkUserName(userName: string, type: string): boolean {
        if (userName) {
            if (this.userNameRegExp.test(userName)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }
    //校验密码
    public checkPwd(usePwd: string, type: string): boolean {
        if (usePwd) {
            if (this.pwdRegExp.test(usePwd)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }
    //校验确认密码
    public checkCheckPwd(checkPwd: string, type: string): boolean {
        if (checkPwd) {
            if (this.pwdRegExp.test(checkPwd)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }
    //校验验证码
    public checkValidationCode(validationCode: string, type: string): boolean {
        if (validationCode) {
            if (this.validationCodeRegExp.test(validationCode)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }
    //校验身份证号
    public checkIdCard(idNumber: string, type: string): boolean {
        if (idNumber) {
            if (this.idCardRegExp.test(idNumber)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }
    //校验姓名
    public checkIdName(idName: string, type: string): boolean {
        if (idName) {
            if (this.nameRegExp.test(idName)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }
    //校验商品串号
    public checkGoodsNo(goodNo: string, type: string): boolean {
        if (goodNo) {
            if (this.goodsNoRegExp.test(goodNo)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }
    //校验发票号
    public checkInvoiceNumber(invoiceNumber: string, type: string): boolean {
        if (invoiceNumber) {
            if (this.invoiceNumberRegExp.test(invoiceNumber)) {
                return true
            } else {
                this.toolService.showAlert(`请输入正确的${type}`);
                return false
            }
        } else {
            this.toolService.showAlert(`请输入${type}`);
            return false
        }
    }

}
