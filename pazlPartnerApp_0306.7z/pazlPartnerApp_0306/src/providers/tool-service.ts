import { Injectable } from '@angular/core';
import { AlertController, Events, Platform } from 'ionic-angular';
import { ConnectService } from './connect-service';
import { Md5 } from 'ts-md5/dist/md5';
import { ConfigService } from '../config-servise';

declare var BMap;

/**
 * @title ToolService
 * @description 存放工具方法的服务
 * @export
 * @class ToolService
 * @author xjn
 * @date 2017年3月10日
 */
@Injectable()
export class ToolService {

    constructor(
        private alertCtrl: AlertController,
        private events: Events,
        private connectService: ConnectService,
        private plt: Platform
    ) {

    }

    /**
     * @description 获取当前设备种类
     * @returns {string}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年4月5日
     */
    public getDeviceType() {
        let deviceType = '';
        if (this.plt.is('ios')) {
            deviceType = 'IOS'
        } else if (this.plt.is('android')) {
            deviceType = 'ANDROID'
        } else {
            deviceType = 'ANDROID'
        }
        return deviceType
    }

    /**
     * @description md5加密方法
     * @param {string} field 需要加密的字段值
     * @returns {string}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月26日
     */
    public encryptByMd5(field: string): string {
        return Md5.hashStr(field).toString().toUpperCase()
    }

    /**
     * @description 截取时间
     * @param {string} time 时间
     * @returns {string}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月27日
     */
    public timeSubString(time: string): string {
        return time.substr(0, 19);
    }

    /**
     * @description 弹出警告窗口
     * @param {string} msg 弹出内容
     * @returns {void}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月6日
     */
    public showAlert(msg: string): void {
        let alert = this.alertCtrl.create({
            title: '平安租赁',
            subTitle: msg,
            buttons: ['关闭']
        });
        alert.present();
    }

    public showTimeoutAlert(msg: string, time: number): void {
        let alert = this.alertCtrl.create({
            subTitle: msg
        });
        alert.present();
        setTimeout(() => {
            alert.dismiss();
        }, time);
    }

    /**
     * @description 弹出警告窗口（自定义）
     * @param {string} title 弹出标题
     * @param {string} msg 弹出内容
     * @param {?string} btn1Text 按钮1文字
     * @param {?any} btn1Func 按钮1事件
     * @param {?string} btn2Text 按钮2文字
     * @param {?any} btn2Func 按钮2事件
     * @returns {void}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年4月5日
     */
    public showCustomAlert(title: string, msg: string, btn1Text?: string, btn1Func?: any, btn2Text?: string, btn2Func?: any): void {
        let buttons: any[] = []
        if (btn1Text) {
            let btn1: any = {
                text: btn1Text,
                handler: () => {
                    if (btn1Func) {
                        btn1Func();
                    }
                }
            }
            buttons.push(btn1)
        }
        if (btn2Text) {
            let btn2: any = {
                text: btn2Text,
                handler: () => {
                    if (btn2Func) {
                        btn2Func();
                    }
                }
            }
            buttons.push(btn2)
        }
        let alert: any = this.alertCtrl.create({
            title: title,
            subTitle: msg,
            buttons: buttons
        });
        alert.present();
    }

    /**
     * @description 弹出单选列表
     * @param {string} title 标题
     * @param {any[]} list 列表数据
     * @param {string} eventType 传值事件命名
     * @returns {void}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月23日
     */
    public showRadio(title: string, list: any[], eventType?: string): void {
        //创建alert对象
        let alert = this.alertCtrl.create();
        //标题设置
        alert.setTitle(title);
        //生成选项列表
        list.map(item => {
            console.log(item)
            alert.addInput({
                type: 'radio',
                label: item.value,
                value: item,
                checked: false
            });
        })
        //生成cancel按钮
        alert.addButton('取消');
        //生成OK按钮
        alert.addButton({
            text: '选择',
            handler: data => {

                if (Object.prototype.toString.call(data) === '[object Object]') {
                    if (typeof data.key === 'string' && data.key !== '') {
                        this.events.publish(eventType, data); // 传值给相应页面，页面中用subscribe接受
                    }
                }
            }
        });
        //弹出alert窗口
        alert.present();
    }

    /**
     * @description 清除定时器列表
     * @returns {viod}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月24日
     */
    public clearTimeArray(): void {
        this.connectService.commonData.timeIntervalArray.map((timer, index, timeIntervalArray) => {
            clearInterval(timer);  //清除定时器
            timeIntervalArray.pop(timer);  //删除数组中的该定时器
            // console.log(timeIntervalArray);
        })
    }

    /**
     * @description
     * 将获取到的订单数据进行时间归类
     * 按照时间添加到绑定模板展示的数组displayOrders中
     * 并将当前订单时间更新至存放时间的数组orderDateExist中
     * @param {any[]} listData 订单数组
     * @returns {void}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月13日
     */
    public setOrdersByDate(listData: any[]): void {
        let shareData = this.connectService.commonData  //变量暂存
        let date: string = '';
        //遍历订单数组
        listData.forEach(order => {
            date = order.date || order.time;  //获取该条订单的时间
            date = date.substring(0, 10)
            //判断该条订单的时间是否在时间数组数组（orderDateExist）中
            if (shareData.orderDateExist.indexOf(date) >= 0) {  //如果订单时间已存在，找到订单数组（displayOrders）中的该日期数组，插入订单
                shareData.displayOrders.forEach(ordersByDate => {
                    if (ordersByDate.date == date) {
                        ordersByDate.orders.push(order)
                    }
                })
            } else {  //如果订单时间不存在，新建订单对象，插入订单数组（displayOrders）；并将时间存入时间数组（orderDateExist）
                let ordersByDate: any = {
                    date: date,
                    orders: [order]
                }
                shareData.displayOrders.push(ordersByDate);
                shareData.orderDateExist.push(date);
            }
        })
        //将转换完毕的数组传递出去
        this.events.publish('getOrdersByDateComplete', shareData.orderDateExist, shareData.displayOrders);
    }

    public setClerksByStore(listData: any[]): void {
        let shareData = this.connectService.commonData  //变量暂存
        let storeName: string = '';
        //遍历订单数组
        listData.forEach(clerk => {
            storeName = clerk.storeName;
            //判断该条订单的时间是否在时间数组数组（orderDateExist）中
            if (shareData.storeExist.indexOf(storeName) >= 0) {  //如果订单时间已存在，找到订单数组（displayOrders）中的该日期数组，插入订单
                shareData.displayClerks.forEach(clerksByStore => {
                    if (clerksByStore.storeName == storeName) {
                        clerksByStore.clerks.push(clerk)
                    }
                })
            } else {  //如果订单时间不存在，新建订单对象，插入订单数组（displayOrders）；并将时间存入时间数组（orderDateExist）
                let clerksByStore: any = {
                    storeName: storeName,
                    clerks: [clerk]
                }
                shareData.displayClerks.push(clerksByStore);
                shareData.storeExist.push(storeName);
            }
        })
        //将转换完毕的数组传递出去
        this.events.publish('getClerksByStoreComplete', shareData.storeExist, shareData.displayClerks);
    }

    /**
     * @description
     * 获取经纬度
     * @param {any} successCallback
     * @param {any} errorCallback
     * @returns {void}
     * @memberOf ToolService
     * @author zjj
     * @date 2017年04月20日
     */
    public getLngAndLat(successCallback: any, errorCallback?: any): void {
        if (!ConfigService.getConfig('skipCordova').lngAndLat) {
            let lng = '';
            let lat = '';

            navigator.geolocation.getCurrentPosition(function (position) {
                const x = position.coords.longitude;
                const y = position.coords.latitude;

                let ggPoint = new BMap.Point(x, y);

                let convertor = new BMap.Convertor();
                let pointArr = [];

                pointArr.push(ggPoint);
                convertor.translate(pointArr, 1, 5, data => {
                    if (data.status == 0) {
                        lng = data.points[0].lng;
                        lat = data.points[0].lat;
                    }

                    successCallback({
                        lng: lng,
                        lat: lat
                    });
                });
            }, errorCallback);
        } else {
            successCallback({ lng: '', lat: '' });
        }
    }
}
