import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { OperatorManagerStatisticPage } from '../operator-manager-statistic/operator-manager-statistic';
import { OperatorManagerMePage } from '../operator-manager-me/operator-manager-me';

/*
  Generated class for the OperatorManagerTabs page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-operator-manager-tabs',
  templateUrl: 'operator-manager-tabs.html'
})
export class OperatorManagerTabsPage {
  
  tab1Root: any = OperatorManagerStatisticPage;
  tab2Root: any = OperatorManagerMePage;

  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad OperatorManagerTabsPage');
  }

}
