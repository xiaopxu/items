import { Component } from '@angular/core';
import { ModalController, Events, NavController, App } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ConnectService } from '../../../providers/connect-service';
import { ConfigService } from '../../../config-servise';
import { TestdataService } from '../../../providers/testdata-service';

@Component({
    selector: 'page-shop-assistant-qrcode',
    templateUrl: 'shop-assistant-qrcode.html',
    providers: []
})
export class ShopAssistantQrcodePage {

    public loginStatus: any = '';

    constructor(
        public navCtrl: NavController,
        public modalCtrl: ModalController,
        public events: Events,
        public storage: Storage,
        public appCtrl: App,
        public connectService: ConnectService,
        public configService: ConfigService,
        public testdataService: TestdataService
    ) {

    }
    ionViewDidLoad() {
        if (!ConfigService.getConfig('devMode')) {
            this.loginStatus = this.connectService.getData('loginStatus');
        } else {
            this.loginStatus = this.testdataService.qrCodeList.data;
        }
        // console.log(this.navCtrl.getActive().name)
    }

}
