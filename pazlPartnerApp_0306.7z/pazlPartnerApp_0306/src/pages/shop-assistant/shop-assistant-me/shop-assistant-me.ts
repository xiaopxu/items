import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ConnectService } from '../../../providers/connect-service';
import { LoginPage } from '../../common-pages/login/login';
import { ShopAssistantMePersonalInfomationPage } from '../shop-assistant-me-personal-infomation/shop-assistant-me-personal-infomation';
import { ChangePwdPage } from '../../common-pages/change-pwd/change-pwd';
import { HttpService } from '../../../providers/http-service';
import { ApiUrlService } from '../../../providers/api-url-service';

@Component({
    selector: 'page-shop-assistant-me',
    templateUrl: 'shop-assistant-me.html'
})
export class ShopAssistantMePage {
    public storeUserName: string = '';  //用户名
    public storeUserPhoneNum: string = '';  //手机号
    public storeUserIdCard: string = ''; //身份证


    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        public connectService: ConnectService,
        private httpService: HttpService
    ) { }

    ionViewDidLoad() {
        let loginStatus: any = this.connectService.getData('loginStatus');
        this.storeUserName = loginStatus.storeUserName;
        this.storeUserPhoneNum = loginStatus.storeUserPhoneNumber;
        this.storeUserIdCard = loginStatus.storeUserIdentityCardNumber;
    }
    userInfo() {
        console.log("userInfo");
        this.navCtrl.push(ShopAssistantMePersonalInfomationPage);
    }
    changePwd() {
        console.log("changePwd");
        this.navCtrl.push(ChangePwdPage);
    }
    logout() {
        console.log("loginout");
        let param = {
            url: ApiUrlService.getApiUrl('logout')
        }
        this.httpService.post(param)
            .then(res => {
                this.connectService.saveData('loginStatus', '');
                this.connectService.saveData('userId', '');
                this.navCtrl.parent.parent.setRoot(LoginPage)
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl);
            })
    }
}
