import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
    selector: 'page-clerk-detail',
    templateUrl: 'clerk-detail.html'
})
export class ClerkDetailPage {

    private clerkDetailList: any[] = [];
    private clerkDetailListInit: any[] = [];
    private store: any = {};

    constructor(public navCtrl: NavController, public navParams: NavParams) { }

    ionViewDidLoad() {
        console.warn('========================进入供应商管理员-店员-店员详情============================')
    }

    ionViewWillEnter() {
        this.clerkDetailList = this.navParams.data.clerkDetailList;
        this.clerkDetailListInit = this.navParams.data.clerkDetailList;
        this.store = this.navParams.data.store;
    }

    public searchClerkList(ev: any) {
        this.clerkDetailList = this.clerkDetailListInit;

        let val = ev.target.value;

        if (val && val.trim() != '') {
            this.clerkDetailList = this.clerkDetailList.filter((item) => {
                return (item.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
            })
        }
    }

}
