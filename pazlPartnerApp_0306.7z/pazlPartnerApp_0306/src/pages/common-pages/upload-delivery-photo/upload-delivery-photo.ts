import { Component, ElementRef, Renderer } from '@angular/core';
import { NavController, NavParams, ActionSheetController, Events } from 'ionic-angular';
import { UploadService } from '../../../providers/upload-service';
import { ToolService } from '../../../providers/tool-service';
import { HttpService } from '../../../providers/http-service';


@Component({
    selector: 'page-upload-delivery-photo',
    templateUrl: 'upload-delivery-photo.html'
})
export class UploadDeliveryPhotoPage {

    private photoType = '';
    private goodsEvidence: any[] = [];
    private distributionEvidence: any[] = [];
    private uploadStep: string = 'unload';
    private deliveryType = '';
    private deliveryOrder: any[] = [];
    private deliveryAddress: any[] = [];

    private goodsEvidenceStatus: boolean = false;
    private deliveryOrderStatus: boolean = false;
    private deliveryAddressStatus: boolean = false;

    private actualDeliveryAddressLatitude: string = '';
    private actualDeliveryAddressLongitude: string = '';

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private ele: ElementRef,
        private uploadService: UploadService,
        private actionSheetCtrl: ActionSheetController,
        private events: Events,
        private toolService: ToolService,
        private renderer: Renderer,
        private httpService: HttpService
    ) { }

    ionViewDidLoad() {
        console.log('ionViewDidLoad UploadDeliveryPhotoPage');
        console.log(this.navParams.data);
        this.photoType = this.navParams.data.photoType
        this.deliveryType = this.navParams.data.deliveryType

        this.goodsEvidence = this.navParams.data.goodsEvidence;
        this.deliveryOrder = this.navParams.data.deliveryOrder;
        this.deliveryAddress = this.navParams.data.deliveryAddress;

        //变更上传状态，并在上传成功的情况下获取图片信息
        this.events.subscribe('upload:change-step', (step, id?, token?, imgId?) => {

            if (id != 'goodsEvidence' && id != 'deliveryOrder' && id != 'deliveryAddress') { return }
            this.uploadStep = step;
            if (this.uploadStep == 'unload') { return }
            let invoiceUrl = '';
            let invoiceImgId = '';
            let photoObj: any = {};

            //如果图片上传成功
            if (token && imgId && this.uploadStep == 'loaded') {
                invoiceUrl = token.iobsCloudUrl;
                invoiceImgId = imgId;
                // let img = this.ele.nativeElement.createElement('img')
                // console.log(img)

                //创建图片信息对象
                photoObj = {
                    picId: new Date().getTime().toString(),
                    picType: '1',
                    cloudKey: invoiceImgId,
                    cloudUrl: invoiceUrl,
                    checkResultArray: [],
                    otherContent: '',
                    mIsCheck: false,
                    checkResult: false
                }

                //图片对象push入图片数组
                if (id == 'goodsEvidence') {
                    photoObj.picName = '商品证明材料'
                    this.goodsEvidence.push(photoObj)
                } else if (id == 'deliveryOrder') {
                    photoObj.picName = '发货单据材料'
                    this.deliveryOrder.push(photoObj)
                } else if (id == 'deliveryAddress') {
                    photoObj.picName = '配送地址材料'
                    photoObj.picType = '2'
                    this.deliveryAddress.push(photoObj)
                }
            }
        })
    }

    public uploadPhoto(id) {
        //如果已经有上传完毕的照片，则不允许重新上传
        // if (this.uploadStep == 'loaded') { return }
        if (id == 'goodsEvidence' && this.goodsEvidence.length >= 5) {
            this.toolService.showAlert('最多只允许上传5张照片')
            return
        }
        if (id == 'deliveryOrder' && this.deliveryOrder.length >= 5) {
            this.toolService.showAlert('最多只允许上传5张照片')
            return
        }
        if (id == 'deliveryAddress' && this.deliveryAddress.length >= 5) {
            this.toolService.showAlert('最多只允许上传5张照片')
            return
        }

        // 抓取经纬度
        if (id == 'deliveryAddress') {
            let callBack = (data) => {
                this.events.publish('get:addressLocation', this.actualDeliveryAddressLatitude, this.actualDeliveryAddressLongitude)
                this.actualDeliveryAddressLatitude = data.lat;
                this.actualDeliveryAddressLongitude = data.lng;
            }
            this.toolService.getLngAndLat(callBack, err => {
                this.events.publish('get:addressLocation', '', '')
            })
        }

        //获取canvas对象
        let canvas = this.ele.nativeElement.querySelector('canvas');
        //调用actionSheet弹出层
        let actionSheet = this.actionSheetCtrl.create({
            title: '选择上传方式',
            buttons: [
                {
                    text: '拍摄',
                    role: 'destructive',
                    handler: () => {
                        this.uploadStep = 'loading'
                        this.uploadService.takePicture(id, canvas)
                    }
                }, {
                    text: '从相册选择',
                    role: 'destructive',
                    handler: () => {
                        this.uploadStep = 'loading'
                        this.uploadService.choosePicture(id, canvas)
                    }
                }, {
                    text: '取消',
                    role: 'cancel',
                    handler: () => {
                        console.log('取消上传');
                    }
                }
            ]
        });
        actionSheet.present();
    }

    public confirm() {
        if (this.photoType == 'goodsEvidence') {
            if (this.goodsEvidence.length == 0) {
                this.toolService.showAlert('请按要求上传商品证明材料')
                return
            }
        } else if (this.photoType == 'distributionEvidence') {
            if (this.deliveryType == '1') {
                if (this.deliveryOrder.length == 0) {
                    this.toolService.showAlert('请按要求上传发货单据材料')
                    return
                }
                if (this.deliveryAddress.length == 0) {
                    this.toolService.showAlert('请按要求上传配送地址材料')
                    return
                }
            } else if (this.deliveryType == '2') {
                if (this.deliveryOrder.length == 0) {
                    this.toolService.showAlert('请按要求上传发货单据材料')
                    return
                }
            }
        }
        this.events.publish('get:deliveryPhotoData', '', this.goodsEvidence, this.deliveryOrder, this.deliveryAddress)
        this.events.publish('get:addressLocation', this.actualDeliveryAddressLatitude, this.actualDeliveryAddressLongitude)
        this.navCtrl.pop();
    }

    public editBtnChange(tarKey: string) {
        if (tarKey === 'goodsEvidence') {
            this.goodsEvidenceStatus = !this.goodsEvidenceStatus;
        } else if (tarKey === 'deliveryOrder') {
            this.deliveryOrderStatus = !this.deliveryOrderStatus;
        } else if (tarKey === 'deliveryAddress') {
            this.deliveryAddressStatus = !this.deliveryAddressStatus;
        }
    }

    public dealWithPhotoBox(tarKey: string, photo: any) {
        if (tarKey === 'goodsEvidence') {
            if (this.goodsEvidenceStatus === false) {
                this.uploadService.PhotoViewer(photo.cloudUrl)
            } else if (this.goodsEvidenceStatus === true) {
                this.goodsEvidence = this.goodsEvidence.filter(item => {
                    return item.picId !== photo.picId
                });
            }
        } else if (tarKey === 'deliveryOrder') {
            if (this.deliveryOrderStatus === false) {
                this.uploadService.PhotoViewer(photo.cloudUrl)
            } else if (this.deliveryOrderStatus === true) {
                this.deliveryOrder = this.deliveryOrder.filter(item => {
                    return item.picId !== photo.picId
                })
            }
        } else if (tarKey === 'deliveryAddress') {
            if (this.deliveryAddressStatus === false) {
                this.uploadService.PhotoViewer(photo.cloudUrl)
            } else if (this.deliveryAddressStatus === true) {
                this.deliveryAddress = this.deliveryAddress.filter(item => {
                    return item.picId !== photo.picId
                })
            }
        }

        this.events.publish('get:deliveryPhotoData', '', this.goodsEvidence, this.deliveryOrder, this.deliveryAddress)
    }

    ionViewWillLeave() {
        this.events.unsubscribe('upload:change-step');
    }
}
