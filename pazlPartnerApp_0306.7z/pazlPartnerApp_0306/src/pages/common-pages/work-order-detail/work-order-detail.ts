import { Component, ElementRef } from '@angular/core';
import { NavController, NavParams, ActionSheetController, Events, AlertController } from 'ionic-angular';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';
import { ValidatorService } from '../../../providers/validator-service';
import { UploadService } from '../../../providers/upload-service';
import { HttpService } from '../../../providers/http-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { ConnectService } from '../../../providers/connect-service';
import { UploadDeliveryPhotoPage } from '../upload-delivery-photo/upload-delivery-photo';


@Component({
    selector: 'page-work-order-detail',
    templateUrl: 'work-order-detail.html'
})
export class WorkOrderDetailPage {

    private orderDetailData: any = [];
    private phoneNumber: string = '';
    private validationCode: string = '';
    private goodsNo: string = '';
    private tempOrderStatus: string = '';
    private tempBusinessType: string = '';
    private base64Img: string = '';
    private uploadStep: string = 'unload';
    private smsId: string = '';
    private invoiceNumber: string = '';
    private invoiceUrl = '';
    private invoiceImgId = '';
    private isOverTime: boolean = false;
    private checkinDisable: boolean = false;
    private day: any = '';
    private hours: any = '';
    private minutes: any = '';
    private seconds: any = '';
    private invoiceLimitTime: number = 24 * 4;
    private deliverySelfLimitTime: number = 24 * 14;
    private deliveryOtherLimitTime: number = 24 * 14;
    private contractPhone: string = '';
    private goodsLogistics: string = '';
    private showOrderDetail: boolean = false;
    private showAddressInfo: boolean = false;
    private deliveryType: string = '';
    private goodsEvidence: any[] = [];
    private distributionEvidence: any[] = [];
    private deliveryOrder: any[] = [];
    private deliveryAddress: any[] = [];
    private refundReason: string = '';
    private selfDisable: boolean = false;
    private otherDisable: boolean = false;

    private goodsEvidenceArr: any[] = [];
    private distributionEvidence1Arr: any[] = [];
    private distributionEvidence2Arr: any[] = [];

    private goodsEvidenceErrorStatus: boolean = false;
    private distributionEvidenceErrorStatus: boolean = false;

    private actualDeliveryAddressLatitude: string = '';
    private actualDeliveryAddressLongitude: string = '';

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private toolService: ToolService,
        private validatorService: ValidatorService,
        private uploadService: UploadService,
        private actionSheetCtrl: ActionSheetController,
        private events: Events,
        private ele: ElementRef,
        private httpService: HttpService,
        private connectService: ConnectService,
        private alertCtrl: AlertController
    ) { }

    ionViewDidLoad() {
        this.orderDetailData = this.navParams.data;
        this.goodsLogistics = this.orderDetailData.goodsLogistics;
        // this.goodsLogistics = '0';
        console.warn('订单详情')
        console.log(this.orderDetailData)

        // if (this.orderDetailData.orderEvidenceInvoice) {
        //     this.invoiceUrl = JSON.parse(this.orderDetailData.orderEvidenceInvoice)[0].cloudUrl
        // }
        //如果是待完善资料，回显商品串号、发票号码、合约机号
        if (this.orderDetailData.orderStoreUserInvoiceNumber) {
            this.invoiceNumber = this.orderDetailData.orderStoreUserInvoiceNumber;
        }
        if (this.orderDetailData.orderDeviceCode) {
            this.goodsNo = this.orderDetailData.orderDeviceCode;
        }
        if (this.orderDetailData.orderContractNumber) {
            this.contractPhone = this.orderDetailData.orderContractNumber;
        }
        //获取订单状态类型、业务类型
        this.tempOrderStatus = this.orderDetailData.tempOrderStatus;
        this.tempBusinessType = this.orderDetailData.tempBusinessType;
        if (this.tempOrderStatus == 'checked') {
            this.showOrderDetail = true;
            this.showAddressInfo = true;
        }

        // 初始化选择默认物流状态 --- 物流状态默认不选
        // this.chooseDeliveryType('1')

        // 当为重新上传资料时回显上次选择的物流类型
        if (this.orderDetailData.orderStatus === '34') {
            this.chooseDeliveryType(this.orderDetailData.logisticsType);

            if (typeof this.orderDetailData.goodsEvidence === 'string' && this.orderDetailData.goodsEvidence !== '') {
                this.goodsEvidence = JSON.parse(this.orderDetailData.goodsEvidence);

                this.goodsEvidenceErrorStatus = !this.goodsEvidence.every(item => {

                    return Array.isArray(item.checkResultArray) && (item.checkResultArray.length === 0 || (item.checkResultArray.length === 1 && item.checkResultArray[0] === '100'));
                });
            }

            if (typeof this.orderDetailData.distributionEvidence === 'string' && this.orderDetailData.distributionEvidence !== '') {
                this.deliveryOrder = JSON.parse(this.orderDetailData.distributionEvidence).filter(item => {
                    return item.picType === '1';
                });

                this.deliveryAddress = JSON.parse(this.orderDetailData.distributionEvidence).filter(item => {
                    return item.picType === '2';
                });

                this.distributionEvidence = JSON.parse(this.orderDetailData.distributionEvidence);

                this.distributionEvidenceErrorStatus = !this.distributionEvidence.every(item => {

                    return Array.isArray(item.checkResultArray) && (item.checkResultArray.length === 0 || (item.checkResultArray.length === 1 && item.checkResultArray[0] === '110'));
                });
            }
        }

        this.events.subscribe('upload:img-src', url => {
            this.base64Img = url;
        });

        // 这里不判断状态
        // 订单详情请求数据中，如果有发票图片信息则回显。
        // @warn 这里回显发票图片要设置条件，防止手机通讯重新提交34状态未提交直接登记。
        if (this.orderDetailData.orderStatus !== '34') {
            if (typeof this.orderDetailData.orderEvidenceInvoice === 'string' && this.orderDetailData.orderEvidenceInvoice !== '') {
                this.invoiceUrl = JSON.parse(this.orderDetailData.orderEvidenceInvoice)[0].cloudUrl;
            }
        }

        // 订单详情请求数据中，有物流情况下图片信息回显。
        if (typeof this.orderDetailData.goodsEvidence === 'string' && this.orderDetailData.goodsEvidence !== '') {
            this.goodsEvidenceArr = JSON.parse(this.orderDetailData.goodsEvidence);
        }

        if (typeof this.orderDetailData.distributionEvidence === 'string' && this.orderDetailData.distributionEvidence !== '') {
            let distributionEvidenceArr = JSON.parse(this.orderDetailData.distributionEvidence);

            distributionEvidenceArr.forEach((item) => {
                if (item.picType === '1') {
                    this.distributionEvidence1Arr.push(item);
                } else if (item.picType === '2') {
                    this.distributionEvidence2Arr.push(item);
                }
            });
        }

        //变更上传状态，并在上传成功的情况下获取图片信息
        this.events.subscribe('upload:change-step', (step, id?, token?, imgId?) => {
            if (id != 'invoice-photo') { return }
            this.uploadStep = step;
            this.invoiceUrl = token.iobsCloudUrl;
            this.invoiceImgId = imgId;
        })
        //获取物流照片数组
        this.events.subscribe('get:deliveryPhotoData', (step, goodsEvidence, deliveryOrder, deliveryAddress) => {

            if (goodsEvidence.length > 0) {
                this.goodsEvidence = [];
                this.goodsEvidence = goodsEvidence;
                // this.goodsEvidenceArr = goodsEvidence;
            }

            if (deliveryOrder.length > 0 || deliveryAddress.length > 0) {
                this.distributionEvidence = [];
            }

            if (deliveryOrder.length > 0) {
                this.deliveryOrder = deliveryOrder;
                // this.distributionEvidence1Arr = deliveryOrder;
                this.deliveryOrder.map(item => {
                    this.distributionEvidence.push(item)
                })
            }
            if (deliveryAddress.length > 0 && this.deliveryType == '1') {
                this.deliveryAddress = deliveryAddress;
                // this.distributionEvidence2Arr = deliveryAddress;
                this.deliveryAddress.map(item => {
                    this.distributionEvidence.push(item)
                })
            }

            this.goodsEvidenceErrorStatus = !this.goodsEvidence.every(item => {

                return Array.isArray(item.checkResultArray) && (item.checkResultArray.length === 0 || (item.checkResultArray.length === 1 && item.checkResultArray[0] === '100'));
            });

            this.distributionEvidenceErrorStatus = !this.distributionEvidence.every(item => {

                return Array.isArray(item.checkResultArray) && (item.checkResultArray.length === 0 || (item.checkResultArray.length === 1 && item.checkResultArray[0] === '110'));
            });
        })
        //获取经纬度信息
        this.events.subscribe('get:addressLocation', (latitude, longitude) => {
            this.actualDeliveryAddressLatitude = latitude;
            this.actualDeliveryAddressLongitude = longitude;
        })
    }

    ionViewWillEnter() {
        //设置倒计时限制时间，物流时间默认为自有物流
        let orderLimitTime: number = 0;

        // 是否有物流
        if (this.orderDetailData.orderStatus === '31' || this.orderDetailData.orderStatus === '34') {
            if (this.goodsLogistics === '1') {
                // 家电有物流
                if (this.deliveryType === '1') {
                    // 自有物流
                    orderLimitTime = this.deliverySelfLimitTime;
                } else if (this.deliveryType === '2') {
                    // 第三方物流
                    orderLimitTime = this.deliveryOtherLimitTime;
                } else {
                    // 未选择物流方式
                    orderLimitTime = this.deliverySelfLimitTime;
                }
            } else {
                // 家电无物流    手机无物流
                orderLimitTime = this.invoiceLimitTime;
            }
        } else if (this.orderDetailData.orderStatus === '701' || this.orderDetailData.orderStatus === '702' || this.orderDetailData.orderStatus === '703' || this.orderDetailData.orderStatus === '704') {
            orderLimitTime = 24;
        }


        // orderLimitTime = this.goodsLogistics ? this.deliverySelfLimitTime : this.invoiceLimitTime
        //如果是待处理状态的订单，需要判断是否超时
        if (this.tempOrderStatus == 'unChecked') {
            this.setOrderLimitTime(orderLimitTime)
        }
    }

    //接收子集传递的smsId
    public getSmsId(smsId: string) {
        this.smsId = smsId;
    }
    //进入照片上传页面
    public goUploadPhotoPage(photoType: string) {
        if (this.deliveryType === '1' || this.deliveryType === '2') {

            console.log(this.goodsEvidence);
            console.log(this.deliveryOrder);
            console.log(this.deliveryAddress);

            this.navCtrl.push(UploadDeliveryPhotoPage, {
                deliveryType: this.deliveryType,
                photoType: photoType,
                goodsEvidence: this.goodsEvidence,
                deliveryOrder: this.deliveryOrder,
                deliveryAddress: this.deliveryAddress
            });
        } else {
            this.toolService.showAlert('请进行物流信息选择')
        }
    }
    //转换是否展开详情
    public changeBoolean(flag: string): void {
        if (flag == 'address') {
            this.showAddressInfo = !this.showAddressInfo;
        } else {
            this.showOrderDetail = !this.showOrderDetail;
        }
    }
    //转换自有物流 or 第三方物流
    public chooseDeliveryType(type: string): void {
        // console.log(this.deliveryType)
        //如果取消选择，将状态设置成特殊的取消状态（因为ionic2）
        if (type == this.deliveryType) {
            if (type == '1') {
                this.deliveryType = '10';
            } else {
                this.deliveryType = '20';
                // 当选择第三方物流取消后，更新提示信息和倒计时
                this.toolService.clearTimeArray();
                this.setOrderLimitTime(this.deliverySelfLimitTime)
            }
            console.warn(`当前物流状态：${this.deliveryType}`)
            return
        }
        //重置超时及提交按钮状态（未超时 and 允许提交）
        this.isOverTime = false;
        this.checkinDisable = false;

        let orderLimitTime: number = 0
        this.deliveryType = type;
        if (this.deliveryType == '1') {
            orderLimitTime = this.deliverySelfLimitTime;
        } else if (this.deliveryType == '2') {
            orderLimitTime = this.deliveryOtherLimitTime;
        } else if (this.deliveryType === '10' || this.deliveryType === '20') {
            orderLimitTime = this.deliverySelfLimitTime;
        }
        this.toolService.clearTimeArray();
        this.setOrderLimitTime(orderLimitTime)
        console.warn(`当前物流状态：${this.deliveryType}`)
    }

    public checkin() {
        //字段验证
        if (!this.validatorService.checkGoodsNo(this.goodsNo, '商品串号')) { return };
        if (!this.validatorService.checkPhone(this.phoneNumber, '合约机号')) { return };
        if (!this.validatorService.checkValidationCode(this.validationCode, '验证码')) { return };
        if (!ConfigService.getConfig('devMode')) {
            let param: any = {
                url: ApiUrlService.getApiUrl('clerkCheckInOrder'),
                params: {
                    orderNo: this.orderDetailData.orderId,
                    goodsSerialNo: this.goodsNo,
                    contractPhoneNo: this.phoneNumber,
                    identifyCode: this.validationCode,
                    smsId: this.smsId
                }
            }
            this.httpService.post(param)
                .then(res => {
                    this.navCtrl.pop();
                }).catch(err => {
                    this.httpService.handleErr(err, this.navCtrl)
                })
        } else {
            this.navCtrl.pop();
        }
    }

    public showAlert() {
        // 手机通讯裸机分期，没有套餐id不显示合约号码，不判断合约号码
        if (this.orderDetailData.goodsPlanId === '') {
            this.flsCheckin()
        } else {
            if (!this.validatorService.checkPhone(this.contractPhone, '合约号码')) { return };
            let alert = this.alertCtrl.create({
                title: '平安租赁',
                subTitle: `该合约号码非常重要，平安租赁将对该手机号进行话费充值，请您再次确认:${this.contractPhone}`,
                buttons: [
                    {
                        text: '修改',
                    },
                    {
                        text: '确认',
                        handler: () => {
                            this.flsCheckin()
                        }
                    }
                ]
            });
            alert.present();
        }
        // this.toolService.showCustomAlert('平安租赁', `该合约号码非常重要，平安租赁将对该手机号进行话费充值，请您再次确认:${this.contractPhone}`, '修改', null, '确认', this.flsCheckin)
    }

    public flsCheckin() {
        //字段验证
        if (!this.validatorService.checkGoodsNo(this.goodsNo, '商品串号')) { return };
        if (!this.validatorService.checkInvoiceNumber(this.invoiceNumber, '发票号码')) { return };
        if (this.orderDetailData.goodsPlanId !== '') {
            if (!this.validatorService.checkPhone(this.contractPhone, '合约号码')) { return };
        }
        if (!this.invoiceUrl) { this.toolService.showAlert('请上传发票照片'); return }

        //生成发票照片数组
        let invoiceArray: any[] = []
        let invoicePicObj: any = {
            picId: Date.now().toString(),
            picType: "1",
            picName: "发票信息",
            cloudKey: this.invoiceImgId,
            cloudUrl: this.invoiceUrl,
            mIsCheck: false,
            checkResult: false,
            checkResultArray: [],
            otherContent: ""
        };
        invoiceArray.push(invoicePicObj)

        //发送请求
        if (!ConfigService.getConfig('devMode')) {
            let param: any = {
                url: ApiUrlService.getApiUrl('stageClerkCheckInOrder'),
                params: {
                    storeUserId: this.connectService.getData('loginStatus').storeUserId,
                    orderId: this.orderDetailData.orderId,
                    userId: this.orderDetailData.userId,
                    orderDeviceCode: this.goodsNo,
                    orderStoreUserInvoiceNumber: this.invoiceNumber,
                    orderInvoicePic: JSON.stringify(invoiceArray),
                    orderContractNumber: this.contractPhone
                }
            }
            this.httpService.post(param)
                .then(res => {
                    this.toolService.clearTimeArray()
                    this.toolService.showAlert('登记成功')
                    this.navCtrl.pop();
                })
                .catch(err => {
                    this.httpService.handleErr(err, this.navCtrl)
                })
        } else {
            this.navCtrl.pop();
        }
    }

    public applianceCheckin() {

        let invoiceArray: any[] = []
        //字段验证
        if (!this.validatorService.checkGoodsNo(this.goodsNo, '商品串号')) { return };
        if (!this.validatorService.checkInvoiceNumber(this.invoiceNumber, '发票号码')) { return };

        if (this.goodsLogistics === '0' || !this.goodsLogistics) {
            if (!this.invoiceUrl) { this.toolService.showAlert('请上传发票照片'); return }

            //生成发票照片数组
            let invoicePicObj: any = {
                picId: Date.now().toString(),
                picType: "1",
                picName: "发票信息",
                cloudKey: this.invoiceImgId,
                cloudUrl: this.invoiceUrl,
                mIsCheck: false,
                checkResult: false,
                checkResultArray: [],
                otherContent: ""
            };
            invoiceArray.push(invoicePicObj);
        }

        if (this.goodsLogistics === '1') {
            if (!this.deliveryType || (this.deliveryType != '1' && this.deliveryType != '2')) {
                this.toolService.showAlert('请进行物流信息选择'); return
            }

            if (this.deliveryType === '1') {
                if (this.goodsEvidence.length == 0) {
                    this.toolService.showAlert('请按要求上传商品证明材料')
                    return
                }
                if (this.deliveryOrder.length == 0) {
                    this.toolService.showAlert('请按要求上传配送证明材料')
                    return
                }
                if (this.deliveryAddress.length == 0) {
                    this.toolService.showAlert('请按要求上传配送证明材料')
                    return
                }
            } else if (this.deliveryType === '2') {
                if (this.goodsEvidence.length == 0) {
                    this.toolService.showAlert('请按要求上传商品证明材料')
                    return
                }
                if (this.deliveryOrder.length == 0) {
                    this.toolService.showAlert('请按要求上传配送证明材料')
                    return
                }
            }
        }

        if (this.goodsEvidenceErrorStatus === true) {
            this.toolService.showAlert('请按要求上传商品证明材料');
            return;
        }
        if (this.distributionEvidenceErrorStatus === true) {
            this.toolService.showAlert('请按要求上传配送证明材料');
            return;
        }

        let param = {
            url: ApiUrlService.getApiUrl('applianceClerkCheckInOrder'),
            params: {
                orderId: this.orderDetailData.orderId,
                userId: this.orderDetailData.userId,
                orderDeviceCode: this.goodsNo,
                orderStoreUserInvoiceNumber: this.invoiceNumber,
                orderInvoicePic: JSON.stringify(invoiceArray),
                goodsEvidence: JSON.stringify(this.goodsEvidence),
                distributionEvidence: JSON.stringify(this.distributionEvidence),
                logisticsType: this.deliveryType,
                actualDeliveryAddressLatitude: this.actualDeliveryAddressLatitude,
                actualDeliveryAddressLongitude: this.actualDeliveryAddressLongitude
            }
        }
        this.httpService.post(param)
            .then(res => {
                this.toolService.clearTimeArray()
                this.toolService.showAlert('登记成功')
                this.navCtrl.pop();
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl);
            })

    }

    //上传发票照片
    public uploadPhoto() {
        //如果已经有上传完毕的照片，则不允许重新上传
        // if (this.uploadStep == 'loaded') { return }
        //获取canvas对象
        let canvas = this.ele.nativeElement.querySelector('canvas');
        //调用actionSheet弹出层
        let actionSheet = this.actionSheetCtrl.create({
            title: '选择上传方式',
            buttons: [
                {
                    text: '拍摄',
                    role: 'destructive',
                    handler: () => {
                        this.uploadStep = 'loading'
                        this.uploadService.takePicture('invoice-photo', canvas)
                    }
                }, {
                    text: '从相册选择',
                    role: 'destructive',
                    handler: () => {
                        this.uploadStep = 'loading'
                        this.uploadService.choosePicture('invoice-photo', canvas)
                    }
                }, {
                    text: '取消',
                    role: 'cancel',
                    handler: () => {
                        console.log('取消上传');
                    }
                }
            ]
        });
        actionSheet.present();
    }

    //发票照片预览
    public photoPreView(url: string): void {
        if (url) {
            this.uploadService.PhotoViewer(url)
        } else {
            this.toolService.showAlert('请上传发票照片')
        }

    }

    //获取、设置倒计时 && 启动定时器
    public setOrderLimitTime(limitTime: number) {
        this.isOverTime = false;
        let orderStateChangeTime: any

        let startTime = () => {
            this.toolService.clearTimeArray();
            let timer = setInterval(() => {
                getOrderLeftTime()
            }, 300);
            this.connectService.commonData.timeIntervalArray.push(timer);
        }

        if (!this.orderDetailData.orderDetailStateChangeTime) {
            orderStateChangeTime = new Date(this.orderDetailData.orderStateChangeTime.substring(0, 19).replace(/-/g, '/'))
        } else if ((this.orderDetailData.orderStatusName != '申请取消' || this.orderDetailData.orderStatusName != '申请退款') && this.orderDetailData.orderDetailStateChangeTime) {
            orderStateChangeTime = new Date(this.orderDetailData.orderDetailStateChangeTime.substring(0, 19).replace(/-/g, '/'))
        }
        orderStateChangeTime = Date.parse(orderStateChangeTime)
        startTime();

        //更新页面展示时间
        let setOverTime = () => {
            this.day = "0"
            this.hours = "00"
            this.minutes = "00";
            this.seconds = "00";
        }

        // let changeOrderStatusSuccess = (data) => {
        // Datas.Orders = eval("(" + data.orders + ");");;
        // //在返回按钮绑定方法，使回退至list页面时刷新页面
        // $("[data-page='5_flscheckindetails'] .navbar a").on('click', function () {
        //     clearTimer();
        //     reloadPage('index', '5', 'tab-worder');
        // })
        // console.log(Datas.Orders)

        // if (data.retType == "4") {
        //     $('#uploadBtn').attr('disabled', '').css('background', '#b3b3b3');
        //     Current.currentorder.isOverTime = true;
        //     setOrderLeftTime("order-left-hour", "00", "order-left-min", "00", "order-left-sec", "00")
        //     $("#time-left").hide();
        //     $("#orderMsg").text("很抱歉，您的订单操作超时，请及时与客户沟通处理").css("text-align", "center")
        //     myApp.alert("很抱歉，您的订单操作超时，请及时与客户沟通处理")
        // }
        // }

        //发送请求，更改订单状态
        let changeOrderStatus = () => {

            let param: any = {
                url: ApiUrlService.getApiUrl('applianceClerkCheckInOrderTimeOut'),
                params: {
                    // storeUserId: this.connectService.getData('loginStatus').storeUserId,
                    orderId: this.orderDetailData.orderId,
                    userId: this.orderDetailData.userId,
                    goodsLogistics: this.goodsLogistics
                }
            }
            this.httpService.post(param)
                .then(res => {
                    console.log(res)
                    // this.toolService.clearTimeArray();
                    // this.toolService.showAlert('很抱歉，您的订单操作超时，请及时与客户沟通处理')

                    if (res.retType == '0') {
                        this.toolService.clearTimeArray();
                        this.toolService.showAlert('很抱歉，您的订单操作超时，请及时与客户沟通处理')
                    } else if (res.retType == '1') {
                        this.checkinDisable = false;
                        this.isOverTime = false;
                        if (this.deliveryType == "1") {
                            this.selfDisable = false;  //自有物流允许
                            this.otherDisable = false;  //第三方物流物流允许
                            this.deliveryType = '1';  //消除当前选择物流
                        } else {
                            this.otherDisable = false;  //第三方物流物流禁止
                            this.deliveryType = '2'
                            // this.chooseDeliveryType('1')
                        }
                    }
                })
                .catch(err => {
                    this.httpService.handleErr(err, this.navCtrl)
                })
        }

        let getOrderLeftTime = () => {
            //进入工单直接超时的处理
            let orderLimitTime = limitTime * 60 * 60 * 1000  //限制24小时
            let nowTime = new Date().getTime();  //获取当前时间
            let deltaTime = (nowTime - 0.005 * 60 * 60 * 1000) - orderStateChangeTime;  //获取时间差

            if (deltaTime > (orderLimitTime)) {  //超时情况
                this.checkinDisable = true;
                this.isOverTime = true;
                if (this.orderDetailData.goodsLogistics == '1') {
                    if (this.deliveryType == "1") {
                        this.selfDisable = true;  //自有物流禁止
                        this.otherDisable = true;  //第三方物流物流禁止
                        this.deliveryType = '';  //消除当前选择物流
                    } else {
                        this.otherDisable = true;  //第三方物流物流禁止
                        // this.deliveryType = '1'
                        this.chooseDeliveryType('1')
                        return
                    }
                }
                this.toolService.clearTimeArray()
                setOverTime()
                if (this.orderDetailData.orderStatusName != '申请取消' && this.orderDetailData.orderStatusName != '申请退款') {
                    changeOrderStatus()
                }

            } else {  //不超时情况
                let orderLeftTime = orderLimitTime - deltaTime;  //计算剩余时间

                let int_day: any = "0";
                let int_hour: any = "0";
                let int_minute: any = "0";
                let int_second: any = "0";

                if (orderLeftTime >= 86400000) {
                    int_day = Math.floor(orderLeftTime / 86400000)
                    orderLeftTime -= int_day * 86400000;
                }
                if (orderLeftTime >= 3600000) {
                    int_hour = Math.floor(orderLeftTime / 3600000)
                    orderLeftTime -= int_hour * 3600000;
                }
                if (orderLeftTime >= 60000) {
                    int_minute = Math.floor(orderLeftTime / 60000)
                    orderLeftTime -= int_minute * 60000;
                }
                if (orderLeftTime >= 1000) {
                    int_second = Math.floor(orderLeftTime / 1000)
                }

                if (int_hour < 10) {
                    int_hour = "0" + int_hour;
                }
                if (int_minute < 10) {
                    int_minute = "0" + int_minute;
                }
                if (int_second < 10) {
                    int_second = "0" + int_second;
                }

                // let str_time = int_day + "小时" + int_hour + "小时" + int_minute + "分" + int_second + "秒";

                // console.log("详情登记剩余时间:" + str_time)

                this.day = int_day;
                this.hours = int_hour;
                this.minutes = int_minute;
                this.seconds = int_second;
                //定时器自动走到超时的处理
                if (int_minute == 0 && int_second == 0) {
                    this.checkinDisable = true;
                    this.isOverTime = true;
                    if (this.orderDetailData.goodsLogistics == '1') {
                        if (this.deliveryType == "1") {
                            this.selfDisable = true;  //自有物流禁止
                            this.otherDisable = true;  //第三方物流物流禁止
                            this.deliveryType = '';  //消除当前选择物流
                        } else {
                            this.otherDisable = true;  //第三方物流物流禁止
                            // this.deliveryType = '1'
                            this.chooseDeliveryType('1')
                            return
                        }
                    }
                    this.toolService.clearTimeArray()
                    setOverTime()
                    if (this.orderDetailData.orderStatusName != '申请取消' && this.orderDetailData.orderStatusName != '申请退款') {
                        changeOrderStatus()
                    }
                    // return;
                }
            }
        }
    }

    public showRefund(type: string): void {
        let alert = this.alertCtrl.create();

        if (type == 'refuse') {
            if (this.orderDetailData.orderStatusName == '申请取消') {
                alert.setMessage('确认不允许客户取消订单？');
            } else {
                alert.setMessage('确认不允许系统退款？');
            }
            alert.addInput({ type: 'text', placeholder: '请输入拒绝原因' });
            alert.setCssClass('refund-alert')
        } else if (type == 'agree') {
            if (this.orderDetailData.orderStatusName == '申请取消') {
                alert.setMessage('确认同意客户取消订单？允许客户取消订单，系统将进行自动退款');
            } else {
                alert.setMessage('确认允许系统进行退款？');
            }
        }

        alert.addButton('取消');
        alert.addButton({
            text: '确认',
            handler: data => {
                //获取输入的拒绝原因
                this.refundReason = data[0];
                if (type == 'refuse' && this.refundReason == '') {
                    this.toolService.showAlert('请输入拒绝原因')
                    return false;
                }
                //发送请求
                let param: any;

                param = {
                    url: ApiUrlService.getApiUrl('reimburseCheck'),
                    params: {
                        orderId: this.orderDetailData.orderId,
                        userId: this.orderDetailData.userId,
                        checkResult: type == 'refuse' ? false : true,
                        rejectReason: type == 'refuse' ? this.refundReason : '', //店员拒绝退款原因
                        oldOrderStatus: this.orderDetailData.orderStatus
                    }
                }

                this.httpService.post(param)
                    .then(res => {
                        this.navCtrl.pop()
                    })
                    .catch(err => {
                        this.httpService.handleErr(err, this.navCtrl)
                    })
            }
        });

        alert.present();
    }
}
