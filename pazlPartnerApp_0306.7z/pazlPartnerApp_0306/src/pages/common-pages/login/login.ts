//框架自带
import { Component } from '@angular/core';
import { NavController, ViewController, Events, ModalController, App, LoadingController, Platform, AlertController } from 'ionic-angular';
import { HttpService } from '../../../providers/http-service'
import { Storage } from '@ionic/storage';
import { BrowserTab } from '@ionic-native/browser-tab';

//自定义组件
import { ShopAssistantTabsPage } from '../../shop-assistant/shopassistant-tabs/shop-assistant-tabs';
import { SupplierManagerTabsPage } from '../../supplier-manager/supplier-manager-tabs/supplier-manager-tabs';
import { ConnectService } from '../../../providers/connect-service';
import { OperatorManagerTabsPage } from '../../operator-manager/operator-manager-tabs/operator-manager-tabs';
import { FindPwdPage } from '../find-pwd/find-pwd';
import { RegisterPage } from '../register/register';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';
import { ValidatorService } from '../../../providers/validator-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { TestdataService } from '../../../providers/testdata-service';

declare let cordova: any;

@Component({
    selector: 'page-login',
    templateUrl: './login.html',
    providers: [HttpService]
})
export class LoginPage {
    private userName: string = '';
    private userPwd: string = '';
    private tabPage: any;
    public findPwdPage: any = FindPwdPage;
    public registerPage: any = RegisterPage;

    constructor(
        private navCtrl: NavController,
        private httpService: HttpService,
        private viewCtrl: ViewController,
        private modalCtrl: ModalController,
        private events: Events,
        private storage: Storage,
        private appCtrl: App,
        private connectService: ConnectService,
        private toolService: ToolService,
        private loadingCtrl: LoadingController,
        private validatorService: ValidatorService,
        private testdataService: TestdataService,
        private plt: Platform,
        private browserTab: BrowserTab,
        private alertCtrl: AlertController
    ) { }


    ionViewDidLoad() {
        // console.log(this.navCtrl.getActive().name)
        // console.log(ApiUrlService.getApiUrl('login'))
        localStorage.setItem('partnerVersion', JSON.stringify(ConfigService.getConfig('partnerVersion')));
        if (!ConfigService.getConfig('devMode')) {
            this.checkVersion()
        }
    }

    //登陆方法
    public login() {
        // this.userName = 'heru51';
        // this.userPwd = 'heruadmin';
        // this.userName = '20170420';
        // this.userPwd = '111111';

        //字段校验
        if (!this.validatorService.checkUserName(this.userName, '账号')) { return }
        // if (!this.validatorService.checkPwd(this.userPwd, '密码')) { return }

        //设置请求参数
        let param: any = {
            url: ApiUrlService.getApiUrl('login'),
            accountId: this.userName,
            params: {
                accountName: this.userName,
                accountPwd: this.toolService.encryptByMd5(this.userPwd),
                appName: 'APP_PARTNER'
            }
        }
        // if (!ConfigService.getConfig('devMode')) {
        //发送请求
        this.httpService.post(param, '', false, true)
            .then(res => {  //第一次请求获取登陆状态
                let loginData: any = res;
                this.connectService.saveData('loginInfo', loginData)
                console.warn('获取登录信息成功')
                console.log(loginData)
                //根据获取到的店员身份，转跳不同的模块
                if (loginData.userType == '2') {  //店员
                    this.tabPage = ShopAssistantTabsPage;
                } else if (loginData.userType == '3') {  //运营商管理员
                    this.tabPage = OperatorManagerTabsPage;
                } else if (loginData.userType == '4') {  //供应商管理员
                    this.tabPage = SupplierManagerTabsPage;
                }
                return Promise.resolve();
            })
            .then(() => {  //第二次请求获取用户信息
                let param = {
                    url: ApiUrlService.getApiUrl('getStoreUserInfo')
                }
                return this.httpService.post(param, '', true, false);
            })
            .then(res => {
                console.log(res)
                let loginData = res;
                //将登录信息存储入connectService服务
                this.connectService.saveData('loginStatus', loginData);
                //重新指定root组件
                this.navCtrl.setRoot(this.tabPage)
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl);
            })
        // } else {
        //     //将登录信息存储入connectService服务
        //     this.connectService.saveData('loginStatus', this.testdataService.qrCodeList.data);
        //     this.navCtrl.push(ShopAssistantTabsPage);
        // }
    }

    //检查版本信息
    private checkVersion() {
        let partnerVersion = JSON.parse(localStorage.getItem('partnerVersion'));
        let param = {
            url: ApiUrlService.getApiUrl('checkVersion'),
            appVersion: partnerVersion.appVersionCode || '',
            apiVersion: partnerVersion.apiVersion || '',
            accountRole: '2',
            params: {
                appName: 'APP_PARTNER',
                deviceType: this.toolService.getDeviceType(),
                appVersionName: '未定义',
                appVersionCode: partnerVersion.appVersionCode
            }
        }
        this.httpService.post(param)
            .then(res => {
                if (res.appVersionCode > partnerVersion.appVersionCode) {
                    // 如果是IOS设备，对更新有特殊要求
                    if (this.toolService.getDeviceType() === 'IOS') {
                        // 是否可以提示
                        if (res.appIsPromptUser) {
                            this.updateVersion(res);
                        }
                    } else {
                        this.updateVersion(res);
                    }
                }
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl);
            })
    }

    //转跳app下载页面
    private updateVersion(res) {
        let goUpdatePage = (res) => {
            this.browserTab.isAvailable()
                .then((isAvailable: boolean) => {
                    if (isAvailable) {
                        this.browserTab.openUrl(res.appDownloadUrl);
                    } else {
                        cordova.InAppBrowser.open(res.appDownloadUrl);
                    }
                });
            console.log(`跳转至：${res.appDownloadUrl}`)
        }
        // 判断是否强制更新
        if (res.appIsForceUpdate) {
            // this.toolService.showCustomAlert(res.appVersionTitle, res.appVersionMsg, '确定', goUpdatePage)
            this.alertCtrl.create({
                title: res.appVersionTitle,
                subTitle: res.appVersionMsg,
                buttons: [
                    {
                        text: '确定',
                        handler: goUpdatePage
                    }
                ]
            })
        } else {
            // this.toolService.showCustomAlert(res.appVersionTitle, res.appVersionMsg, '取消', null, '确定', goUpdatePage)
            this.alertCtrl.create({
                title: res.appVersionTitle,
                subTitle: res.appVersionMsg,
                buttons: [
                    {
                        text: '取消'
                    },
                    {
                        text: '确定',
                        handler: goUpdatePage
                    }
                ]
            })
        }
    }
}
