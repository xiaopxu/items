import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HttpService } from '../../../providers/http-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { ToolService } from '../../../providers/tool-service';

@Component({
    selector: 'page-change-pwd',
    templateUrl: 'change-pwd.html'
})
export class ChangePwdPage {
    oldPwd: any;
    newPwd: any;
    conformPwd: any;
    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        private httpService: HttpService,
        private toolService: ToolService
    ) { }

    ionViewDidLoad() {
        console.log('ionViewDidLoad ChangePwdPage');
    }
    changePwd() {
        console.log(this.oldPwd + ".." + this.newPwd + "--" + this.conformPwd);
        if (this.newPwd != this.conformPwd) { this.toolService.showAlert('新密码不一致'); return }
        let param = {
            url: ApiUrlService.getApiUrl('updatePwd'),
            params: {
                oldPwd: this.toolService.encryptByMd5(this.oldPwd),
                newPwd: this.toolService.encryptByMd5(this.newPwd)
            }
        }
        this.httpService.post(param)
            .then(res => {
                this.toolService.showAlert('密码修改成功');
                this.navCtrl.pop();
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl)
            })
    }

}
