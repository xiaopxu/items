import { Component, ElementRef } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';
import { ApiUrlService } from '../../../providers/api-url-service';
import { ToolService } from '../../../providers/tool-service';
import { ValidatorService } from '../../../providers/validator-service';
import { HttpService } from '../../../providers/http-service';
import { ConnectService } from '../../../providers/connect-service';

@Component({
    selector: 'page-check-clerk-detail',
    templateUrl: 'check-clerk-detail.html'
})
export class CheckClerkDetailPage {

    private pageSize: number = 100;
    private pageNumber: number = 0;
    private newClerkList: any[] = [];
    private storeExist: string[] = [];  //已存在的时间分类（缓存）
    private displayClerks: any = [];  //经过时间分类处理的订单数据（缓存）
    private checkedList: any[] = [];
    private checkedListByStore: any[] = [];
    private isAllChecked: boolean = false;

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private toolService: ToolService,
        private validatorService: ValidatorService,
        private events: Events,
        private ele: ElementRef,
        private httpService: HttpService,
        private connectService: ConnectService
    ) { }

    ionViewDidLoad() {
        console.warn('========================进入供应商管理员-店员-新店员审核页面============================')
    }

    ionViewWillEnter() {
        this.clearClerkList();
        this.getkNewClerkList();

        this.events.subscribe('getClerksByStoreComplete', (storeExist, displayClerks) => {
            this.storeExist = storeExist;
            this.displayClerks = displayClerks;
        })
    }

    /**
         * @description 上拉加载方法
         * @param {*} infiniteScroll infiniteScroll实例
         * @returns {void}
         * @memberOf ShopAssistantWorkOrdersPage
         * @author xjn
         * @date 2017年3月27日
         */
    // public doInfinite(infiniteScroll: any): void {

    //     this.getkNewClerkList(infiniteScroll) //获取订单

    //     //如果获取到的订单数量少于pageSize，则使上拉加载不可用
    //     if (this.newClerkList.length < this.pageSize) {
    //         infiniteScroll.enable(false);
    //         return
    //     }

    //     this.pageNumber++;
    // }

    /**
     * @description 下拉刷新方法
     * @param {*} refresher refresher实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    // public doRefresh(refresher: any): void {
    //     this.pageNumber = 0;
    //     this.clearClerkList()
    //     this.getkNewClerkList(refresher)  //获取订单
    // }


    public getkNewClerkList(ionEvent?: any) {
        let param = {
            url: ApiUrlService.getApiUrl('getUncheckClerks'),
            params: {
                pageSize: this.pageSize,
                pageNumber: this.pageNumber
            }
        }
        this.httpService.post(param, ionEvent)
            .then(res => {
                this.newClerkList = res.list;
                this.clearClerkList();
                this.handleDisplayClerks(this.newClerkList);
                if (ionEvent) {
                    ionEvent.complete()
                }
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl)
            })
    }

    private handleDisplayClerks(newClerkList: any[]): void {

        this.toolService.setClerksByStore(newClerkList)

        console.warn('待审核店员刷新完毕')
        console.log(this.displayClerks)
    }

    private clearClerkList() {
        this.connectService.commonData.storeExist = [];
        this.connectService.commonData.displayClerks = [];
    }

    public chooseClerk(clerk: any, chooseType?: string, store?: any): void {
        clerk.checked = clerk.checked ? false : true;
        console.log(clerk.checked)
        this.getCheckedOrder(clerk)
        if (this.getCheckedCount('clerkInAll') == this.newClerkList.length) {
            this.isAllChecked = true;
        } else {
            this.isAllChecked = false;
        }
        if (store) {
            if (this.getCheckedCount('clerkInStore', store) == store.clerks.length) {
                store.checked = true;
            } else {
                store.checked = false;
            }
        }

    }

    public chooseStore(store) {
        store.checked = store.checked ? false : true;
        console.log(`门店选择：${store.storeName}/$(store.chedked)`)
        store.clerks.forEach(clerk => {
            if (store.checked) {
                clerk.checked = true;
            } else {
                clerk.checked = false;
            }
            this.getCheckedOrder(clerk)
        })

        if (this.getCheckedCount('storeInAll') == this.displayClerks.length) {
            this.isAllChecked = true;
        } else {
            this.isAllChecked = false;
        }

    }

    public chooseAll(): void {
        this.isAllChecked = this.isAllChecked ? false : true;
        this.newClerkList.forEach(clerk => {
            if (this.isAllChecked) {
                clerk.checked = true;
            } else {
                clerk.checked = false;
            }
            this.clearClerkList();
            this.handleDisplayClerks(this.newClerkList);
            this.getCheckedOrder(clerk)
        })

        this.displayClerks.map(store => {
            if (this.isAllChecked) {
                store.checked = true;
            } else {
                store.checked = false;
            }
        })

    }

    private getCheckedCount(type: string, store?: any) {
        let count: number = 0;
        if (type == 'clerkInAll' && !store) {
            this.newClerkList.map(clerk => {
                if (clerk.checked) {
                    count++
                }
            })
        } else if (type == 'clerkInStore' && store) {
            store.clerks.map(clerk => {
                if (clerk.checked) {
                    count++
                }
            })
        } else if (type == 'storeInAll' && !store) {
            this.displayClerks.map(store => {
                if (store.checked) {
                    count++
                }
            })
        }
        return count
    }

    private getCheckedOrder(clerk: any): void {
        if (clerk.checked) {
            this.addOrderId(clerk)
        } else {
            this.deleteOrderId(clerk)
        }
        console.log(this.checkedList)
    }

    private addOrderId(clerk: any): void {
        if (this.checkedList.indexOf(clerk.storeUserId) == -1) {
            this.checkedList.push(clerk.storeUserId)
        }
    }

    private deleteOrderId(clerk: any): void {
        let index = this.checkedList.indexOf(clerk.storeUserId)
        if (index > -1) {
            this.checkedList.splice(index, 1);
        }
    }

    public clerkCheck(result) {

        if (this.checkedList.length == 0) {
            this.toolService.showAlert('请选择店员');
            return
        }

        let param = {
            url: ApiUrlService.getApiUrl('clerkCheck'),
            params: {
                clerkIds: this.checkedList.join(','),
                status: result == 'pass' ? '1' : '0'
            }
        }

        console.log(param)
        this.httpService.post(param)
            .then(res => {
                this.navCtrl.pop();
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl);
            })
    }

    public clerkCheckByStore(store: any, result: string) {
        this.checkedListByStore = [];
        store.clerks.map(clerk => {
            if (clerk.checked && this.checkedListByStore.indexOf(clerk.storeUserId) == -1) {
                this.checkedListByStore.push(clerk.storeUserId);
            }
        })

        if (this.checkedListByStore.length == 0) {
            this.toolService.showAlert('请选择店员')
            return
        }

        let param = {
            url: ApiUrlService.getApiUrl('clerkCheck'),
            params: {
                clerkIds: this.checkedListByStore.join(','),
                status: result == 'pass' ? '1' : '0'
            }
        }
        console.log(param)
        this.httpService.post(param)
            .then(res => {
                this.getkNewClerkList()
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl);
            })
    }

}
