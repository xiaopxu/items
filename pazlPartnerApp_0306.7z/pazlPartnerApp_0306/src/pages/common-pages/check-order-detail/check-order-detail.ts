import { Component, ElementRef } from '@angular/core';
import { NavController, NavParams, ActionSheetController, Events } from 'ionic-angular';
import { ToolService } from '../../../providers/tool-service';
import { ValidatorService } from '../../../providers/validator-service';
import { HttpService } from '../../../providers/http-service';
import { ConnectService } from '../../../providers/connect-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { OrderListHeaderPage } from '../order-list-header/order-list-header';

@Component({
    selector: 'page-check-order-detail',
    templateUrl: 'check-order-detail.html'
})
export class CheckOrderDetailPage {

    //初始化变量
    private currentPage: string = 'checkOrderDetail';
    private businessType: string = this.connectService.getData('loginStatus').bussinessType;
    private orderStatusType: string = '';
    private orderList: any[] = [];
    private checkedList: string[] = [];
    private isAllChecked: boolean = false;

    //构造函数（依赖注入）
    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private toolService: ToolService,
        private validatorService: ValidatorService,
        private actionSheetCtrl: ActionSheetController,
        private events: Events,
        private ele: ElementRef,
        private httpService: HttpService,
        private connectService: ConnectService
    ) { }

    ionViewDidLoad() {
        console.warn('========================进入CheckOrderDetailPage============================')
        this.orderList = this.navParams.data.orderDetail;
        this.orderStatusType = this.navParams.data.orderStatusType;
        console.warn('订单详情')
        console.log(this.orderList)
    }

    public chooseOrder(order: any, chooseType?: string): void {
        order.checked = order.checked ? false : true;
        console.log(order.checked)
        this.getCheckedOrder(order)
        if (this.getCheckedCount() == this.orderList.length) {
            this.isAllChecked = true;
        } else {
            this.isAllChecked = false;
        }
    }

    public chooseAll(): void {
        this.isAllChecked = this.isAllChecked ? false : true;
        this.orderList.forEach(order => {
            if (this.isAllChecked) {
                order.checked = true;
            } else {
                order.checked = false;
            }
            this.getCheckedOrder(order)
        })
    }

    private getCheckedCount() {
        let count: number = 0;
        this.orderList.map(order => {
            if (order.checked) {
                count++
            }
        })
        return count
    }

    private getCheckedOrder(order: any): void {
        if (order.checked) {
            this.addOrderId(order)
        } else {
            this.deleteOrderId(order)
        }
        console.log(this.checkedList)
    }

    private addOrderId(order: any): void {
        if (this.checkedList.indexOf(order.orderId) == -1) {
            this.checkedList.push(order.orderId)
        }
    }

    private deleteOrderId(order: any): void {
        let index = this.checkedList.indexOf(order.orderId)
        if (index > -1) {
            this.checkedList.splice(index, 1);
        }
    }

    public submit() {
        let url: string = '';
        if (this.businessType == '0010') {
            url = ApiUrlService.getApiUrl('ordersConfirm');
        } else if (this.businessType == '002001') {
            url = ApiUrlService.getApiUrl('stageOrdersConfirm');
        } else if (this.businessType == '002002') {
            url = ApiUrlService.getApiUrl('applianceOrdersConfirm');
        }
        let param = {
            url: url,
            params: {
                orderIds: this.checkedList.join(',')
            }
        }
        this.httpService.post(param)
            .then(res => {
                this.toolService.showAlert('验单确认成功')
                this.navCtrl.pop()
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl)
            })
    }
}
