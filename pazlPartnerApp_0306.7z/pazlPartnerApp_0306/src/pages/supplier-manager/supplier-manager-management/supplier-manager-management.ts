import { Component, ElementRef } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';
import { ToolService } from '../../../providers/tool-service';
import { ValidatorService } from '../../../providers/validator-service';
import { HttpService } from '../../../providers/http-service';
import { ConnectService } from '../../../providers/connect-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { ClerkDetailPage } from '../../common-pages/clerk-detail/clerk-detail';
import { CheckClerkDetailPage } from '../../common-pages/check-clerk-detail/check-clerk-detail';


@Component({
    selector: 'page-supplier-manager-management',
    templateUrl: 'supplier-manager-management.html'
})
export class SupplierManagerManagementPage {

    private storeList: any[] = [];
    private storeListInit: any[] = [];
    private newClerkCount: number = 0;


    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private toolService: ToolService,
        private validatorService: ValidatorService,
        private events: Events,
        private ele: ElementRef,
        private httpService: HttpService,
        private connectService: ConnectService
    ) { }

    //生命周期：页面加载完毕（只在首次加载时被调用）
    ionViewDidLoad() {
        console.warn('========================进入供应商管理员-店员页面============================')
    }

    ionViewWillEnter() {
        this.getStoreList()
    }

    public getStoreList() {
        let param = {
            url: ApiUrlService.getApiUrl('getStoresBySupplier')
        }
        this.httpService.post(param, '', false, true)
            .then(res => {
                this.storeList = res;
                this.storeListInit = res;
                return Promise.resolve()
            })
            .then(() => {
                let param = {
                    url: ApiUrlService.getApiUrl('getNewClerkCount')
                }
                return this.httpService.post(param, '', true, false)
            })
            .then(res => {
                this.newClerkCount = res;
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl)
            })
    }

    public searchStoreList(ev: any) {
        this.storeList = this.storeListInit;

        let val = ev.target.value;

        if (val && val.trim() != '') {
            this.storeList = this.storeList.filter((item) => {
                return (item.value.toLowerCase().indexOf(val.toLowerCase()) > -1);
            })
        }
    }

    public goCheckNewClerk() {
        this.navCtrl.push(CheckClerkDetailPage)
    }

    public goClerkDetail(store: any): void {
        let param = {
            url: ApiUrlService.getApiUrl('getClerksByStoreId'),
            params: {
                id: store.key
            }
        }
        this.httpService.post(param)
            .then(res => {
                this.navCtrl.push(ClerkDetailPage, { clerkDetailList: res, store: store })
            })
    }

}
