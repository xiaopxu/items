import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { SupplierManagerManagementPage } from '../supplier-manager-management/supplier-manager-management';
import { SupplierManagerCheckOrderPage } from '../supplier-manager-check-order/supplier-manager-check-order';
import { SupplierManagerAchievementPage } from '../supplier-manager-achievement/supplier-manager-achievement';
import { SupplierManagerMePage } from '../supplier-manager-me/supplier-manager-me';

/*
  Generated class for the SupplierManagerTabs page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-supplier-manager-tabs',
  templateUrl: 'supplier-manager-tabs.html'
})
export class SupplierManagerTabsPage {
  
  tab1Root: any = SupplierManagerManagementPage;
  tab2Root: any = SupplierManagerCheckOrderPage;
  tab3Root: any = SupplierManagerAchievementPage;
  tab4Root: any = SupplierManagerMePage;
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad SupplierManagerTabsPage');
  }

}
