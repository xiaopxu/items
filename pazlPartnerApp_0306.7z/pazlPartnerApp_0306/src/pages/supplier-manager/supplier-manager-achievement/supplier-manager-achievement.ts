import { Component } from '@angular/core';
import { NavController, NavParams, Events, LoadingController } from 'ionic-angular';
import { TestdataService } from '../../../providers/testdata-service';
import { ConnectService } from '../../../providers/connect-service';
import { ToolService } from '../../../providers/tool-service';
import { HttpService } from '../../../providers/http-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { AchievementDetailPage } from '../../common-pages/achievement-detail/achievement-detail';

@Component({
    selector: 'page-supplier-manager-achievement',
    templateUrl: 'supplier-manager-achievement.html'
})
export class SupplierManagerAchievementPage {

    private currentPage: string = 'achievement';
    private businessType: string = this.connectService.getData('loginStatus').bussinessType;
    private pageNumber: number = 0;
    private pageSize: number = 10;
    private achievementList: any[] = [];
    private achievementListTemp: any[] = [];

    constructor(
        private navCtrl: NavController,
        private navParam: NavParams,
        private testdataService: TestdataService,
        private events: Events,
        private connectService: ConnectService,
        private toolService: ToolService,
        private loadingCtrl: LoadingController,
        private httpService: HttpService
    ) { }

    //生命周期：页面加载完毕（只在首次加载时被调用）
    ionViewDidLoad() {
        console.warn('========================进入SupplierManagerAchievementPage============================')
    }

    ionViewWillEnter() {
        this.pageNumber = 0;
        this.achievementList = [];
        this.getAchievementLists();  //获取发展量

        if (this.connectService.getData('infiniteScroll')) {
            this.connectService.getData('infiniteScroll').enable(true);
        }
    }

    /**
     * @description 获取业绩发展量列表
     * @param {string} status 订单状态（发展量 or 佣金）
     * @param {*} ionEvent 实例对象（上拉刷新 or 下拉加载）
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    public getAchievementLists(ionEvent?: any, ionEventType?: string): void {
        let url: string = '';
        if (this.businessType == '0010') {
            url = ApiUrlService.getApiUrl('getManagerPerformance')
        } else if (this.businessType == '002001') {
            url = ApiUrlService.getApiUrl('getStageClerkPerformance')
        } else if (this.businessType == '002002') {
            url = ApiUrlService.getApiUrl('getApplianceClerkPerformance')
        }
        let param = {
            url: url,
            accountId: this.connectService.getData('loginStatus').storeUserId,
            params: {
                pageNumber: this.pageNumber,
                pageSize: this.pageSize
            }
        }

        //发送请求
        this.httpService.post(param, ionEvent)
            .then(res => {
                this.achievementListTemp = res;
                this.achievementListTemp.forEach(item => {
                    this.achievementList.push(item)
                })
                console.log(this.achievementList)
                console.log(this.currentPage)
                console.log(this.businessType)

                //关闭上拉加载、下拉刷新事件
                if (ionEvent) {
                    ionEvent.complete()
                    //如果上拉加载已经被关闭，在下拉加载后重新开启
                    if (ionEventType == 'refresher' && this.connectService.getData('infiniteScroll')) {
                        this.connectService.getData('infiniteScroll').enable(true);
                    }
                }

                //如果获取到的订单数量少于pageSize，则使上拉加载不可用
                if (ionEvent && ionEventType == 'infiniteScroll' && this.achievementListTemp.length < this.pageSize) {
                    ionEvent.enable(false);
                    this.connectService.saveData('infiniteScroll', ionEvent)
                }
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl)
            })
    }

    /**
     * @description 上拉加载方法
     * @param {*} infiniteScroll infiniteScroll实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    public doInfinite(infiniteScroll: any): void {
        // this.getAchievementLists()
        this.pageNumber++;
        this.getAchievementLists(infiniteScroll, 'infiniteScroll') //获取订单
    }

    /**
     * @description 下拉刷新方法
     * @param {*} refresher refresher实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    public doRefresh(refresher: any): void {
        this.pageNumber = 0;
        this.achievementList = [];
        this.getAchievementLists(refresher, 'refresher')  //获取订单
    }

    public goAchievementDetail(month: string): void {
        this.navCtrl.push(AchievementDetailPage, month)
    }

}
