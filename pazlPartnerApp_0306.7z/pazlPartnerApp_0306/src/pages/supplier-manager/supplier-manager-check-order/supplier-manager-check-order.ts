import { Component, ElementRef } from '@angular/core';
import { NavController, NavParams, ActionSheetController, Events } from 'ionic-angular';
import { ToolService } from '../../../providers/tool-service';
import { ValidatorService } from '../../../providers/validator-service';
import { HttpService } from '../../../providers/http-service';
import { ConnectService } from '../../../providers/connect-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { CheckOrderDetailPage } from '../../common-pages/check-order-detail/check-order-detail';
import { LoginPage } from '../../common-pages/login/login';

@Component({
    selector: 'page-supplier-manager-check-order',
    templateUrl: 'supplier-manager-check-order.html'
})
export class SupplierManagerCheckOrderPage {

    //变量初始化
    private currentPage: string = 'checkOrder';  //页面标签
    private businessType: string = this.connectService.getData('loginStatus').bussinessType;
    private orderStatusType: string = 'unChecked';  //订单状态
    private pageNumber: number = 0;
    private pageSize: number = 10;
    private orderList: any[] = []
    private orderListTemp: any[] = [];

    //构造函数（依赖注入）
    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private toolService: ToolService,
        private validatorService: ValidatorService,
        private actionSheetCtrl: ActionSheetController,
        private events: Events,
        private ele: ElementRef,
        private httpService: HttpService,
        private connectService: ConnectService
    ) { }

    //生命周期：页面加载完毕（只在首次加载时被调用）
    ionViewDidLoad() {
        console.warn('========================进入SupplierManagerCheckOrderPage============================')
    }

    ionViewWillEnter() {
        this.selectSegment(this.orderStatusType)
    }

    /**
     * @description 点击切换segment触发方法，刷新验单数据
     * @param {string} status 验单状态（已处理 or 未处理）
     * @returns {void}
     * @memberOf SupplierManagerCheckOrderPage
     * @author xjn
     * @date 2017年3月27日
     */
    public selectSegment(status: string): void {

        console.warn(`当前标签为：${status}`)
        if (status == 'commission') {
            this.toolService.showAlert('该功能暂未开放')
            return
        }
        this.orderStatusType = status;  //更新标签状态
        this.pageNumber = 0;
        this.orderList = [];
        this.getOrderCheckLists(this.orderStatusType);  //获取发展量

        if (this.connectService.getData('infiniteScroll')) {
            this.connectService.getData('infiniteScroll').enable(true);
        }
    }

    public selectSegmentDisable() {
        this.toolService.showAlert('该功能暂未开放')
        return
    }

    /**
     * @description 获取验单列表
     * @param {string} status 验单状态（未完成 or 已完成）
     * @param {*} ionEvent 实例对象（上拉刷新 or 下拉加载）
     * @returns {void}
     * @memberOf SupplierManagerCheckOrderPage
     * @author xjn
     * @date 2017年3月30日
     */
    public getOrderCheckLists(status: string, ionEventType?: string, ionEvent?: any): void {
        let url: string = '';
        if (this.businessType == '0010') {
            url = ApiUrlService.getApiUrl('getOrdersConfirm');
        } else if (this.businessType == '002001') {
            url = ApiUrlService.getApiUrl('getStageOrdersConfirm');
        } else if (this.businessType == '002002') {
            url = ApiUrlService.getApiUrl('getApplianceOrdersConfirm');
        }
        let param = {
            url: url,
            accountId: this.connectService.getData('loginStatus').storeUserId,
            params: {
                pageNumber: this.pageNumber,
                pageSize: this.pageSize,
                type: status == 'unChecked' ? '0' : '1'
            }
        }
        //发送请求
        this.httpService.post(param, ionEvent)
            .then(res => {
                this.orderListTemp = res.list;
                this.orderListTemp.forEach(item => {
                    this.orderList.push(item)
                })

                //关闭上拉加载、下拉刷新事件
                if (ionEvent) {
                    ionEvent.complete()
                    //如果上拉加载已经被关闭，在下拉加载后重新开启
                    if (ionEventType == 'refresher' && this.connectService.getData('infiniteScroll')) {
                        this.connectService.getData('infiniteScroll').enable(true);
                    }
                }

                //如果获取到的订单数量少于pageSize，则使上拉加载不可用
                if (ionEvent && ionEventType == 'infiniteScroll' && this.orderListTemp.length < this.pageSize) {
                    ionEvent.enable(false);
                    this.connectService.saveData('infiniteScroll', ionEvent)
                }
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl)
            })
    }

    /**
     * @description 上拉加载方法
     * @param {*} infiniteScroll infiniteScroll实例
     * @returns {void}
     * @memberOf SupplierManagerCheckOrderPage
     * @author xjn
     * @date 2017年3月27日
     */
    public doInfinite(infiniteScroll: any): void {
        this.pageNumber++;
        this.getOrderCheckLists(this.orderStatusType, 'infiniteScroll', infiniteScroll) //获取订单
        console.warn(`当前pageNumber：${this.pageNumber}`)
    }

    /**
     * @description 下拉刷新方法
     * @param {*} refresher refresher实例
     * @returns {void}
     * @memberOf SupplierManagerCheckOrderPage
     * @author xjn
     * @date 2017年3月27日
     */
    public doRefresh(refresher: any): void {
        this.pageNumber = 0;
        this.orderList = [];
        this.getOrderCheckLists(this.orderStatusType, 'refresher', refresher)  //获取订单
    }

    /**
     * @description 跳转验单详情
     * @param {string} orderStatusType 验单状态（已完成 or 未完成）
     * @param {*} order 当前订单数据
     * @returns {void}
     * @memberOf SupplierManagerCheckOrderPage
     * @author xjn
     * @date 2017年3月31日
     */
    public goCheckOrderDetail(orderStatusType: string, order: any): void {
        let url: string = '';
        if (this.businessType == '0010') {
            url = ApiUrlService.getApiUrl('getOrdersConfirmDetail');
        } else if (this.businessType == '002001') {
            url = ApiUrlService.getApiUrl('getStageOrdersConfirmDetail');
        } else if (this.businessType == '002002') {
            url = ApiUrlService.getApiUrl('getApplianceOrdersConfirmDetail');
        }
        let param = {
            url: url,
            params: {
                storeId: order.storeId,
                date: order.date,
                type: orderStatusType == 'unChecked' ? '0' : '1',
                sortType: 'goodsName'
            }
        }
        this.httpService.post(param)
            .then(res => {
                this.navCtrl.push(CheckOrderDetailPage, { orderDetail: res, orderStatusType: orderStatusType })
            })
            .catch(err => {
                this.httpService.handleErr(err, this.navCtrl);
            })
    }
}
