import { Injectable } from '@angular/core';

/**
 * @title ConfigService
 * @description 配置信息存取服务
 * @export
 * @class ConfigService
 * @author xjn
 * @date 2017年3月13日
 */
@Injectable()
export class ConfigService {
    //基础地址
    private static baseHost: string = 'http://localhost:8080/pazlNewApp0420JD';
    // private static baseHost: string = 'http://FLQSH-L1868:8080/pazlNewApp_20170420_jiadian';  //顾理想地址
    // private static baseHost: string = 'http://FLQSH-L1798:8080/pazlNewApp_20170420_jiadian';
    // private static baseHost: string = 'http://10.11.3.127:8080/pazl';
    // private static baseHost: string = ''  //sit测试地址
    // private static baseHost: string = 'http://localhost:8080/pazlNewApp_20170420_jiadian';
    // private static baseHost: string = 'http://10.11.3.127:8080/pazl';
    // private static baseHost: string = 'http://10.119.40.132:8080/pazl';

    //通用地址
    private static commonHost: string = '/new/partnerApp'

    //订单时间限制（小时）
    private invoiceLimitTime: number = 24;
    private deliverySelfLimitTime: number = 24 * 14;
    private deliveryOtherLimitTime: number = 24 * 10;

    //是否开发模式（开发模式：不进行http请求，页面所有数据都使用testdata-service中预存的数据）
    private static devMode: boolean = false;

    private static skipCordova = {
        uploadInvoice: true,  //上传发票
        lngAndLat: true  // 经纬度
    }

    private static partnerVersion = {
        appVersionCode: 20170420,
        apiVersion: '1.0'
    };

    constructor() {

    }

    /**
     * @description 获取配置参数
     * @static
     * @param {string} config 配置名称
     * @returns {ConfigService}
     * @memberOf ConfigService
     * @author xjn
     * @date 2017年3月26日
     */
    public static getConfig(config: string) {
        return this[config]
    }

}
