import { Directive, ElementRef, Renderer } from '@angular/core';
import { Events } from 'ionic-angular';

@Directive({
    selector: '[square]' // Attribute selector
})
export class Square {

    constructor(
        ele: ElementRef,
        renderer: Renderer,
        events: Events
    ) {
        console.log('Hello Square Directive');
        console.log(ele.nativeElement.querySelector('.photo'))
        setTimeout(function () {
            // console.log(ele.nativeElement.width)
            // ele.nativeElement.style.height = ele.nativeElement.width
            // console.log(ele.nativeElement.querySelector('.photo'))
            let photo = ele.nativeElement.querySelector('.photo')
            // console.log(photo.width)
            ele.nativeElement.style.height = photo.width + 'px'
            photo.style.height = photo.width + 'px';
            photo.style.display = 'block';
        }, 200);

    }

}
