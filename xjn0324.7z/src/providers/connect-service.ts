import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

/**
 * @Title: ConnectService
 * @Description: 全局通信及变量存取服务
 * @export
 * @class ConnectService
 * 
 * @auther: xjn
 * @date: 2017年3月9日
 */
@Injectable()
export class ConnectService {
  
  /**
   * @Title: getOrdersByDate
   * @Description: 存放全局变量的对象
   * @type {*}
   * @memberOf ConnectService
   */
  public commonData: any = {
    orderDateExist: [],
    displayOrders: [],
    timeIntervalArray: []
  }

  constructor() {
    
  }

  /**
   * @Title: saveData
   * @Description: 保存全局变量的方法
   * @param {string} key  存入的key值
   * @param {*} val  存入的数据
   * @returns {void}
   * @memberOf ConnectService
   * 
   * @auther: xjn
   * @date: 2017年3月9日
   */
  public saveData(key: string, val: any): void{
    this.commonData.key = val;
  }
  
  /**
   * @Title: getData
   * @Description: 获取全局变量的方法
   * @param {string} key  获取的key值
   * @returns {*}
   * @memberOf ConnectService
   * 
   * @auther: xjn
   * @date: 2017年3月9日
   */
  public getData(key: string): any{
    return this.commonData.key;
  }

  /**
   * @Title: clearData
   * @Description: 清除全局变量的方法
   * @param {string} key  需要清空的key值
   * @returns {void}
   * @memberOf ConnectService
   * 
   * @auther: xjn
   * @date: 2017年3月15日
   */
  public clearData(key: string): void{
    this.commonData.key = '';
  }

}
