import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { AlertController, Events } from 'ionic-angular';
import { ConnectService } from './connect-service';

/**
 * @Title ToolService
 * @Description 存放工具方法的服务
 * @export 
 * @class ToolService
 * 
 * @auther xjn
 * @date 2017年3月10日
 */
@Injectable()
export class ToolService {
  
  //校验规则
  public phoneRegExp:any = /^1[34578]\d{9}$/;
  public userNameRegExp:any = /^[a-zA-Z0-9_]{6,}$/;
  public pwdRegExp:any = /^(?!([a-zA-Z]+|\d+)$)[a-zA-Z\d]{8,}$/;
  public validationCodeRegExp:any = /^\d{6}$/;
  public idCardRegExp:any = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
  public nameRegExp:any = /^[\u4e00-\u9fa5]{2,}$/;
  public goodsNoRegExp:any = /^[0-9a-zA-Z]*$/;
  public invoiceNumberRegExp:any = /^\d{8}$/;

  constructor(
      public alertCtrl: AlertController,
      public events: Events,
      public connectService: ConnectService
  ) {
    
  }

  //校验手机号
  public checkPhone(phone: string, type: string): boolean{
    if(phone){
        if(this.phoneRegExp.test(phone)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }
  //校验用户名
  public checkUserName(userName: string, type: string): boolean{
    if(userName){
        if(this.userNameRegExp.test(userName)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }
  //校验密码
  public checkPwd(usePwd: string, type: string): boolean{
    if(usePwd){
        if(this.pwdRegExp.test(usePwd)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }
  //校验确认密码
  public checkCheckPwd(checkPwd: string, type: string): boolean{
    if(checkPwd){
        if(this.pwdRegExp.test(checkPwd)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }
  //校验验证码
  public checkValidationCode(validationCode: string, type: string): boolean{
    if(validationCode){
        if(this.validationCodeRegExp.test(validationCode)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }
  //校验身份证号
  public checkIdCard(idNumber: string, type: string): boolean{
    if(idNumber){
        if(this.idCardRegExp.test(idNumber)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }
  //校验姓名
  public checkIdName(idName: string, type: string): boolean{
    if(idName){
        if(this.nameRegExp.test(idName)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }
  //校验商品串号
  public chenkGoosNo(goodNo: string, type: string): boolean{
      if(goodNo){
        if(this.goodsNoRegExp.test(goodNo)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }
  //校验发票号
  public chenkInvoiceNumber(invoiceNumber: string, type: string): boolean{
      if(invoiceNumber){
        if(this.invoiceNumberRegExp.test(invoiceNumber)){
            return true
        }else{
            this.showAlert(`请输入正确的${type}`);
            return false
        }
    }else{
        this.showAlert(`请输入${type}`);
        return false
    }
  }

  /**
   * @Title showAlert
   * @Description 弹出警告窗口
   * @param {string} msg 弹出内容
   * @returns {void}
   * @memberOf ToolService
   * 
   * @auther xjn
   * @date 2017年3月6日
   */
  public showAlert(msg: string): void{
    let alert = this.alertCtrl.create({
      title: '平安租赁',
      subTitle: msg,
      buttons: ['关闭']
    });
    alert.present();
  }
 
  /**
   * @Title showRadio
   * @Description 弹出单选列表
   * @param {string} title 标题
   * @param {any[]} list 列表数据
   * @param {string} eventType 传值事件命名
   * @returns {void}
   * @memberOf ToolService
   * 
   * @auther xjn
   * @date 2017年3月23日
   */
  public showRadio(title: string, list: any[], eventType?: string): void{
    //创建alert对象
    let alert = this.alertCtrl.create();
    //标题设置
    alert.setTitle(title);
    //生成选项列表
    list.map(item => {
        alert.addInput({
          type: 'radio',
          label: item.value,
          value: item,
          checked: false
        });
    })
    //生成cancel按钮
    alert.addButton('取消');
    //生成OK按钮
    alert.addButton({
      text: '选择',
      handler: data => {
        this.events.publish(eventType, data)  //传值给相应页面，页面中用subscribe接受
        console.log(data)
      }
    });
    //弹出alert窗口
    alert.present();
  }
  
  /**
   * @Title clearTimeArray
   * @Description 清除定时器列表
   * @returns {viod}
   * @auther xjn
   * @date 2017年3月24日
   * @memberOf ToolService
   * 
   * @auther xjn
   * @date 2017年3月24日
   */
  public clearTimeArray(): void{
    this.connectService.commonData.timeIntervalArray.map((timer, index, timeIntervalArray) => {
        clearInterval(timer);  //清除定时器
        timeIntervalArray.pop(timer);  //删除数组中的该定时器
        // console.log(timeIntervalArray);
    })
  }

  /**
   * @Title getOrdersByDate
   * @Description
   * 将获取到的订单数据进行时间归类
   * 按照时间添加到绑定模板展示的数组displayOrders中
   * 并将当前订单时间更新至存放时间的数组orderDateExist中
   * @param {*} listData
   * @returns {void}
   * @memberOf ToolService
   * 
   * @auther xjn
   * @date 2017年3月13日
   */
  public getOrdersByDate(listData: any[]): void{
      let shareData = this.connectService.commonData  //变量暂存
      //遍历获取到的订单数据
      listData.forEach(order => {  
          let date = order.orderTime.substring(0,10);
          if(shareData.orderDateExist.indexOf(date) >= 0){  //如果订单时间已存在，找到订单数组中的该日期数组，插入订单
            shareData.displayOrders.forEach(ordersByDate => {
              if(ordersByDate.date == date){
                ordersByDate.orders.push(order)
              }
            })
          }else{  //如果订单时间不存在，新建订单对象，插入订单数组；并将时间存入时间数组
            let ordersByDate: any = {
              date: date,
              orders: [order]
            }
            shareData.displayOrders.push(ordersByDate);
            shareData.orderDateExist.push(date);
          }
      })
      //将转换完毕的数组传递出去
      this.events.publish('getOrdersByDateComplete', shareData.orderDateExist, shareData.displayOrders);
  }
}
