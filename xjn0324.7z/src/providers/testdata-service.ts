import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

/**
 * @Title: TestdataService
 * @Description: 保存前端开发测试数据的服务
 * @export
 * @class TestdataService
 * 
 * @auther: xjn
 * @date: 2017年3月9日
 */
@Injectable()
export class TestdataService {
  //注册-联级查询运营商
  public operatorList: any = {
    "code" : 2000,
    "message" : "提示信息",
    "data" : [
        {"key" : "1", "value":"运营商test1"},
        {"key" : "2", "value":"运营商test2"},
        {"key" : "3", "value":"运营商test3"},
        {"key" : "4", "value":"运营商test4"},
        {"key" : "5", "value":"运营商test5"},
        {"key" : "6", "value":"运营商test6"},
        {"key" : "7", "value":"运营商test7"},
        {"key" : "8", "value":"运营商test8"},
        {"key" : "9", "value":"运营商test9"},
        {"key" : "10", "value":"运营商test10"},
        {"key" : "11", "value":"运营商test11"},
        {"key" : "12", "value":"运营商test12"},
        {"key" : "13", "value":"运营商test13"}
    ]
  }

  //注册-联级查询供应商
  public supplierList: any = {
    "code" : 2000,
    "message" : "提示信息",
    "data" : [
        {"key" : "1", "value":"供应商test1"},
        {"key" : "2", "value":"供应商test2"},
        {"key" : "3", "value":"供应商test3"},
        {"key" : "4", "value":"供应商test4"},
        {"key" : "5", "value":"供应商test5"},
        {"key" : "6", "value":"供应商test6"},
        {"key" : "7", "value":"供应商test7"},
        {"key" : "8", "value":"供应商test8"},
        {"key" : "9", "value":"供应商test9"},
        {"key" : "10", "value":"供应商test10"},
        {"key" : "11", "value":"供应商test11"},
        {"key" : "12", "value":"供应商test12"},
        {"key" : "13", "value":"供应商test13"}
    ]
  }

  //注册-联级查询门店
  public storeList: any = {
    "code" : 2000,
    "message" : "提示信息",
    "data" : [
        {"key" : "1", "value":"test门店1"},
        {"key" : "2", "value":"test门店2"},
        {"key" : "3", "value":"test门店3"},
        {"key" : "4", "value":"test门店4"},
        {"key" : "5", "value":"test门店5"},
        {"key" : "6", "value":"test门店6"},
        {"key" : "7", "value":"test门店7"},
        {"key" : "8", "value":"test门店8"},
        {"key" : "9", "value":"test门店9"},
        {"key" : "10", "value":"test门店10"},
        {"key" : "11", "value":"test门店11"},
        {"key" : "12", "value":"test门店12"},
        {"key" : "13", "value":"test门店13"}
    ]
  }

  //二维码页面测试数据
  public qrCodeList:any ={
    "code" : 2000,
    "message" : "提示信息",
    "data" : {
        "storeUserName" : "张飞",
        "storeName" : "运营商test",
        "storeUserCompany" : "上海联通",
        "storeUserId" : "47"
    }
  }

  //工单列表测试数据
  public workOrdersList: any = {
    "code" : 2000,
    "message" : "提示信息",
    "data" : [ 
        {
        "orderNo" : "921020448",
        "userName":"徐嘉农",
        "goodsType" : "iPhone6S",
        "orderTime" : "2017-01-01 19:14:29",
        "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "iPhone5",
            "orderTime" : "2017-01-02 19:14:29",
            "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "三星Note5",
            "orderTime" : "2017-01-02 19:14:29",
            "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "OPPO R9",
            "orderTime" : "2017-01-03 19:14:29",
            "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "iPhone7",
            "orderTime" : "2017-01-03 19:14:29",
            "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "iPhone5 plus",
            "orderTime" : "2017-01-03 19:14:29",
            "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "iPhone6 plus",
            "orderTime" : "2017-01-04 19:14:29",
            "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "三星 S7",
            "orderTime" : "2017-01-04 19:14:29",
            "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "华为 荣耀4",
            "orderTime" : "2017-01-04 19:14:29",
            "orderStatus" : "待处理订单"
        },
        {
            "orderNo" : "921020449",
            "userName":"徐嘉农",
            "goodsType" : "小米4",
            "orderTime" : "2017-01-04 19:14:29",
            "orderStatus" : "待处理订单"
        } 
    ]
  }
  
  //工单详情测试数据
  public workOrderDetail:any ={
    "code" : 2000,
    "message" : "提示信息",
    "data" : {
        "applicant" : "张三",
        "goodsName" : "三星J3109",
        "price" : "2345",
        "businessType" : "新号入网",
        "suite" : "天翼59套餐",
        "subsidyAmt" : "590.0",
        "downPatestentAmt" : "1755",
        "orderTime" : "2017-01-09 19:14:29",
        "orderStatus" : "1"
    }
  }

  
  constructor() {
    
  }

 

}
