import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { LoginPage } from './pages/common-pages/login/login';
// import { ShopAssistantTabsPage } from './pages/shop-assistant/shopassistant-tabs/shop-assistant-tabs';
// import { SupplierManagerTabsPage } from './pages/supplier-manager/supplier-manager-tabs/supplier-manager-tabs';
// import { OperatorManagerTabsPage } from './pages/operator-manager/operator-manager-tabs/operator-manager-tabs';


/**
 * @Title: ConfigService
 * @Description: 配置信息存取服务
 * @export
 * @class ConfigService
 * 
 * @auther: xjn
 * @date: 2017年3月13日
 */
@Injectable()
export class ConfigService {
  
  //请求地址的通用部分
  // public baseHost: string = 'http://localhost:8080/pazl1230_2';
  public baseHost: string = 'http://FLQSH-L1868:8080/pazlNewApp_20170323';  //顾理想地址
  
  // public commonHost: string = '/new'

  //开发模式
  public devMode: boolean = false;

  //开发模式中根组件切换
  public rootPage: any = LoginPage;  //登陆
  // public rootPage: any = ShopAssistantTabsPage;  //普通店员
  // public rootPage: any = SupplierManagerTabsPage;  //供应商管理员
  // public rootPage: any = OperatorManagerTabsPage;  //运营商管理员


  constructor() {
  }

}
