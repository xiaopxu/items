import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ConnectService } from '../../../providers/connect-service';
import { LoginPage } from '../../common-pages/login/login';
import { ChangePwdPage } from '../../common-pages/change-pwd/change-pwd';
import { SupplierManagerMePersonalInfomationPage } from '../supplier-manager-me-personal-infomation/supplier-manager-me-personal-infomation';


/*
  Generated class for the SupplierManagerMe page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-supplier-manager-me',
  templateUrl: 'supplier-manager-me.html'
})
export class SupplierManagerMePage {
  public storeUserName: string = '';//用户名
  public storeUserPhoneNum: string = '';//手机号
  public storeUserIdCard: string = ''; //身份证
  constructor(public navCtrl: NavController, 
  public navParams: NavParams,
  public connectService: ConnectService
  ) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad SupplierManagerMePage');
    let loginStatus: any = this.connectService.getData('loginStatus');
    this.storeUserName = loginStatus.storeUserName;
    this.storeUserPhoneNum = loginStatus.storeUserPhoneNumber;
    this.storeUserIdCard = loginStatus.storeUserIdentityCardNumber;
  }
    userInfo(){
  console.log("usersInfo");
  this.navCtrl.push(SupplierManagerMePersonalInfomationPage);

}
changePwd(){
   console.log("changePwd");
    this.navCtrl.push(ChangePwdPage);
  
}
loginOut(){
  console.log("loginout");
  this.navCtrl.push(LoginPage);
}

}
