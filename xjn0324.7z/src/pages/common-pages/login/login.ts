//框架自带
import { Component } from '@angular/core';
import { NavController, ViewController, Events, ModalController, App, LoadingController } from 'ionic-angular';
import { HttpService } from '../../../providers/http-service'
import { Storage } from '@ionic/storage';

//第三方插件
import { Md5 } from 'ts-md5/dist/md5';

//自定义组件
import { ShopAssistantTabsPage } from '../../shop-assistant/shopassistant-tabs/shop-assistant-tabs';
import { SupplierManagerTabsPage } from '../../supplier-manager/supplier-manager-tabs/supplier-manager-tabs';
import { ConnectService } from '../../../providers/connect-service';
import { OperatorManagerTabsPage } from '../../operator-manager/operator-manager-tabs/operator-manager-tabs';
import { FindPwdPage } from '../find-pwd/find-pwd';
import { RegisterPage } from '../register/register';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';


@Component({
    selector: 'page-login',
    templateUrl: './login.html',
    providers: [HttpService]
})
export class LoginPage {
    private userName: string = '';
    private userPwd: string = '';
    private tabPage: any;
    private findPwdPage: any = FindPwdPage;
    private registerPage: any = RegisterPage;

    constructor(
        private navCtrl: NavController, 
        private httpService: HttpService, 
        private viewCtrl: ViewController,
        private modalCtrl: ModalController,
        private events: Events,
        private storage: Storage,
        private appCtrl: App,
        private connectService: ConnectService,
        private toolService: ToolService,
        private config: ConfigService,
        private loadingCtrl: LoadingController
    ){}


    ionViewDidLoad(){
        console.log(this.navCtrl.getActive().name)
    }

    //登陆方法
    private login(){
        //字段校验
        if(!this.toolService.checkUserName(this.userName, '账号')){ return }
        // if(!this.toolService.checkPwd(this.userPwd, '密码')){ return }
        
        //设置请求参数
        let param: any = {
            url: `${this.config.baseHost}/new/partnerApp/common/userLogin`,
            accountId: this.userName || '',
            params: {
                accountName: this.userName || '',
                accountPwd: Md5.hashStr(this.userPwd || '').toString().toUpperCase()
            }
        }
        if(!this.config.devMode){
            //发送请求
            this.httpService.post(param)
                .then( res => {
                    let loginData:any = res;
                    console.warn('获取登录信息')
                    console.log(loginData)
                    //根据获取到的店员身份，转跳不同的模块
                    if(loginData.userType == '2'){  //店员
                        this.tabPage = ShopAssistantTabsPage;
                    }else if(loginData.userType == '3'){  //运营商管理员
                        this.tabPage = OperatorManagerTabsPage;
                    }else if(loginData.userType == '4'){  //供应商管理员
                        this.tabPage = SupplierManagerTabsPage;
                    }
                    //将登录信息存储入connectService服务
                    this.connectService.saveData('loginStatus', loginData);
                    //重新指定root组件
                    this.navCtrl.setRoot(this.tabPage)
                })
                .catch(err => {
                    this.httpService.handleErr(err);
                })
        }else{
            this.navCtrl.push(ShopAssistantTabsPage);
        }
    }
}
