import { Component, Input } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { WorkOrderDetailPage } from '../work-order-detail/work-order-detail';
import { TestdataService } from '../../../providers/testdata-service';

/*
  Generated class for the WorkOrdersList page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-work-orders-list',
  templateUrl: 'work-orders-list.html'
})
export class WorkOrdersListPage {
  @Input() displayOrders: any = [];
  @Input() currentPage: any = [];
  @Input() orderStatus: any = [];
  public orderDetailData: any = this.testData.workOrderDetail.data;
  constructor(public navCtrl: NavController, public navParams: NavParams, public testData: TestdataService) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad WorkOrdersListPage');
  }
  
  public goDetailPage(order: any): void{
    this.orderDetailData.userName = order.userName;
    this.orderDetailData.orderId = order.orderNo;
    this.navCtrl.push(WorkOrderDetailPage, this.orderDetailData)
  }

}
