import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HttpService } from '../../../providers/http-service';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';
import { ConnectService } from '../../../providers/connect-service';
import { Md5 } from 'ts-md5/dist/md5';

@Component({
  selector: 'page-find-pwd',
  templateUrl: 'find-pwd.html'
})
export class FindPwdPage {
  public userName: string = '';
  public phoneNumber: string = '';
  public validationCode: string = '';
  public newPwd: string = '';
  private smsId: string = '';

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public httpService: HttpService,
    public toolService: ToolService,
    public configService: ConfigService,
    public connectService: ConnectService
  ) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad FindPwdPage');
  }
  
  //接收子集传递的smsId
  private getSmsId(smsId: string) {
    this.smsId = smsId;
  }
  
  //提交修改密码
  private submit(): void{
    //字段校验
    if(!this.toolService.checkUserName(this.userName, '账号')){ return };
    if(!this.toolService.checkPhone(this.phoneNumber, '手机号')){ return };
    if(!this.toolService.checkValidationCode(this.validationCode, '验证码')){ return };
    if(!this.toolService.checkPwd(this.newPwd, '密码')){ return };
    //请求参数
    let param: any = {
      url: `${this.configService.baseHost}/new/partnerApp/common/resetPwd`,
      params: {
          userName: this.userName,
          newPwd: Md5.hashStr(this.newPwd || '').toString().toUpperCase(),
          phone: this.phoneNumber,
          smsId: this.smsId,
          identifyCode: this.validationCode
      }
    }
    //发送请求
    if(!this.configService.devMode){
      this.httpService.post(param)
        .then( res => {
          console.log('密码修改成功')
          this.navCtrl.pop();
        })
        .catch( err => {
          this.httpService.handleErr(err)
        })
    }else{
      this.navCtrl.pop();
    }
  }
}
