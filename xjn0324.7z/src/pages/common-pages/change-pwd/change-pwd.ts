import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/*
  Generated class for the ChangePwd page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-change-pwd',
  templateUrl: 'change-pwd.html'
})
export class ChangePwdPage {
   oldPwd:any;
  newPwd:any;
  conformPwd:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChangePwdPage');
  }
  changePwd(){
     console.log(this.oldPwd+".."+this.newPwd+"--"+this.conformPwd);
  }

}
