import { Injectable } from '@angular/core';

/**
 * @title ConfigService
 * @description 配置信息存取服务
 * @export
 * @class ConfigService
 * @author xjn
 * @date 2017年3月13日
 */
@Injectable()
export class ConfigService {
    //基础地址
    // private static baseHost: string = 'http://localhost:8080/pazlNewApp0406';
    private static baseHost: string = 'http://FLQSH-L1868:8080/pazlNewApp_20170406';  //顾理想地址
    // private static baseHost: string = ''  //sit测试地址

    //通用地址
    private static commonHost: string = '/new/partnerApp'

    //是否开发模式（开发模式：不进行http请求，页面所有数据都使用testdata-service中预存的数据）
    private static devMode: boolean = false;

    private static skipCordova = {
        uploadInvoice: true  //上传发票
    }

    constructor() { }

    /**
     * @description 获取配置参数
     * @static
     * @param {string} config 配置名称
     * @returns {ConfigService}
     * @memberOf ConfigService
     * @author xjn
     * @date 2017年3月26日
     */
    public static getConfig(config: string) {
        return this[config]
    }

}
