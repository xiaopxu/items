import { Component } from '@angular/core';
import { NavController, NavParams, Events, LoadingController } from 'ionic-angular';
import { TestdataService } from '../../../providers/testdata-service';
import { ConnectService } from '../../../providers/connect-service';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';
import { ApiUrlService } from '../../../providers/api-url-service';
import { HttpService } from '../../../providers/http-service';

@Component({
    selector: 'page-shop-assistant-work-orders',
    templateUrl: 'shop-assistant-work-orders.html'
})
export class ShopAssistantWorkOrdersPage {
    private businessType: string = this.connectService.getData('loginStatus').bussinessType;
    private orderStatusType: string = 'unChecked';  //判断segment在已处理or未处理，预设值影响默认展示页
    private listData: any = [];  //当前获取到的订单数据（当前一次请求的数据（0-pageSize条））
    private orderDateExist: string[] = [];  //已存在的时间分类（缓存）
    private displayOrders: any = [];  //经过时间分类处理的订单数据（缓存）
    private pageNumber: number = 0;
    private pageSize: number = 10;

    constructor(
        private navCtrl: NavController,
        private navParam: NavParams,
        private testdataService: TestdataService,
        private events: Events,
        private connectService: ConnectService,
        private toolService: ToolService,
        private loadingCtrl: LoadingController,
        private httpService: HttpService
    ) {

    }
    //生命周期：页面加载完毕（只在首次加载时被调用）
    ionViewDidLoad() {
        // this.clearOrderList();
        // this.selectSegment('unChecked')
        console.warn('========================进入ShopAssistantWorkOrdersPage============================')
    }
    //生命周期：即将进入页面
    ionViewWillEnter() {
        this.clearOrderList();
        this.selectSegment(this.orderStatusType)

        this.events.subscribe('getOrdersByDateComplete', (orderDateExist, displayOrders) => {
            this.orderDateExist = orderDateExist;
            this.displayOrders = displayOrders;
        })
    }

    /**
     * @description 点击切换segment触发方法，刷新订单数据
     * @param {string} status 订单状态（已处理 or 未处理）
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    public selectSegment(status: string): void {
        console.warn(`当前标签为：${status}`)

        this.orderStatusType = status;  //更新标签状态
        this.pageNumber = 0;
        this.clearOrderList()
        this.getDisplayOrders(this.orderStatusType);  //获取订单
    }

    /**
     * @description 上拉加载方法
     * @param {*} infiniteScroll infiniteScroll实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    public doInfinite(infiniteScroll: any): void {

        this.getDisplayOrders(this.orderStatusType, infiniteScroll) //获取订单

        //如果获取到的订单数量少于pageSize，则使上拉加载不可用
        if (this.listData.length < this.pageSize) {
            infiniteScroll.enable(false);
            return
        }

        this.pageNumber++;
    }

    /**
     * @description 下拉刷新方法
     * @param {*} refresher refresher实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    public doRefresh(refresher: any): void {
        this.pageNumber = 0;
        this.clearOrderList()
        this.getDisplayOrders(this.orderStatusType, refresher)  //获取订单
    }

    /**
     * @description 请求工单数据
     * @param {string} status 订单数组
     * @param {*} event 上拉加载实例 or 下拉刷新实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    private getDisplayOrders(status: string, ionEvent?: any): void {
        //参数校验
        if (!status) {
            console.error('非法参数：status')
            return
        }
        status = status == 'unChecked' ? '0' : '1'  //转换标签状态为请求字段
        //获取订单数据
        if (!ConfigService.getConfig('devMode')) {
            //设置请求参数
            let param = {
                url: this.businessType == '0010' ? ApiUrlService.getApiUrl('getClerkOrderList') : ApiUrlService.getApiUrl('getStageClerkOrderList'),
                accountId: this.connectService.getData('loginStatus').storeUserId,
                params: {
                    pageNumber: this.pageNumber,
                    pageSize: this.pageSize,
                    type: status
                }
            }
            //发送请求
            this.httpService.post(param, ionEvent)
                .then(res => {
                    this.listData = res.list;
                    this.clearOrderList();
                    this.handleDisplayOrders(this.listData);
                    if (ionEvent) {
                        ionEvent.complete()
                    }
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            if (!ionEvent) {
                //启动加载提示符
                let loading = this.loadingCtrl.create({
                    spinner: 'ios',
                    content: '加载中...'
                })
                this.connectService.saveData('loading', loading)
                this.connectService.getData('loading').present();
            }

            setTimeout(() => {

                this.listData = this.businessType == '0010' ? this.testdataService.workOrdersList.data.list : this.testdataService.workOrderStageList.data.list;
                this.handleDisplayOrders(this.listData);
                if (!ionEvent) {
                    this.connectService.getData('loading').dismiss();
                } else {
                    ionEvent.complete()
                }
            }, 1000);
        }
    }

    /**
     * @description 将listData按照时间分类加入到displayOrders中缓存
     * @param {any[]} listData 订单数组
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    private handleDisplayOrders(listData: any[]): void {

        this.toolService.setOrdersByDate(listData)

        console.warn('工单数据刷新完毕')
        console.log(this.displayOrders)
    }

    /**
     * @description 清空已有的订单数据缓存
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    private clearOrderList() {
        this.connectService.commonData.orderDateExist = [];
        this.connectService.commonData.displayOrders = [];
    }

}
