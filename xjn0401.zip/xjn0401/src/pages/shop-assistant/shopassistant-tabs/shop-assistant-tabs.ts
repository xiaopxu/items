import { Component, ViewChild } from '@angular/core';
import { Tabs } from 'ionic-angular';
import { ShopAssistantQrcodePage } from '../shop-assistant-qrcode/shop-assistant-qrcode';
import { ShopAssistantWorkOrdersPage } from '../shop-assistant-work-orders/shop-assistant-work-orders';
import { ShopAssisyantAchievementPage } from '../shop-assistant-achievement/shop-assistant-achievement';
import { ShopAssistantMePage } from '../shop-assistant-me/shop-assistant-me';

@Component({
  templateUrl: './shop-assistant-tabs.html'
})
export class ShopAssistantTabsPage {
  @ViewChild('mainTabs') tabs:Tabs;
  // this tells the tabs component which Pages
  // should be each tab's root Page
  tab1Root: any = ShopAssistantQrcodePage;
  tab2Root: any = ShopAssistantWorkOrdersPage;
  tab3Root: any = ShopAssisyantAchievementPage;
  tab4Root: any = ShopAssistantMePage;

  constructor() {

  }
}
