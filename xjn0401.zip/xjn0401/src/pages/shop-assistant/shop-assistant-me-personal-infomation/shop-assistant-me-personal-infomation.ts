import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ConnectService } from '../../../providers/connect-service';

/*
  Generated class for the ShopAssistantMePersonalInfomation page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-shop-assistant-me-personal-infomation',
  templateUrl: 'shop-assistant-me-personal-infomation.html'
})
export class ShopAssistantMePersonalInfomationPage {
    public name:string='';//姓名
   public  storeUserPhone:string='';//手机号
    public storeUserAccountName: string = '';//用户名
  public storeName: string = ''; //所属门店
  public storesSupplier: string = ''; //门店所属供应商


  constructor(public navCtrl: NavController, public navParams: NavParams,
           public connectService: ConnectService
  ) {}
 
  ionViewDidLoad() {
    console.log('ionViewDidLoad ShopAssistantMePersonalInfomationPage');
     let loginStatus: any = this.connectService.getData('loginStatus');
    this.name = loginStatus.storeUserName;
    this.storeUserPhone = loginStatus.storeUserPhoneNumber;
    this.storeUserAccountName=loginStatus.storeUserAccountName;
    this.storeName=loginStatus.storeName;
    this.storesSupplier=loginStatus.storeUserCompany;

    
  }

}
