import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HttpService } from '../../../providers/http-service';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';
import { ConnectService } from '../../../providers/connect-service';
import { ValidatorService } from '../../../providers/validator-service';
import { ApiUrlService } from '../../../providers/api-url-service';


@Component({
    selector: 'page-find-pwd',
    templateUrl: 'find-pwd.html'
})
export class FindPwdPage {
    private userName: string = '';
    private phoneNumber: string = '';
    private validationCode: string = '';
    private newPwd: string = '';
    private smsId: string = '';

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private httpService: HttpService,
        private toolService: ToolService,
        private connectService: ConnectService,
        private validatorService: ValidatorService
    ) { }

    ionViewDidLoad() {
        console.log('ionViewDidLoad FindPwdPage');

        //清除验证码定时器
        this.toolService.clearTimeArray();

    }

    //接收子集传递的smsId
    public getSmsId(smsId: string) {
        this.smsId = smsId;
    }

    //提交修改密码
    public submit(): void {
        //字段校验
        if (!this.validatorService.checkUserName(this.userName, '账号')) { return };
        if (!this.validatorService.checkPhone(this.phoneNumber, '手机号')) { return };
        if (!this.validatorService.checkValidationCode(this.validationCode, '验证码')) { return };
        if (!this.validatorService.checkPwd(this.newPwd, '密码')) { return };
        //请求参数
        let param: any = {
            url: ApiUrlService.getApiUrl('resetPwd'),
            params: {
                userName: this.userName,
                newPwd: this.toolService.encryptByMd5(this.newPwd),
                phone: this.phoneNumber,
                smsId: this.smsId,
                identifyCode: this.validationCode
            }
        }
        //发送请求
        if (!ConfigService.getConfig('devMode')) {
            this.httpService.post(param)
                .then(res => {
                    console.log('密码修改成功')
                    this.navCtrl.pop();
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            this.navCtrl.pop();
        }
    }
}
