import { Component, Input } from '@angular/core';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { WorkOrderDetailPage } from '../work-order-detail/work-order-detail';
import { TestdataService } from '../../../providers/testdata-service';
import { ConnectService } from '../../../providers/connect-service';
import { ConfigService } from '../../../config-servise';
import { HttpService } from '../../../providers/http-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { ToolService } from '../../../providers/tool-service';

/**
 * @description 工单列表组件
 * @export
 * @class WorkOrdersListPage
 * @author xjn
 * @date 2017年3月14日
 */
@Component({
    selector: 'page-work-orders-list',
    templateUrl: 'work-orders-list.html'
})
export class WorkOrdersListPage {
    @Input() displayOrders: any[] = [];  //订单列表
    @Input() currentPage: string = '';  //当前页面（工单 or 验单）
    @Input() orderStatusType: string = '';  //订单状态类型（未处理 or 已处理）

    private orderDetailData: any = {};
    private businessType: string = this.connectService.getData('loginStatus').bussinessType

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private testdataService: TestdataService,
        private connectService: ConnectService,
        private httpService: HttpService,
        private loadingCtrl: LoadingController,
        private toolService: ToolService
    ) { }

    ionViewDidLoad() {
        console.log('ionViewDidLoad WorkOrdersListPage');
    }

    /**
     * @description 转跳至详情页面
     * @param {*} order 当前订单列表字段
     * @param {string} orderStatus 订单状态类型（未处理 or 已处理）
     * @returns {void}
     * @memberOf WorkOrdersListPage
     * @author xjn
     * @date 2017年3月14日
     */
    public goDetailPage(order: any, orderStatusType: string): void {
        this.toolService.clearTimeArray();
        this.getDisplayOrders(order, orderStatusType);
    }

    /**
     * @description 请求工单详情数据
     * @param {string} orderId 订单id
     * @param {string} status 订单状态类型（未处理 or 已处理）
     * @returns {void}
     * @memberOf WorkOrdersListPage
     * @author xjn
     * @date 2017年3月28日
     */
    private getDisplayOrders(order: any, status: string): void {
        //参数校验
        if (!order) {
            console.error('非法参数：order')
            return
        }
        if (!status) {
            console.error('非法参数：status')
            return
        }

        status = status == 'unChecked' ? '0' : '1'  //转换标签状态为请求字段
        //获取订单数据
        if (!ConfigService.getConfig('devMode')) {
            //设置请求参数
            let param = {};
            if (this.businessType == '0010') {
                param = {
                    url: ApiUrlService.getApiUrl('getClerkOrderDetail'),
                    accountId: this.connectService.getData('loginStatus').storeUserId,
                    params: {
                        orderId: order.orderId,
                        type: status
                    }
                }
            } else if (this.businessType == '002001') {
                param = {
                    url: ApiUrlService.getApiUrl('getStageOrderDetail'),
                    accountId: this.connectService.getData('loginStatus').storeUserId,
                    params: {
                        orderId: order.orderId,
                        userId: order.userId
                    }
                }
            }

            //发送请求
            this.httpService.post(param, event)
                .then(res => {
                    this.orderDetailData = res;
                    this.orderDetailData.tempBusinessType = this.businessType;
                    this.orderDetailData.tempOrderStatus = this.orderStatusType;
                    this.navCtrl.push(WorkOrderDetailPage, this.orderDetailData)
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            //启动加载提示符
            let loading = this.loadingCtrl.create({
                spinner: 'ios',
                content: '加载中...'
            })
            this.connectService.saveData('loading', loading)
            this.connectService.getData('loading').present();
            //获取测试数据
            setTimeout(() => {
                this.orderDetailData = this.businessType == '0010' ? this.testdataService.contractWorkOrderDetailChecked.data : this.testdataService.flsOrderDetailUnchecked.data;
                this.orderDetailData.tempBusinessType = this.businessType;
                this.orderDetailData.tempOrderStatus = this.orderStatusType;
                this.navCtrl.push(WorkOrderDetailPage, this.orderDetailData)
                this.connectService.getData('loading').dismiss();
            }, 1000);
        }
    }

}
