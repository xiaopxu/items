import { Component, ElementRef } from '@angular/core';
import { NavController, NavParams, ActionSheetController, Events, AlertController } from 'ionic-angular';
import { ToolService } from '../../../providers/tool-service';
import { ConfigService } from '../../../config-servise';
import { ValidatorService } from '../../../providers/validator-service';
import { UploadService } from '../../../providers/upload-service';
import { HttpService } from '../../../providers/http-service';
import { ApiUrlService } from '../../../providers/api-url-service';
import { ConnectService } from '../../../providers/connect-service';


@Component({
    selector: 'page-work-order-detail',
    templateUrl: 'work-order-detail.html'
})
export class WorkOrderDetailPage {

    private orderDetailData: any = [];
    private phoneNumber: string = '';
    private validationCode: string = '';
    private goodsNo: string = '';
    private tempOrderStatus: string = '';
    private tempBusinessType: string = '';
    private base64Img: string = '';
    private uploadStep: string = 'unload';
    private smsId: string = '';
    private invoiceNumber: string = '';
    private invoiceUrl = '';
    private invoiceImgId = '';
    private isOverTime: boolean = false;
    private checkinEnable: boolean = false;
    private hours: any = '';
    private minutes: any = '';
    private seconds: any = '';
    private contractPhone: string = '';

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private toolService: ToolService,
        private validatorService: ValidatorService,
        private uploadService: UploadService,
        private actionSheetCtrl: ActionSheetController,
        private events: Events,
        private ele: ElementRef,
        private httpService: HttpService,
        private connectService: ConnectService,
        private alertCtrl: AlertController
    ) { }

    ionViewDidLoad() {
        this.orderDetailData = this.navParams.data;
        console.warn('订单详情')
        console.log(this.orderDetailData)

        // if (this.orderDetailData.orderEvidenceInvoice) {
        //     this.invoiceUrl = JSON.parse(this.orderDetailData.orderEvidenceInvoice)[0].cloudUrl
        // }
        //如果是待完善资料，回显商品串号、发票号码
        if (this.orderDetailData.orderStoreUserInvoiceNumber) {
            this.invoiceNumber = this.orderDetailData.orderStoreUserInvoiceNumber;
        }
        if (this.orderDetailData.orderDeviceCode) {
            this.goodsNo = this.orderDetailData.orderDeviceCode;
        }
        //获取订单状态类型、业务类型
        this.tempOrderStatus = this.orderDetailData.tempOrderStatus;
        this.tempBusinessType = this.orderDetailData.tempBusinessType;
        //
        this.events.subscribe('upload:img-src', url => {
            this.base64Img = url;
        });
        //变更上传状态，并在上传成功的情况下获取图片信息
        this.events.subscribe('upload:change-step', (step, token?, imgId?) => {
            this.uploadStep = step;
            this.invoiceUrl = token.iobsCloudUrl;
            this.invoiceImgId = imgId;
        })
    }

    ionViewWillEnter() {
        //如果是待处理状态的订单，需要判断是否超时
        if (this.tempOrderStatus == 'unChecked') {
            this.setOrderLimitTime()
        }
    }

    //接收子集传递的smsId
    public getSmsId(smsId: string) {
        this.smsId = smsId;
    }

    public checkin() {
        //字段验证
        if (!this.validatorService.checkGoodsNo(this.goodsNo, '商品串号')) { return };
        if (!this.validatorService.checkPhone(this.phoneNumber, '合约机号')) { return };
        if (!this.validatorService.checkValidationCode(this.validationCode, '验证码')) { return };
        if (!ConfigService.getConfig('devMode')) {
            let param: any = {
                url: ApiUrlService.getApiUrl('clerkCheckInOrder'),
                params: {
                    orderNo: this.orderDetailData.orderId,
                    goodsSerialNo: this.goodsNo,
                    contractPhoneNo: this.phoneNumber,
                    identifyCode: this.validationCode,
                    smsId: this.smsId
                }
            }
            this.httpService.post(param)
                .then(res => {
                    this.navCtrl.pop();
                }).catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            this.navCtrl.pop();
        }
    }

    public showAlert() {
        let alert = this.alertCtrl.create({
            title: '平安租赁',
            subTitle: `该合约号码非常重要，平安租赁将对该手机号进行话费充值，请您再次确认:${this.contractPhone}`,
            buttons: [
                {
                    text: '修改',
                },
                {
                    text: '确认',
                    handler: () => {
                        this.flsCheckin()
                    }
                }
            ]
        });
        alert.present();
    }

    public flsCheckin() {
        //字段验证
        if (!this.validatorService.checkGoodsNo(this.goodsNo, '商品串号')) { return };
        if (!this.validatorService.checkInvoiceNumber(this.invoiceNumber, '发票号码')) { return };
        if (!this.validatorService.checkPhone(this.contractPhone, '手机号')) { return };
        if (!this.invoiceUrl) { this.toolService.showAlert('请上传发票照片'); return }

        //生成发票照片数组
        let invoiceArray: any[] = []
        let invoicePicObj: any = {
            picId: Date.now().toString(),
            picType: "1",
            picName: "发票信息",
            cloudKey: this.invoiceImgId,
            cloudUrl: this.invoiceUrl,
            mIsCheck: false,
            checkResult: false,
            checkResultArray: [],
            otherContent: ""
        };
        invoiceArray.push(invoicePicObj)

        //发送请求
        if (!ConfigService.getConfig('devMode')) {
            let param: any = {
                url: ApiUrlService.getApiUrl('stageClerkCheckInOrder'),
                params: {
                    storeUserId: this.connectService.getData('loginStatus').storeUserId,
                    orderId: this.orderDetailData.orderId,
                    userId: this.orderDetailData.userId,
                    orderDeviceCode: this.goodsNo,
                    orderStoreUserInvoiceNumber: this.invoiceNumber,
                    orderInvoicePic: JSON.stringify(invoiceArray),
                    orderContractNumber: this.contractPhone
                }
            }
            this.httpService.post(param)
                .then(res => {
                    this.toolService.clearTimeArray()
                    this.toolService.showAlert('登记成功')
                    this.navCtrl.pop();
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            this.navCtrl.pop();
        }
    }

    public uploadPhoto() {
        //如果已经有上传完毕的照片，则不允许重新上传
        if (this.uploadStep == 'loaded') { return }
        //获取canvas对象
        let canvas = this.ele.nativeElement.querySelector('canvas');
        //调用actionSheet弹出层
        let actionSheet = this.actionSheetCtrl.create({
            title: '选择上传方式',
            buttons: [
                {
                    text: '拍摄',
                    role: 'destructive',
                    handler: () => {
                        this.uploadStep = 'loading'
                        this.uploadService.takePicture(canvas)
                    }
                }, {
                    text: '从相册选择',
                    role: 'destructive',
                    handler: () => {
                        this.uploadStep = 'loading'
                        this.uploadService.choosePicture(canvas)
                    }
                }, {
                    text: '取消',
                    role: 'cancel',
                    handler: () => {
                        console.log('取消上传');
                    }
                }
            ]
        });
        actionSheet.present();
    }

    public photoPreView(url: string): void {
        this.uploadService.PhotoViewer(url)
    }

    public setOrderLimitTime() {
        this.isOverTime = false;


        //更新页面展示时间
        let setOverTime = () => {
            this.hours = "00"
            this.minutes = "00";
            this.seconds = "00";
        }

        let changeOrderStatusSuccess = (data) => {
            // Datas.Orders = eval("(" + data.orders + ");");;
            // //在返回按钮绑定方法，使回退至list页面时刷新页面
            // $("[data-page='5_flscheckindetails'] .navbar a").on('click', function () {
            //     clearTimer();
            //     reloadPage('index', '5', 'tab-worder');
            // })
            // console.log(Datas.Orders)

            // if (data.retType == "4") {
            //     $('#uploadBtn').attr('disabled', '').css('background', '#b3b3b3');
            //     Current.currentorder.isOverTime = true;
            //     setOrderLeftTime("order-left-hour", "00", "order-left-min", "00", "order-left-sec", "00")
            //     $("#time-left").hide();
            //     $("#orderMsg").text("很抱歉，您的订单操作超时，请及时与客户沟通处理").css("text-align", "center")
            //     myApp.alert("很抱歉，您的订单操作超时，请及时与客户沟通处理")
            // }
        }

        //发送请求，更改订单状态
        let changeOrderStatus = () => {

            let param: any = {
                url: ApiUrlService.getApiUrl('stageClerkCheckInOrderTimeOut'),
                params: {
                    storeUserId: this.connectService.getData('loginStatus').storeUserId,
                    orderId: this.orderDetailData.orderId,
                    userId: this.orderDetailData.userId,
                }
            }
            this.httpService.post(param)
                .then(res => {
                    console.log(res)
                    if (res == {}) {
                        this.toolService.showAlert('服务器错误！')
                        return
                    } else {
                        this.toolService.showAlert('登记成功')
                    }
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        }

        let getOrderLeftTime = () => {
            let orderLimitTime = 24 * 60 * 60 * 1000  //限制24小时
            let nowTime = new Date().getTime();  //获取当前时间
            let deltaTime = nowTime - orderStateChangeTime;  //获取时间差

            if (deltaTime > orderLimitTime) {
                this.checkinEnable = false;
                this.toolService.clearTimeArray()
                setOverTime()
                changeOrderStatus()
            } else {
                let orderLeftTime = orderLimitTime - deltaTime;  //计算剩余时间

                let int_day: any = "0";
                let int_hour: any = "0";
                let int_minute: any = "0";
                let int_second: any = "0";

                if (orderLeftTime >= 86400000) {
                    int_day = Math.floor(orderLeftTime / 86400000)
                    orderLeftTime -= int_day * 86400000;
                }
                if (orderLeftTime >= 3600000) {
                    int_hour = Math.floor(orderLeftTime / 3600000)
                    orderLeftTime -= int_hour * 3600000;
                }
                if (orderLeftTime >= 60000) {
                    int_minute = Math.floor(orderLeftTime / 60000)
                    orderLeftTime -= int_minute * 60000;
                }
                if (orderLeftTime >= 1000) {
                    int_second = Math.floor(orderLeftTime / 1000)
                }

                if (int_hour < 10) {
                    int_hour = "0" + int_hour;
                }
                if (int_minute < 10) {
                    int_minute = "0" + int_minute;
                }
                if (int_second < 10) {
                    int_second = "0" + int_second;
                }

                let str_time = int_hour + "小时" + int_minute + "分" + int_second + "秒";

                // console.log("详情登记剩余时间:" + str_time)

                this.hours = int_hour;
                this.minutes = int_minute;
                this.seconds = int_second;

                if (int_minute == 0 && int_second == 0) {
                    this.toolService.clearTimeArray();
                    this.checkinEnable = false
                    setOverTime()
                    changeOrderStatus()
                    return;
                }
            }
        }

        let startTime = () => {
            this.toolService.clearTimeArray();
            let timer = setInterval(() => {
                getOrderLeftTime()
            }, 300);
            this.connectService.commonData.timeIntervalArray.push(timer);
        }

        let orderStateChangeTime: any = new Date(this.orderDetailData.orderStateChangeTime.substring(0, 19).replace(/-/g, '/'))
        orderStateChangeTime = Date.parse(orderStateChangeTime)
        startTime();
    }
}
