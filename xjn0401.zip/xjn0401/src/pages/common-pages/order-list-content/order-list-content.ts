import { Component, Input } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ConnectService } from '../../../providers/connect-service';

@Component({
    selector: 'page-order-list-content',
    templateUrl: 'order-list-content.html'
})
export class OrderListContentPage {

    @Input() currentPage: string = '';  //页面组件（工单 or 业绩 or 验单）
    @Input() order: any[] = [];  //订单数据
    @Input() businessType: string = '';  //业务线（合约机 or 小件均）

    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        public connectService: ConnectService
    ) {
        console.log('ionViewDidLoad OrderListContentPage');
    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad OrderListContentPage');
    }

}
