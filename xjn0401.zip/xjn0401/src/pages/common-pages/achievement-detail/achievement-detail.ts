import { Component } from '@angular/core';
import { NavController, NavParams, Events, LoadingController } from 'ionic-angular';
import { TestdataService } from '../../../providers/testdata-service';
import { ConnectService } from '../../../providers/connect-service';
import { ToolService } from '../../../providers/tool-service';
import { HttpService } from '../../../providers/http-service';
import { ConfigService } from '../../../config-servise';
import { ApiUrlService } from '../../../providers/api-url-service';


@Component({
    selector: 'page-achievement-detail',
    templateUrl: 'achievement-detail.html'
})
export class AchievementDetailPage {
    private businessType: string = this.connectService.getData('loginStatus').bussinessType;
    private listData: any = [];  //当前获取到的订单数据（当前一次请求的数据（0-pageSize条））
    private orderDateExist: string[] = [];  //已存在的时间分类（缓存）
    private displayOrders: any = [];  //经过时间分类处理的订单数据（缓存）
    private pageNumber: number = 0;
    private pageSize: number = 10;
    private month: string = '';

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private testdataService: TestdataService,
        private events: Events,
        private connectService: ConnectService,
        private toolService: ToolService,
        private loadingCtrl: LoadingController,
        private httpService: HttpService
    ) { }

    //生命周期：页面加载完毕（只在首次加载时被调用）
    ionViewDidLoad() {
        console.warn('========================进入AchievementDetailPage============================')
    }
    //生命周期：即将进入页面
    ionViewWillEnter() {
        this.month = this.navParams.data;
        this.pageNumber = 0;
        this.clearOrderList()
        this.getAchievementDetailList();  //获取订单

        this.events.subscribe('getOrdersByDateComplete', (orderDateExist, displayOrders) => {
            this.orderDateExist = orderDateExist;
            this.displayOrders = displayOrders;
        })
    }

    /**
     * @description 上拉加载方法
     * @param {*} infiniteScroll infiniteScroll实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    public doInfinite(infiniteScroll: any): void {

        this.getAchievementDetailList(infiniteScroll) //获取订单

        //如果获取到的订单数量少于pageSize，则使上拉加载不可用
        if (this.listData.length < this.pageSize) {
            infiniteScroll.enable(false);
            return
        }

        this.pageNumber++;
    }

    /**
     * @description 下拉刷新方法
     * @param {*} refresher refresher实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    public doRefresh(refresher: any): void {
        this.pageNumber = 0;
        this.clearOrderList()
        this.getAchievementDetailList(refresher)  //获取订单
    }

    /**
     * @description 请求工单数据
     * @param {*} ionEvent 上拉加载实例 or 下拉刷新实例
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    private getAchievementDetailList(ionEvent?: any): void {

        //获取订单数据
        if (!ConfigService.getConfig('devMode')) {
            //设置请求参数
            let param = {
                url: ApiUrlService.getApiUrl('getClerkPerformanceDetail'),
                accountId: this.connectService.getData('loginStatus').storeUserId,
                params: {
                    pageNumber: this.pageNumber,
                    pageSize: this.pageSize,
                    month: this.month
                }
            }
            //发送请求
            this.httpService.post(param, ionEvent)
                .then(res => {
                    this.listData = res.list;
                    this.clearOrderList();
                    this.handleDisplayOrders(this.listData);
                    if (ionEvent) {
                        ionEvent.complete()
                    }
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        }
    }

    /**
     * @description 将listData按照时间分类加入到displayOrders中缓存
     * @param {any[]} listData 订单数组
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    private handleDisplayOrders(listData: any[]): void {

        this.toolService.setOrdersByDate(listData)

        console.warn('工单数据刷新完毕')
        console.log(this.displayOrders)
    }

    /**
     * @description 清空已有的订单数据缓存
     * @returns {void}
     * @memberOf ShopAssistantWorkOrdersPage
     * @author xjn
     * @date 2017年3月27日
     */
    private clearOrderList() {
        this.connectService.commonData.orderDateExist = [];
        this.connectService.commonData.displayOrders = [];
    }

}
