import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ConfigService } from '../../../config-servise';
import { HttpService } from '../../../providers/http-service';
import { ToolService } from '../../../providers/tool-service';
import { ConnectService } from '../../../providers/connect-service';
import { ValidatorService } from '../../../providers/validator-service';
import { ApiUrlService } from '../../../providers/api-url-service';

@Component({
    selector: 'page-validation-code',
    templateUrl: 'validation-code.html'
})
export class ValidationCodePage {
    @Input() phoneNumber: string = '';
    @Input() userName?: string = '';

    //用setter/getter，将接收到的businessType做二次处理
    private _businessType: string;
    @Input()
    private set businessType(businessType: string) {
        if (businessType == 'register') {
            this._businessType = '1';
        } else if (businessType == 'findPwd') {
            this._businessType = '2';
        } else if (businessType == 'checkContract') {
            this._businessType = '3';
        } else if (businessType == 'checkFls') {
            this._businessType = '4';
        }
    }
    private get businessType() {
        return this._businessType;
    }

    /**
     * @description 输出smsId给父级的方法
     * @type {EventEmitter<string>}
     * @memberOf ValidationCodePage
     * @author xjn
     * @date 2017年3月24日
     */
    @Output() returnSmsId: EventEmitter<string> = new EventEmitter();

    private vCodeStep: string = 'notSend';  //发送验证码状态，初始为未发送
    private limitTime: number = 60;  //倒计时初始时间

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private config: ConfigService,
        private http: HttpService,
        private toolService: ToolService,
        private connectService: ConnectService,
        private validatorService: ValidatorService
    ) { }

    ionViewDidLoad() {
        console.log('ionViewDidLoad ValidationCodePage');
    }
    /**
     * @description: 发送验证码请求
     * @param {string} phoneNumber
     * @returns {void}
     * @memberOf ValidationCodePage
     * @author xjn
     * @date 2017年3月14日
     */
    public getValidationCode(): void {
        //参数校验
        if (!this.validatorService.checkPhone(this.phoneNumber, '手机号')) { return }
        // if(!this.validatorService.checkUserName(this.userName, '用户名')){ return }

        //设置查询验证码进度状态，设置为发送中
        if (this.vCodeStep == 'notSend' || this.vCodeStep == 'reSend') {
            this.vCodeStep = 'sending'
        }

        //设置请求参数
        let param: any = {
            url: ApiUrlService.getApiUrl('sendSms'),
            accountId: this.userName || '',
            params: {
                smsPhone: this.phoneNumber || '',
                appName: 'APP_PARTNER',
                smsBusinessType: this.businessType
            }
        }
        //发送请求
        if (!ConfigService.getConfig('devMode')) {
            this.http.post(param)
                .then(res => {
                    console.log('验证码发送成功')
                    //向父级传递smsId
                    this.returnSmsId.emit(res.smsId)
                    //启动定时器
                    this.vCodeTimer();
                })
                .catch(err => {
                    this.http.handleErr(err)
                    this.toolService.clearTimeArray();
                    this.vCodeStep = 'reSend';
                })
        }
    }

    /**
     * @description 验证码倒计时定时器
     * @private
     * @returns {void}
     * @memberOf ValidationCodePage
     * @author xjn
     * @date 2017年3月14日
     */
    private vCodeTimer() {
        this.limitTime = 60;
        let vCodeTimer = setInterval(() => {
            if (this.limitTime <= 1) {
                this.toolService.clearTimeArray();
                this.vCodeStep = 'reSend';  //设置状态为重新发送
            }
            this.limitTime--
        }, 1000);
        //将定时器加入列表中，方便遍历清除
        this.connectService.commonData.timeIntervalArray.push(vCodeTimer)
    }

}
