import { Component } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';
import { ToolService } from '../../../providers/tool-service';
import { TestdataService } from '../../../providers/testdata-service';
import { ConnectService } from '../../../providers/connect-service';
import { HttpService } from '../../../providers/http-service';
import { ConfigService } from '../../../config-servise';
import { ValidatorService } from '../../../providers/validator-service';
import { ApiUrlService } from '../../../providers/api-url-service';

@Component({
    selector: 'page-register',
    templateUrl: 'register.html'
})
export class RegisterPage {

    private userName: string = '';
    private phoneNumber: string = '';
    private validationCode: string = '';
    private userPwd: string = '';
    private checkPwd: string = '';
    private idNumber: string = '';
    private idName: string = '';
    private operatorList: any[] = [];
    private supplierList: any[] = [];
    private storeList: any[] = [];
    private selectedOperator: any = '';
    private selectedSupplier: any = '';
    private selectedStore: any = '';
    private smsId: string = '';

    constructor(
        private navCtrl: NavController,
        private navParams: NavParams,
        private toolService: ToolService,
        private testData: TestdataService,
        private connectService: ConnectService,
        private events: Events,
        private httpService: HttpService,
        private validatorService: ValidatorService
    ) { }

    ionViewDidLoad() {
        console.log('ionViewDidLoad RegisterPage');

        //清除验证码定时器
        this.toolService.clearTimeArray();

        //获取运营商列表
        this.events.subscribe('register:operator', data => {
            this.selectedOperator = data;
        });
        //获取供应商列表
        this.events.subscribe('register:supplier', data => {
            this.selectedSupplier = data;
        });
        //获取门店列表
        this.events.subscribe('register:store', (data) => {
            this.selectedStore = data;
        });
    }

    //提交注册
    public submit(): void {
        //字段校验
        if (!this.validatorService.checkUserName(this.userName, '用户名')) { return };  //用户名
        if (!this.validatorService.checkPwd(this.userPwd, '密码')) { return };  //密码
        if (!this.validatorService.checkCheckPwd(this.checkPwd, '确认密码')) { return };  //确认密码
        if (this.userPwd != this.checkPwd) { this.toolService.showAlert('两次密码不一致') };  //密码一致性
        if (!this.validatorService.checkIdName(this.idName, '姓名')) { return };  //姓名
        if (!this.validatorService.checkIdCard(this.idNumber, '身份证号码')) { return };  //身份证号码
        if (!this.validatorService.checkPhone(this.phoneNumber, '手机号')) { return };  //手机号
        if (!this.validatorService.checkValidationCode(this.validationCode, '验证码')) { return };  //验证码
        if (!this.selectedOperator) { this.toolService.showAlert('请选择运营商') }  //运营商
        if (!this.selectedSupplier) { this.toolService.showAlert('请选择供应商') }  //供应商
        if (!this.selectedStore) { this.toolService.showAlert('请选择门店') }  //门店

        //请求参数
        let param: any = {
            url: ApiUrlService.getApiUrl('register'),
            params: {
                storeUserAccountName: this.userName,
                storeUserPwd: this.toolService.encryptByMd5(this.userPwd),
                storeUserName: this.idName,
                storeUserIdentityCardNumber: this.idNumber,
                storeUserPhoneNumber: this.phoneNumber,
                verificationCode: this.validationCode,
                storeUserPartner: this.selectedOperator.key,
                storeUserCompany: this.selectedSupplier.key,
                storeId: this.selectedStore.key,
                smsId: this.smsId
            }
        }

        //发送请求
        if (!ConfigService.getConfig('devMode')) {
            this.httpService.post(param)
                .then(res => {
                    console.log('注册成功')
                    this.navCtrl.pop();
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            this.navCtrl.pop();
        }
    }

    /**
     * @description 接收子集传递的smsId
     * @param {string} smsId
     * @returns {void}
     * @memberOf RegisterPage
     * @author xjn
     * @date 2017年3月24日
     */
    public getSmsId(smsId: string): void {
        this.smsId = smsId;
    }

    /**
     * @description 请求运营商列表
     * @returns {void}
     * @memberOf RegisterPage
     * @author xjn
     * @date 2017年3月23日
     */
    public getOperatorList(): void {
        let param: any = {
            url: ApiUrlService.getApiUrl('getOperators')
        }
        if (!ConfigService.getConfig('devMode')) {
            //发送请求
            this.httpService.post(param)
                .then(res => {
                    this.operatorList = res;
                    this.toolService.showRadio('选择运营商', this.operatorList, 'register:operator')
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            this.operatorList = this.testData.operatorList.data;
            this.toolService.showRadio('选择运营商', this.operatorList, 'register:operator')
        }

    }

    /**
     * @description 请求供应商列表
     * @returns {void}
     * @memberOf RegisterPage
     * @author xjn
     * @date 2017年3月23日
     */
    public getSupplierList(): void {
        let param: any = {
            url: ApiUrlService.getApiUrl('getCompanies'),
            params: {
                id: this.selectedOperator.key
            }
        }
        if (!ConfigService.getConfig('devMode')) {
            //发送请求
            this.httpService.post(param)
                .then(res => {
                    this.supplierList = res;
                    this.toolService.showRadio('选择供应商', this.supplierList, 'register:supplier')
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            this.supplierList = this.testData.supplierList.data;
            this.toolService.showRadio('选择供应商', this.supplierList, 'register:supplier')
        }

    }

    /**
     * @description 请求门店列表
     * @returns {void}
     * @memberOf RegisterPage
     * @author xjn
     * @date 2017年3月23日
     */
    public getStoreList(): void {
        let param: any = {
            url: ApiUrlService.getApiUrl('getStores'),
            params: {
                id: this.selectedSupplier.key
            }
        }
        if (!ConfigService.getConfig('devMode')) {
            //发送请求
            this.httpService.post(param)
                .then(res => {
                    this.storeList = res;
                    this.toolService.showRadio('选择门店', this.storeList, 'register:store')
                })
                .catch(err => {
                    this.httpService.handleErr(err)
                })
        } else {
            this.storeList = this.testData.storeList.data;
            this.toolService.showRadio('选择门店', this.storeList, 'register:store')
        }
    }
}
