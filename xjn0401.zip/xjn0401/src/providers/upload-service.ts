import { Injectable } from '@angular/core';
import { Camera, PhotoViewer } from 'ionic-native';
import { TestdataService } from './testdata-service';
import { Events } from 'ionic-angular';
import { ConnectService } from './connect-service';
import { HttpService } from './http-service';
import { ApiUrlService } from './api-url-service';
import { UUID } from 'angular2-uuid';
import { ConfigService } from '../config-servise';
import { Http, Headers, RequestOptions } from '@angular/http';
import { ToolService } from './tool-service';

@Injectable()
export class UploadService {

    private base64Img: string = '';

    constructor(
        private testdataService: TestdataService,
        private events: Events,
        private connectService: ConnectService,
        private httpService: HttpService,
        private _http: Http,
        private toolService: ToolService
    ) { }

    //转化成blob流
    public b64toBlob(b64Data, contentType, sliceSize?) {
        contentType = contentType || '';
        sliceSize = sliceSize || 512;

        var byteCharacters = atob(b64Data);
        var byteArrays = [];

        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);

            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);

            byteArrays.push(byteArray);
        }

        var blob = new Blob(byteArrays, {
            type: contentType
        });
        return blob;
    };


    //图片过大时，压缩图片
    public compress(img) {
        var canvas = document.createElement("canvas");
        var ctx = canvas.getContext('2d');
        var tCanvas = document.createElement("canvas");
        var tctx = tCanvas.getContext("2d");
        var maxsize = 10 * 1024;
        var initSize = img.src.length;
        var width = img.width;
        var height = img.height;
        //如果图片大于四百万像素，计算压缩比并将大小压至400万以下
        var ratio;
        if ((ratio = width * height / 8000000) > 1) {
            ratio = Math.sqrt(ratio) - 0.1;
            width /= ratio;
            height /= ratio;
        } else {
            ratio = 1;
        }
        canvas.width = width;
        canvas.height = height;
        //铺底色
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        //如果图片像素大于100万则使用瓦片绘制
        var count;
        if ((count = width * height / 1000000) > 1) {
            count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片
            //计算每块瓦片的宽和高
            var nw = ~~(width / count);
            var nh = ~~(height / count);
            tCanvas.width = nw;
            tCanvas.height = nh;
            for (var i = 0; i < count; i++) {
                for (var j = 0; j < count; j++) {
                    tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);
                    ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
                }
            }
        } else {
            ctx.drawImage(img, 0, 0, width, height);
        }
        //进行最小压缩
        var ndata = canvas.toDataURL('image/jpeg', 0.5);
        console.log('压缩前：' + initSize);
        console.log('压缩后：' + ndata.length);
        console.log('压缩率：' + ~~(100 * (initSize - ndata.length) / initSize) + "%");
        tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0;
        if (ndata) {
            //myApp.alert("压缩成功")
        }
        return ndata;
    };

    public uploadBlob(token, blob, id, i, u, t, f, a, c, imgId) {
        let fd = new FormData();
        fd.append('file', blob, 'invoice-photo' + '.jpg');
        fd.append("token", token.iobsToken);

        let url = token.iobsUrl + imgId;
        console.log(url);

        // let xhr = new XMLHttpRequest();
        // xhr.open('POST', url, true);
        // xhr.onload = e => {
        //     this.events.publish('upload:change-step', 'loaded', token, imgId)
        // };
        // xhr.send(fd);

        let headers: Headers = new Headers({ 'Content-Type': 'application/json' });
        let options: RequestOptions = new RequestOptions({ headers: headers });
        this._http.post(url, JSON.stringify(fd), options)
            .map(res => res.json())
            .subscribe(
            //请求成功
            res => {
                this.events.publish('upload:change-step', 'loaded', token, imgId)
            },
            //请求失败
            err => {
                console.log(err)
                this.base64Img = ''
                this.events.publish('upload:img-src', this.base64Img)
                this.events.publish('upload:change-step', 'unload', token, imgId)
                this.toolService.showAlert('服务器错误！')
            })
    }

    public uploadCloudImage(basestr, i, u, canvas, f, b, c) {
        let imgId = UUID.UUID().toUpperCase();
        let userId: string = this.connectService.getData('loginStatus').storeUserId;
        let param: any = {
            url: ApiUrlService.getApiUrl('uploadCloud'),
            sessionToken: this.connectService.getData('loginStatus').userSession,
            params: {
                userId: userId,
                iobsUuid: imgId
            }
        }
        this.httpService.post(param)
            .then(res => {
                let iden = basestr.indexOf(',');
                let blob = this.b64toBlob(basestr.substring(iden + 1), 'image/png');
                this.uploadBlob(res, blob, 'test', i, u, canvas, f, b, c, imgId);

            })
            .catch(err => {
                this.httpService.handleErr(err);
            })
    };

    //canvas预览及上传云端
    public onDealImage(i, s, o, canvas, f, a, c) {
        console.log(canvas)
        let H = 150, W = 200;
        if (canvas) {
            this.drawImageCanvas(canvas, i, W, H);
        }
        if (i.naturalWidth > 2000 || i.naturalHeight > 2000) {
            let data = this.compress(i);
            this.uploadCloudImage(data, s, o, canvas, f, a, c);
        } else {
            this.uploadCloudImage(i.src, s, o, canvas, f, a, c);
        }

    };

    //canvas绘制预览图片
    public drawImageCanvas(canvas, i, iw, ih) {
        console.log(canvas)
        let ctx = canvas.getContext("2d")
        var expectWidth = i.naturalWidth;
        var expectHeight = i.naturalHeight;

        canvas.style.width = '';
        canvas.style.height = '';

        var imgHeight = ih;
        var imgWidth = iw;

        canvas.height = imgHeight;
        canvas.width = imgWidth;
        ctx.drawImage(i, 0, 0, expectWidth, expectHeight, 0, 0, imgWidth, imgHeight);
    };

    public onDealImageBase64Details(base64, s, o, t, f, a, c) {
        //测试用的虚拟图片对象
        let image = document.getElementById('hiddenloadimg');
        image.onload = () => {
            this.onDealImage(image, s, o, t, f, a, c);
            this.base64Img = ''
            this.events.publish('upload:img-src', this.base64Img)
        };
    };

    //拍摄照片
    public takePicture(canvas): void {
        if (!ConfigService.getConfig('skipCordova').uploadInvoice) {
            const options = {
                quality: 50,
                destinationType: Camera.DestinationType.DATA_URL,
                enodingType: Camera.EncodingType.JPEG,
                mediaType: Camera.MediaType.PICTURE,
                sourceType: Camera.PictureSourceType.CAMERA
            }

            Camera.getPicture(options).then((imageData) => {
                // imageData is either a base64 encoded string or a file URI
                // If it's base64:
                this.base64Img = 'data:image/jpeg;base64,' + imageData;
                this.events.publish('upload:img-src', this.base64Img)
                this.onDealImageBase64Details(this.base64Img, '', '', canvas, '', '', '')
            }, (err) => {
                // Handle error
                console.log(err)
            });
        } else {
            this.base64Img = this.testdataService.testPhoto;
            this.events.publish('upload:img-src', this.base64Img)
            this.onDealImageBase64Details(this.base64Img, '', '', canvas, '', '', '')
        }

    }

    //选择照片
    public choosePicture(canvas): void {
        if (!ConfigService.getConfig('skipCordova').uploadInvoice) {
            const options = {
                quality: 50,
                destinationType: Camera.DestinationType.DATA_URL,
                enodingType: Camera.EncodingType.JPEG,
                mediaType: Camera.MediaType.PICTURE,
                sourceType: Camera.PictureSourceType.PHOTOLIBRARY
            }

            Camera.getPicture(options).then((imageData) => {
                // imageData is either a base64 encoded string or a file URI
                // If it's base64:
                this.base64Img = 'data:image/jpeg;base64,' + imageData;
                this.events.publish('upload:img-src', this.base64Img)
                this.onDealImageBase64Details(this.base64Img, '', '', canvas, '', '', '')
            }, (err) => {
                // Handle error
                console.log(err)
            });
        } else {
            this.base64Img = this.testdataService.testPhoto;
            this.events.publish('upload:img-src', this.base64Img)
            this.onDealImageBase64Details(this.base64Img, '', '', canvas, '', '', '')
        }

    }

    //照片预览（需要cordovan插件）
    public PhotoViewer(url: string): void {
        if (!url) {
            console.error('非法参数：url')
            url = '';
        }
        PhotoViewer.show(url, '拍摄照片')
        console.log('photePreView')
    }
}
