import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

/**
 * @title TestdataService
 * @description 保存前端开发测试数据的服务
 * @export
 * @class TestdataService
 * @author xjn
 * @date 2017年3月9日
 */
@Injectable()
export class TestdataService {
    //注册-联级查询运营商
    public operatorList: any = {
        "code": 2000,
        "message": "提示信息",
        "data": [
            { "key": "1", "value": "运营商test1" },
            { "key": "2", "value": "运营商test2" },
            { "key": "3", "value": "运营商test3" },
            { "key": "4", "value": "运营商test4" },
            { "key": "5", "value": "运营商test5" },
            { "key": "6", "value": "运营商test6" },
            { "key": "7", "value": "运营商test7" },
            { "key": "8", "value": "运营商test8" },
            { "key": "9", "value": "运营商test9" },
            { "key": "10", "value": "运营商test10" },
            { "key": "11", "value": "运营商test11" },
            { "key": "12", "value": "运营商test12" },
            { "key": "13", "value": "运营商test13" }
        ]
    }

    //注册-联级查询供应商
    public supplierList: any = {
        "code": 2000,
        "message": "提示信息",
        "data": [
            { "key": "1", "value": "供应商test1" },
            { "key": "2", "value": "供应商test2" },
            { "key": "3", "value": "供应商test3" },
            { "key": "4", "value": "供应商test4" },
            { "key": "5", "value": "供应商test5" },
            { "key": "6", "value": "供应商test6" },
            { "key": "7", "value": "供应商test7" },
            { "key": "8", "value": "供应商test8" },
            { "key": "9", "value": "供应商test9" },
            { "key": "10", "value": "供应商test10" },
            { "key": "11", "value": "供应商test11" },
            { "key": "12", "value": "供应商test12" },
            { "key": "13", "value": "供应商test13" }
        ]
    }

    //注册-联级查询门店
    public storeList: any = {
        "code": 2000,
        "message": "提示信息",
        "data": [
            { "key": "1", "value": "test门店1" },
            { "key": "2", "value": "test门店2" },
            { "key": "3", "value": "test门店3" },
            { "key": "4", "value": "test门店4" },
            { "key": "5", "value": "test门店5" },
            { "key": "6", "value": "test门店6" },
            { "key": "7", "value": "test门店7" },
            { "key": "8", "value": "test门店8" },
            { "key": "9", "value": "test门店9" },
            { "key": "10", "value": "test门店10" },
            { "key": "11", "value": "test门店11" },
            { "key": "12", "value": "test门店12" },
            { "key": "13", "value": "test门店13" }
        ]
    }

    //二维码页面测试数据
    public qrCodeList: any = {
        "code": 2000,
        "message": "提示信息",
        "data": {
            "storeUserName": "张飞",
            "storeName": "运营商test",
            "storeUserCompany": "上海联通",
            "storeUserId": "47",
            "bussinessType": "002001"
        }
    }

    //工单列表测试数据
    public workOrdersList: any = {
        "code": 2000,
        "message": "",
        "data": {
            "count": 13,
            "list": [
                {
                    "orderId": "10765",
                    "userId": "5542",
                    "date": "2016-12-29 20:55:59",
                    "orderStatus": "已完成",
                    "userName": "罗会明",
                    "goodsSellName": "OPPO R9 玫瑰金 全网通 64G"
                },
                {
                    "orderId": "10763",
                    "userId": "5533",
                    "date": "2016-12-29 20:47:18",
                    "orderStatus": "已完成",
                    "userName": "杨立",
                    "goodsSellName": "OPPO R9 玫瑰金 全网通 64G"
                },
                {
                    "orderId": "10734",
                    "userId": "58528aca9a88e15fc019f876",
                    "date": "2016-12-22 21:10:55",
                    "orderStatus": "已完成",
                    "userName": "夏丹",
                    "goodsSellName": "三星J3109 白 "
                },
                {
                    "orderId": "10506",
                    "userId": "3988",
                    "date": "2016-12-02 20:07:51",
                    "orderStatus": "已完成",
                    "userName": "潘志明",
                    "goodsSellName": "三星J3109 白 "
                },
                {
                    "orderId": "10472",
                    "userId": "3958",
                    "date": "2016-11-30 17:03:14",
                    "orderStatus": "已完成",
                    "userName": "疏文涛",
                    "goodsSellName": "三星J3109 白 "
                },
                {
                    "orderId": "10466",
                    "userId": "3922",
                    "date": "2016-11-29 23:06:23",
                    "orderStatus": "已完成",
                    "userName": "李大碧",
                    "goodsSellName": "苹果6S 16GB 玫瑰金 16G"
                },
                {
                    "orderId": "10441",
                    "userId": "3914",
                    "date": "2016-11-29 17:55:43",
                    "orderStatus": "已完成",
                    "userName": "吴艳",
                    "goodsSellName": "三星J3109 白 "
                },
                {
                    "orderId": "10405",
                    "userId": "3865",
                    "date": "2016-11-29 09:21:28",
                    "orderStatus": "已完成",
                    "userName": "全志岗",
                    "goodsSellName": "苹果6S 16GB 玫瑰金 16G"
                },
                {
                    "orderId": "10400",
                    "userId": "3850",
                    "date": "2016-11-26 00:04:16",
                    "orderStatus": "已完成",
                    "userName": "杨心健",
                    "goodsSellName": "三星J3109 白 "
                },
                {
                    "orderId": "10407",
                    "userId": "3870",
                    "date": "2016-11-26 00:04:16",
                    "orderStatus": "已完成",
                    "userName": "徐嘉农",
                    "goodsSellName": "三星J3109 白 "
                }
            ]
        }
    }

    public workOrderStageList: any = {
        "code": 2000,
        "message": "",
        "data": {
            "count": 3,
            "list": [
                {
                    "orderId": "00200120170309111113499",
                    "userId": "58aaa0df2e87033f4a4d2099",
                    "date": "2017-03-09 11:11:13 499",
                    "orderStatus": "已处理",
                    "goodsModule": "3005",
                    "userName": "杨慧"
                },
                {
                    "orderId": "00200120170307180107668",
                    "userId": "58aa9a382e87033f4a4d2093",
                    "date": "2017-03-07 18:01:07 668",
                    "orderStatus": "已处理",
                    "goodsModule": "3005",
                    "userName": "郭佳"
                },
                {
                    "orderId": "00200120170227200345482",
                    "userId": "58b3e47b2e8703c8def86eb6",
                    "date": "2017-02-27 20:03:45 482",
                    "orderStatus": "已处理",
                    "goodsModule": "3005",
                    "userName": "袁文利"
                }
            ]
        }
    }



    //工单详情测试数据（合约机已完成）
    public contractWorkOrderDetailChecked: any = {
        "code": 2000,
        "message": "",
        "data": {
            "orderId": "10765",
            "userId": "5542",
            "userName": "罗会明",
            "subsidyPrice": "1290.0",
            "orderStatus": "4",
            "firstPrice": "1209",
            "sellPrice": "2499",
            "sellName": "OPPO R9 玫瑰金 全网通 64G",
            "suiteName": "天翼129套餐",
            "date": "2016-12-29 20:55:59",
            "businessType": "手机＋宽带",
            "type": "1"
        }
    }

    //工单详情测试数据（合约机未完成）
    public contractWorkOrderDetailUnChecked: any = {
        "code": 2000,
        "message": "",
        "data": {
            "orderId": "10765",
            "userId": "5542",
            "userName": "罗会明",
            "subsidyPrice": "1290.0",
            "orderStatus": "4",
            "firstPrice": "1209",
            "sellPrice": "2499",
            "sellName": "OPPO R9 玫瑰金 全网通 64G",
            "suiteName": "天翼129套餐",
            "date": "2016-12-29 20:55:59",
            "businessType": "手机＋宽带",
            "type": "0"
        }
    }

    public flsOrderDetailUnchecked = {
        "code": 2000,
        "message": "",
        "data": {
            'orderId': "2123232323223232332",//订单id
            'userId': "2332323wefsdfwe2f",//用户id
            'userName': "张三",//用户姓名
            'goodsSellName': '',//售品名称
            'goodsSuiteName': "无",//套餐名称 即套餐类型
            'orderCreateTime': "2017-03-09 11:08:48 032",//下单时间
            'goodsSuiteStageNumber': "12",//分期期数
            'goodsSuitePayFirstPrice': "2333",//期初支付
            'goodsSuitePayInitialPrice': "200",//自付金额
            'goodsSuiteStagePrice': "233",//每期金额
            'orderProductPrice': "5000",//商品价格
            'orderDeviceCode': "323232232",//唯一编码 商品串号
            'orderStoreUserInvoiceNumber': "23323223",//店员发票号码
            'orderEvidenceInvoice': "",
            'orderReCheckNotes': "没问题",//发票复核意见
            'orderStatus': "待登记货物",
            'baseBusinessType': "小件均分期手机"
        }
    }


    public testPhoto: any = `data:image/PNG;base64,iVBORw0KGgoAAAANSUhEUgAAAT0AAAI1CAYAAACkIC1tAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAG2QSURBVHhe7b15lCTVfeerw19znv0Yj5mxPB4vzPbMmeFgPMPT0xnPMINGHmELnoUYBPazscDsAoMAgcRmhCRACLVRg6BpNUvvTdNN7/u+N73v+0bvC01vlVlVXV11X35u56+4FRWRlVkVWUvG93PO72RmxI17f7Hcb/zuEpFfyOfzrq6uztvZs2fdmTNnWj9Pnz7t7dSpUzKZTNbrzTQr1DE+TePQuy/w5dy5c35FnNh99tln7uTJk23s008/bbcMI61MJpNVy0K9idMh0sSJH4bOoXde9LwS3vFrMplMVpNW//6D7pNPPvH2BVPBuIQymUxWC9ZG9Aj/sLiEMplMVgvWLtKj7RuXUCaTyWrB2kV6Ej2ZTFbL1kb0bJQ2LqFMJpPVgrUTPYZ54xLKZDJZLVgb0SPKY35LXEKZTCarBZPoyWSyTJlETyaTZcokejKZLFPWTvR4hi0uoUwmk9WCKdKTyWSZMomerJ3lfvDHrnn/Rnd+1pv+d8PAu5yrP+tK0fLZIVf/0z9vzaPp4zHuwtYFLvf0f25dhjUOf9y1HN/jGoY83Lqso/ybD21pTUsZlNW04P3WZVEjP9LwGbdelm2T6Mli7fzElwtCdM5dWDnO1d3/xXbrL2ye20aMolbf7xuu5eRB17zr49ZljaOfdi1njrnzswe0SRta08LBruXoTpf7/h+1LguFLu57JZA+FGdZ9kyiJ0u085NecS2HtsaKRJLolRMVGtHtEbqWw9tc0/IP2ixPEr0wTWiK9GSlTKIn65SVEr2o4Jyf8JJv0obiiWhFt28c85xz5+uLkngRyytJ9MjbNTUWU3dMKbGUZcPaiB6PoGn0VkaT9qJCNHpRiU2TcqRHlNd8YKPP15ZdWDPZNR/c7Op//v8mil6cxQmvTGYm0ZPFmheXQnTWGdGLCk45kd756b9wLaePuoa3/tb/zv/of7iWE/t8H18odOH3SqM8Twkhl2XDJHqyWOuK6FUa6dW/fptrOXXYNS0a6lqO7XLN2xa5pqUjnDt7wjUMuCNR9KJlY74f8tQR3xfJCHJcGlm2TaIni7WuiF6lkV7T/HfchQ0z/Shxw7v3F4Rvt3Mtze7C2il+fbmi50eHTx50jeN+7Breuc+L3/kpP3eNY/7BNe/f4FzdSdf4wVPttpNlyyR6slgLRY85dc17Vrn6n93Yuj5J9OIsTvSSjHl9zBFsOb7XN3FZ1qHoFcSSZjCDIKFPftpNY97ndX7yq+3mDMqyaRI9WaxdFL29rnnH0oJw5AoiN6eNaMSJHssqJuhjq3/5et8sJSJrGPz3bfI2i4rexciw0CQ+uNk1LR/dxqf8T/6naxz2mE/fvG/dxQnRMXMOZdkyiZ4s1hoG3eNc/kzBThcipp96scg/+//4dblH/71r3r2yICRr220XZ+VEeo0f/bAgdp/55mnDwL+LTYPVv/FXfoIzTWKEkcEO/+QI0d7iYYXtD3iBJi937lM/MIK/TQvecy2f7r84WFIQyri8ZdkwiZ4s1s6P/4mfQlLf/1sXlxVEhYnDrdSf883H6HZx1qHoFfJGqBjAsCZt1Jp3LisW7FzL2eO+zy6a5sL66X7dhdUT/ABIdL1Mhkn0ZDJZpkyiJ5PJMmUSPZlMlimT6MlkskyZRE8mk2XKJHoymSxTJtGTyWSZMomeTCbLlEn0ZDJZpkyiJ5PJMmUSPZlMlimLFb1c/9tc7hcxxvJS65KWx63rKK9KtrHlndkmurzUuo62qXR5WtukmZetS1remW3ilndkaZbV2bzS2qY78kpaXmpdT2+TtLzUuo62iVsesfr3YkSvoaFBJpPJatKampokejKZLDsm0ZPJZJkyiZ5MJsuUSfRkMlmmTKInk8kyZbGix6dMJpPVop07d6696KGEMplMVot2/vz59qInhBC1yoULFyR6QojsINETQmQKiZ4QIlNI9IQQmUKiJ4TIFBI9IUSmkOgJITKFRE8IkSkkekKITCHRE0JkComeECJTSPSEEJlCoieEyBQSPSFEh/BKpnw+786ePetOnTrlTp486bXixIkT3vjOMtaRhrRs0xuR6AkhYuG9c7xwE004evSoO3z4sDt06FBZRlq2YVvyIK/egkRPCNGGxsZGH7EhWnFCRmRnUV1oLGNdnECyjDTk3dNUVfQWL17s7rvvPh/qlgPpnnjiCbdt27bikp6H48E+2HF54YUX3CWXXNLOrr/+et0wRJ+G5ujp06fbiB3ihZDRZOX/JRCMlpaW4hbtYR1pSMs2bBsKIHlTRk82fXtU9GbNmuWGDBnSegCioscBHDFihBszZoz/HTJjxgx36aWXumHDhhWXXOT48ePupZdecldccYUXo29+85tux44dxbXxUN6DDz7oT0iUqOiVgnyuvvrqdoKIkQfCGC6L+g7z5893Tz/9tL9ohOguqHvUHROnI0eO+P+TqK+vd83NzcVUlcO25EFe5Gn5U1a5wVDa9KjoIXZvvPGGe+WVV3wlD0UPwRs7dqx78sknXV1dXXGLi+zdu9fdfvvt7oYbbmgjHFu2bHHXXXedGzp0qN+GPHbv3u369+/vD3wcCN1dd93VThg5DlGRIsorB/xnP95+++1YYQOWx63jhLz88stu/PjxxSVCVA9E6cyZM62CRFRGM7UaN13yJG+L/CiTsrsiqp0hVdFjp55//vnWSC0UPSK20aNH++UhCN+AAQPcsmXL2oje1q1bXb9+/doJJr8fe+wxH+mRtwkHvt92221u+PDh7cJvDmp0GbDstddeSxQmwI9bb73Vn6iOwDd8CoXSjGMRkiR6sGfPHnfPPff4fRKiWlD5ucZMhAgACBaqKULkTRnWhKZsfMCX7iJV0du0aZNvJlpkFooeQvaNb3zDR2lJhKIXByKFqBG5UUYoepR1yy23VCQU9Dfcfffd/uAnMX36dHfllVe6O+64w3300Uexgmb27rvvev+J0sJIjwixEtHjODz00ENu1apVxSVCpAviE0Zd1IXuHGSgLMo04cOX7or4UhM9BInIjAjMCEXPoqoXX3zRF5o0IJBkpKf5ikjhp0VVJhx8PvXUUxXdMRCVRx55JLHpS+RKFIrg/eAHP3ADBw5sjRjjBNqWvfrqq75f7v3333eDBw/2vs+cObNdFJgkesCxHDVqVPGXEOnBNUwdQmww6nxPDCxQJmWbH/hk9auapCZ6NMm++93v+ja6EYoeHDx40N10001u/fr1/ncIkduzzz7r++nuv/9+nzaEfB944IHWbeNEj6Z1JQcN/0r10xG50j9IOQguTXQTVRO41atXu+eee87vP8uI0K699lqf99q1a93ll1/uBQ7RC0USf0uJXkfrhegs1CVEhiiL+l5JoGAQlbEd9Y3vnRUr8sAHi/hC/agWqYgeO03n+4IFC4pLLhIVPQ4M0dLjjz/epqOU70RHU6ZM8cIwb948HxES8hrkFUZJoVkkxeAGw+TlUkr0uAv97Gc/89Eg+2DHhRHnd955p1X0ELFBgwZ5s2UIZHgRmH+h6HWERE9UA65RG7SgedmZCI/6yvb79+93Bw4c8J/87uwEZHywpi6+mV5Ui1REjxnXNAOjBzAqekAE9+ijj/odBISNpiAjtUR7JgwIx8MPP+wPQhzkGUZ63CWIEufMmeN/hyTdiRg8QYDj+jI4sRMmTHDHjh1rFT2OD81r/DOB47sNPLBPpI0T5qjoUebrr7/eehyiqHkr0obKbtNSuK4r6cOj/pghUBs3bvQzI7j2MVo1RGlhukpAMPEJ3/ARX6tFKqKXRJzoGQgkQnDjjTe6JUuW+IMUCgkwjeTmm2/2gxdhZAhR0QNGh7/0pS+5adOm+ROK2JFH0pQVDjD9dQhmEhwPyuFE09SlXzLqKwcR4bZI1fw34iI9tmebffv2+d8hrNNAhkgbJgVzrWO5XK64tGO43sMmMQHJunXr/LVLlId4rFixwu3cudNHfqQjEKoUfDL/8LVaVE30OFCIUNzgAmJEFPPMM894VTeiogdEf0Q9REVsZ8SJHmVyMu6880532WWXeSOSS4oW8YtmeTj4EsVED5/YF8uLk8LUGYvU5s6d630kbVKkhy/cIYGL4zvf+U7syeXOee+991b1xItsQRBgzVpaV9SVcqHecS1u3rzZ96kT4SF4tNrMWIaIrFy50m3fvr2ibiYDn/ANH/G1kki0ElIXPea1XXXVVb6i87lw4cLimo6JE71qwxQaBCbuaQww0bPjwt3smmuu8fvHiG4YgSb5T6RH1MtNACFmWz5HjhzZ7uIzIdbkZJEmPPdKBIWYRFtN5cB1yc2YlhOtHvIjMqPe0IoieEHoCDooIxrolAu+sT2+UkY1SF30+iI8+sXACaLV0+ALEWRv8EXUBnQlIU4ICXW8syASCB+RHdEYrTCCHCIyggFEipYMotgV8BFf8bkzAy0dIdETosahf82ivKQ5qeWASNAyMsGgn4/mLtEZTV+apmmIHj5atNeZvsGOkOgJUcPQfUKdJjJDjMJ+8Uox0aM/r5qih4/kgc/V0COJnhA1CuLBVBBr2nZmcCEkKnoMbtCHl7boAb5aE7crQh2HRE+IGoX+MPrdrGnbmQGMEESCPj3ys6YnI7UIK6O3afXpQTigkfYorkRPiBoFsbBRWyb+Utm7gokeYocomagSiTGSy+8NGzakInr4is/4nvagnkRPiBqFAQHrG+Ozkrl5cSASPI9Ok5OmLIZehN+Zp5eGhuCr+Y6wpolET4gahQjJHu2ibncV+vCYp0eTlikqfDfjN8YUlq6MEIfgM76nPYIr0ROiRqHJSb8YwpHGRF+asQgp+SYZgtfViNLAZ3xP+80rEj0hahREiD4xhKMvPtKIzxI9IUTZSPTikegJUaMgemk2b7sbNW+FEBWR9kBGpXzyyX63ZMny4q+L8Jvl5YDP+N4nBjI42FOnTo19V5zBq5Z4/boZ6SdNmtRmmRn/e2snbenSpbFpQmN2uEF6+00elMEny8JtPvjgg5L+CtHXqGTKytixE1y/fq/HWv/+bxXqxic+3caNm7zBuXN1bsuWrf77qVOnC3V4RpunJ5qaLvh8d+7c5X+vXbvBzZ49z3/viD43ZaUc0YNQhNgGIYx+D9MAIoYlEYpcVFjNEFHmE1k+5fqbBMeMf00jb14XxevuyRO4CHjBIqLK+okTJ7Y5xoTwvHV28uTJbvnyz++KUVE24x/ZSoX7vOLHbh68s5D9tIudi4d88TXuDdNxJPkHTFDl7dOUQ3m8aZo+JNE7SGty8tKly9uI3qpVa9yQISPbiCJp5s37/DVypAuFM2omnEnga6+fnIyAhJUzznglfNi3EAoaO2aVNWrRSK9c0YPwd1geyyyfroged1MEhDlKCBwnCWFatGiRX89jOePGjfPLEQn+Y4Oy+I4frOM3x6bUfnGieNmp5RuHHUPeRM3seB4N+vDDD/37/VjHm50RL97Vxw2hIzryD0FF0MkbY98QvrTvzKJzVPIYGiIUilaIiZ4J2YABgwpR2Kdu06YthWWbC/kfKVwLa1oFjXzC/KgjM2bMbp2/x7qORA9f+9RjaFQAi9QMBIXKwzqD9aHopR3pAb/jBJQ04fLONm+JosKQHhAd/OdkITQIg0EZCAhhewjpS+0Xb1pGTPlMAnFDpOzGgm8IEW91DqEcyquEOP+ikQMPo1O+nSvRs3BdlvvCARO0OIs2b9et21C4Fie61177pXvrrV+5QYMGu8GDh7vt23f65adPnymZH9aR6PWJFw6QERWM2dpUOiKK8OKnsrOMphURCLC+O0SvK5Ee+0Ukh0UreRKIDMeCchCqXbsu9mkAxwbRC32EjkSPCI///ijlA9tH09AkZZ/ZR4N0aYheFESX/Q2jedGzcOOjTlu/XpKAIEIdRXpAupUrV/u+OROwESNGF+r2tMI1vbVwk5/uI7owv0ojPXy0/rw0grAo1I9URM9EDYWmLU5TLKxorEdYiIIQBSpQGGnxWnkqZ7jMrKsDGeG6MNKzSpym6HFnQtQQAE4a38N8KYv9rET0aKLQbOQ1PqXguEbFjHK6Q/RoSnFDoz/T+hBF74DRT2vimvBEKSV6BmkQubfffteNHv2R/40YTppE3fnEzZ+/yItbmDbJSokePlrTNu2RW0hF9FBmIhv6eIDIZvbs2W0ufhM9mkBUQjrjKY/vfFIpqVjR72EaoOKVqnysi4qe/Q7zonPe8iklepWAOCH8dO6z7+SHyHZV9HieMWy2JkEeWEh3iB77yj6z7+rP631wQ7ImrtWjKB2J3sKFSwrX4XafztKagDFCe/bsOffee0PdmjXtb8zRSK8j8NGatvieNqmIHgLGXd76DGiKmQAaJnqkpQLxOxShkFD0olDxkiofsK4c0WN5GAF2dcoKlZ1jgNjbiaKcaPOW/UfA+Bu9kCRR4QTFDWCQPuo720ebt5wHxCi84EjH9iHR41GuKCN49FmyT+E/24neBTdMi/biBjQQsmnT4m+EjY3nC+d3UmH7I4mix/VF9GdpbF0pI12UcACjWt0kqYheiE2ZQKVDqOTRiCMUISqtTeuIM6uEVLy4ymewjrQWUcXlRfSFOJgwk7YrkV6c4IH5EB3IQAjpAghJEhUGLvDX+kFLwWt/wj41BIkIPPqPdJQTFb2OiPNPgtd3YFANMaHLhddAce5CqIPvvDM4VpywCROmFK7tC34Qw0SPT5q1EydO9U1b0owbN7EggG1FtdxID5/wDR/xNe1RWyNV0Ys270IQorCisUM026jQVFT+BcxIM9LDJ/ImL0SJdfQT4KcJSSnR4wCV6tNLEjwDYWX/uAlQDiIU1++VJHpEeIwAl5puYCB2CBD9pvhKhEnZ/HtVCOV0VfQkeH0PnmUlgsJ4RK1SEDlGbBmlRfQYtOjf/00vejNnzmkVxQ0b2kZw5YqePSuMVfNZ4dREjwufznYEJlr5qbBUGmuiUSi/SY9AUimjERLrk0QvLnoLzUSP7RE35soB+0a+jGgS6ZmQcLA7K3qUFecD5QD7tWDBAj9pOTpxGf8Q/aRtETFEq6MBjBBOJNuQD5/MHwTKjIt8o9F3SCn/ktaxLO68iZ6H65d6SiRFS6NakVRnYGoNPplvcXUtLci7y6JHxUZEVq9e3TokTj5MjLXKgMAl5Z1UIUOzyonoxUVEBusQIvxAbEzwDO42jHJy8hE7npAgf6KppMovRK3ANW7NXKaFxLVOuht8sCkq+FbtepiK6Akh+g4MptGERGSo79WMqjqCsvEBX/AJ36qNRE+IjEF/LHXd+s+o8z0R8VEmZZsf+BTt664GEj0hMgjdP4yUIjbW1O3OPj7KsiYtPuCLdY1VG4meEBmFym8RH+LDDANmI1RTfMibMijLBA8f8KW7kOgJkWEQIfrRbHDDoq5ypkhVCnmG0SVlUnZ3RXiGRE8I4UdMbcqICRJ6wGyHrogS25IHeZmwYpTVU7MlJHpCCA8DC0wKtqYnRlRG3xuPmBKpIRilBhtYRxrSsg3bWmSHkTdl9ORUGYmeEKINDDIwMT4UPxNAIjSEjGYqaUJjGetIEwodRl6k6Q0ToiV6QohYeEqCRzbRBJqmUSErZaRlG7YlD/LqLUj0hBAloclKhMaoK9GaRXMmhCZwFgWShrRs0x3z7ipFoieE6BDEi0EJBIP+ODMiOCxcRhrS9kbBA4meECJTSPSEEJlCoieEyBQSPSFEppDoCSEyhURPCJEpJHpCiEwh0RNCZAqJnhAiU0j0hBCZQqInhMgUEj0hRKaQ6AkhMoVETwiRKSR6QohMESt6vAxQJpPJatH4B7Z2osefeshkMlktGm90lujJZLLMmERPJpNlyiR6MpksUybRk8lkmTKJnkwmy5TFit7Zs2dlMpmsJi2Xy7UXPRbKZDJZLVp9fX170RNCiFpFj6EJITKFRE8IkSkkekKITCHRE0JkComeECJTSPSEEJlCoieEyBQSPSFEppDoCSEyhURPCJEpJHpCiEwh0RNCZAqJnhAiU0j0hBAdglDw8k1ezXTu3Dn/XrrTp0+3MZaxjjSkZZveiERPCBHL+fPnvYihCUePHnWHDx92hw4dKstIyzZsSx7k1VuQ6Akh2kCUdurUKS9acUJ24sQJd/LkSZ8mNJaxLk4gWUYa8u5pJHpCCE9TU5NvpoZih3ghZDRd+X8JBKOlpaW4RXtYRxrSsg3bhgJI3pRBWT1FqqLHjvz4xz92GzZsKC6pjHw+75544gm3bdu24pLagD6OJ5980s2fP7+4pLrs2bPHPfTQQ/6CE6IcqHvHjx9vFacjR4449IBXqzc3NxdTVQ7bkgd5kaflT1mU2ROkKnorV650/fr18+K3ePFid8kll8Ta9ddf78uZNWuWGzJkSKvqR0WPu8aIESPcmDFj/G/LkwodPWDDhg1z9913X5vliO9dd93lLr/8cr/dV7/6VTd27FhfHulIH/pldvXVV7t169bFrscH4KTdc8897tJLL3XXXnutmzx5svcXP6LblDLK+vu///vEdRyPcJkdu1KwjwMHDix5RxYCEKUzZ860ChJRGc1UIrW0IU/ytsiPMim7K6LaGVITPZz/4Q9/6MPX/fv3+98GQvHCCy8Uf30O4vPGG2+4V155xR+QUPSosFReIqS6ujqf3kQPoRk5cqRfZkRFj6jqT/7kT9y0adN8PwIHdseOHe6v/uqv3Msvv9wqtMA+/+Vf/mWbCNNEkXzjeP/9993u3bt9vgsWLPDCt2nTpuJa5/PiBhAH5ZF39FhzjMaPHx+7DpK2A7YNxTHJkvZHZA8qP3XeRIi6S12rpgiRN2VYE5qy8QFfuotURA+BQoS2bNniDh486G677Tb/3UgSPUB8BgwY4JYtW9ZG9LZu3epFw0QMyAdx+fa3v+3+63/9r27v3r3FNW1F79ixY+6WW25xc+bMKa79HPy74YYbfFRqsM+Vil54ktj+z/7sz/w+GORFpBYnPFgYsZmYR832xyB9KdEjn1KwXqInAPEJoy66QrpzkIGyKDOMLqsptiGpiB5D0l/72tfcNddc437nd36nXRRWSvRCQtGLg3wQi/Xr17uvfOUr7umnn26N2ELRI93f/u3f+o7UKAj0j370ozZRGPtcqegZlD9x4kT36KOPtkaklWLHB7NIj2UcC4meSBvqgEV4GNdT2PLpLiiTss0PfOqOLplURM+gUlmfXohV6hB+x0U3SWaV2iKkGTNmuC9+8Yv+E0LR4/vzzz+feABZj0jZnY38kkQv9CGMzvjkN8u/9a1v+aauUcm+sU/Yww8/7MsjOqWvcOHChV70Zs6c2SZ96EOIRE+UC11PiAxRFtdSZ5uW1C+zzkLZ+GARX9gtVi1SEz22RfCIdhAToj+DyhYVvShs9+yzz/qm5/333++boVHIxyo9wkqkR3o6RCsVvaeeeqr1ZJNfVyI9hPfrX/96a5O+HAEC8iYdRlP4scce88P59GMicJSP6Nmxw0+WxZ2jcoW2o/0RtQ3XtQ1a0LzsTITHRGObk8e1yCf1v7PiiQ/W1MU3fKwmqYgebXEGB7785S/7kdLLLrvMffTRR8W1HYsegxivvvqqmzJlio9u5s2b51588UV/YENC0QMOEKJH2QwsmOghFLfffnu3NG+BPBFZy9NEj3wtGgzN/AxFj0GgsE8DXyzSK3XsDCuzFKyX6GUXKrtNS6Hfu9I+PIvqqJd0MXGTp+8dW7t2ra9vlqZSEFJ8wjd87KyAlkMqoodo0Tz76U9/6jZv3uyVOzygVLakissBJGJjpJZoz/r0OKDkibAZ5BNt3tEcvPLKK929997bKiaEyYhh0kDGTTfd1GakNS3RY0AGQtEjj9BfE7Oo6EWF0cQxKnpcXHE+SfRER9CKsP4z5o6WC9c36XmiAo3YuXOn27hxoxcoRmGpo6tXr/YiQn0mXWemvFCG+Yev1SIV0TM4OPRtPfLII+7nP/95cWm86CGMVOgbb7zRLVmyxG+LEJjoAVNMbr75Zjd8+HB/EMknKnrkQ+RmIkEeYFNWaHqShiiKfMnvzTffbHMnqVT0OE5vv/126xwj+t+uu+66ViENRa/cSC96fEwco6JH2jBKNSR6ohQEIdasRZgqica4xml+InTMX7XojrrORHiMYIf6yqwIviN8lYJP+GbN3Eoj0XJJRfRwlgNy5513ujvuuMNHaeFBjVZqDuKoUaPcM88840NZIyp6QPRHJX/99de9uERFD6yZG4oe5XOC8InmNnP7iPDmzp3bphkJpUQvKliIBnkTRTJ9hnwZyCACM0LRI4+4Y0oe3BhIh0XLwdgW0aOvE5/ZBsGeMGFCMZfPocy4PKIm0csmiBARFHWlM1EYgQMiRx3heiY/6ibfidAQK/rx16xZ48shfWfAN3wkj84IZzmkInq05RErEzvyiItwQqOiR4kTvb5IqagrPDaIJc0D0oY3BbBIb9++fX7eox032yZKqTIN1kv0sgcCxDWDkFDHOwsiQVRn4onY0dQlImM5LR+Cn85oSAg+UgY+d1Y8S5Fq81YI0fsgAjOh4jnYzoJI8ECACQb9brSmiM5o0hLtIXo0hbsCPlq0F84CSQuJnhA1jLW86CdDjKJdO5Vgokfrg+9Edozipi161oeIz9XQI4meEDUK4sFUEGvaxk3hqgQTPROMUPTo2kpL9ABfrYnbFaGOQ6InRI1CfxiDDda07cwARoiJHtO+MISJCI8+Pfr2GHhIS/TCAY20R3ElekLUKIiFjdoy8ZfK3hUQCQYs6Mujr40oEs0gEmMZQpWW6OErPuO7zchIC4meEDUKAwLWN8Yn/XtdgVfGMT+PZixRHs3bqDFJOQ0NwVfznWg1TSR6QtQoREj2aBd1u6ugDYgeTVkiPubtmfEb48W9aY244jO+pz2CK9ETokZhHh39YghHGhN96SOkGYtOEO2FxjKM9WkNPOAzvhNBpolET4gaxZ5lRTgQo74GPkv0hBBlI9GLR6InRI2SdvO2u1HzVghREWkPZFTKJ5/sd0uWLC/+ugi/WV4O+IzvGsgQQpRFJVNWxo6d4Pr1ez3W+vd/y+3b94lPt3HjJm9w7lyd27Jlq/9+6tRpN3XqjDaDGE1NF3y+O3fu8r/Xrt3gZs+e5793RJ+bssIdZurUqf4ZvSR4ZRL/aWtG+kmTJrVZZsb/3tqdaunSpbFpQmOWuEF6+00elMEny8JtPvjgg5L+CtHXSGty8tKly9uI3qpVa9yQISPbiCJp5s1b6NMA6ULhjJoJZxL42qcmJ5cjehCKENsghNHvYRpAxLAkQpGLCqsZIsrLDi2fcv1NgmM2ffp0nzf/BMfr7u1EcedbsWKFF1XW889p4THmouRdfPxZ+PLlnzcFoqJsxmv4S/Vx8H5Cu3nwzkL20+7w3DHJF1/j3iodR5J/wAx8/vaSciiP9/xxkYreQSWPoSFCoWiFmOiZkA0YMKgQhX3qNm3aUli2uZD/kcJ1tqZV0MgnzI+Ic8aM2a1veGFdR6LXJx5DQ0DCyhlnvBI+7FANBQ2RsMoatWikV67oQfg7LI9llk9XRI8TiYAwYROB4yQhTIsWLfLreSxn3LhxfjknctasWb4svuMH6/jNsSm1X5wo3gJt+cZhx5A3UXPBM2n0ww8/9O/mYx3/QYJ48TeT3BA6oiP/EFQEnbwx9g3hS7s5IjoH12O5LxwwQYuzaPN23boNhWt8onvttV+6t976lRs0aLAbPHi42759p19++jTv1etapNfnXjhABbBIzUBQqDysM1gfil7akR7wO05ASRMu72zzligqelIQHfznDoXQIAwGZSAg9FWEkL7Ufh04cMCLKZ9JIG6IlN1Y8A0h4m3RIZRDeZUQ5x8XTwgPo1O+nSvR83ANUKetXy9JQBChjiI9IN3Klat935wJ2IgRows302mFOrW1cL1P94FAmF+lkR4+Wn9eGnoUJTXRIyMq2Pbt232lI6IIL34qO8toWhGBAOu7Q/S6EumxX0RyWLSSJ4HIcCwoB6HatetiRy5wbBC90EfoSPSI8KZNm1bSB7aPpqFJyj6zjwbp0hC9KIgu+xtG86LnYfSTqInmoglPlFKiZ5AGkXv77Xfd6NEf+d+I4aRJ1J1P3Pz5i7y4hWmTrJTo4aM1bdMeuQXqRyqiZ6JGWEoHJE2xsKKxHmEhCkIUqEBhpMX/X1A5w2VmXR3ICNeFkZ5V4jRFj3AcUUMAuFPxPcyXstjPSkSP5iLNRt5SWwqOa1TMKKc7RI/mNDc0+jOtD1H0Djg31sS1ehSlI9FbuHCJ27p1u09naU3AGKE9e/ace++9oW7NmvbXaDTS6wh8tKYtvqdNKqJHOEpkQx8PENnMnj27zcVvokcTiEpIZzzl8Z1PKiUVK/o9TANUvFKVj3VR0bPfYV50zls+pUSvEhAnhJ/Offad/BDZrooeD3mHzdYkyAML6Q7RY1/ZZ/Zd/Xm9E64di/biBjQQsmnT4q+JxsbzhetvUmH7I4mih6AR/VkaW1fKSBclHMCoVoshFdFDwLjLW0cpTTETQMNEj7RUIH5HBc0IRS8KFS+p8gHryhE9locRYFenrFDZOQaIvd2dKCfavGX/ETDeNBuSJCqcoLgBDNJHfWf7aPOW84AYhXdZ0rF9SPR4lCvKCB59luxT+M92ondB/zJiQuuDFwREo3Gu1XfeGRwrTtiECVMK1/UFP4hhoscnzdqJE6f6pi1pxo2bWLjW2opquZEePuEbPuJr2qO2RiqiF2JTJghNQ6jk0YgjFCEqrU3riDOrhFS8uMpnsI60FlHF5UX0hTiYMJO2K5FenOCB+RAdyEAI6QIISRIVBi7w1/pBS8H/7oZ9alxEROB0HYRQTlT0OiLOPwle34JnWYmgMB5RqxREjhFbRmkRPQYt+vd/04vezJlzWkVxw4a2EVy5omfPCmPVfFY4VdGLNu9CEKKwoqHiNNuo0FRU/pzbSDPSwyfyJi9EiXV0juKnCUkp0eMAlerTSxI8A2Fl/7gJUA4iFNfvlSR6RHiMAMc1SaIgdggQ/ab4SoRJ2bzaO4Ryuip6Ery+B9cE54pIiptutSKpzsDUGnwy3+LqWlqQdyqix8Gksx2BiVZ+KiyVxppoFMpv0iOQVMpohMT6JNGLi95CM9Fje8SNuXLAvpEvI5pEeiYk3GE6K3qUFecD5QD7tWDBAj9pOTpxGf8Q/aRtETFEq6MBjBBOJNuQD5/MHwTKjIt8o9F3SCn/ktaxLO68id4B59qauUwLibtRdzf4YFNU8C3pekyLVEQPpxERXhVt84DIh4mxVhkQuKS8kypkaFY5Eb24iMhgHUKEH4iNCZ5BiM0oJyKN2PGEBPkTTVX7YAvRG6BfmSYkIkOdjLuZdxeUjQ/4gk/4Vm1SET0hRN+BrgnquvWfUed7IuKjTMo2P/Ap2u1TDSR6QmQQWkKMlCI21tTtzj4+yrImLT7gi7USq41ET4iMQuW3iA/xYbCNgblqig95UwZlmeDhA750FxI9ITIMIkQ/mg1uWNRVzmyBSiHPMLqkTMrurgjPkOgJIfwgnk0ZMUFCDxj464oosS15kJcJK0ZZPTVwKNETQngYWGBSsDU9MaIy+t542opIDcEoNdjAOtKQlm3Y1iI7jLwpoycGTgyJnhCiDQwyMEc0FD8TQCI0hIxmKmlCYxnrSBMKHUZepOkNE6IlekKIWHhKgqeX0ASaplEhK2WkZRu2JQ/y6i1I9IQQJaHJSoTGqCvRmkVzJoQmcBYFkoa0bNMd8+4qRaInhOgQBiToh0PI6K9jcIKBiNBYxjrSkLa7R2XLRaInhMgUEj0hRKaQ6AkhMoVETwiRKSR6QohMIdETQmQKiZ4QIlNI9IQQmUKiJ4TIFBI9IUSmkOgJITKFRE8IkSkkekKITCHRE0JkComeECJTxIoeLwKUyWSyWjT+u6Od6PEiQJlMJqtVk+jJZLLMGG92lujJZLLMmERPJpNlyiR6MpksUybRk8lkmbJY0cvlcjKZTFaTxl9VthO906dPy2QyWU0awtdO9IQQolbRY2hCiEwh0RNCZAqJnhAiU0j0hBCZQqInhMgUEj0hRKaQ6AkhMoVETwiRKSR6QohMIdETQmQKiZ4QIlNI9IQQmUKiJ4TIFBI9IUSHNDc3u6amJv8CTt5Hl8/n272njmWsIw1p2aY3ItETQpSkpaXFnT9/3tXV1blTp075/449duyYO3LkiDt8+LA3vrOMdaQhLduwbW9DoieEiAXROnfunNeEo0ePenE7dOhQWUZatmFb8iCv3oJETwjRBpqnRGuIVpyQEc2dPHnSpwmNZayLE0iWkYa8e5qqit7ixYvdfffd59v65UC6J554wm3btq24pOfheLAPdlxeeOEFd8kll7Sz66+/XjcM0aehH47XqYdih3ghZGfPnvV/qoNglGqyso40pGUbtg0FkLwpg7J6ih4VvVmzZrkhQ4a0HoCo6HEAR4wY4caMGeN/h8yYMcNdeumlbtiwYcUlFzl+/Lh76aWX3BVXXOHF6Jvf/KbbsWNHcW08lPfggw/6ExIlKnqlIJ+rr766nSBi5IEwhsuivsP8+fPd008/7S8aIboL6h51x8SJPjr0gIGJrgxIsC15kBd5Wv6UVW4wlDY9KnqI3RtvvOFeeeUVX8lD0UPwxo4d65588knfKRqyd+9ed/vtt7sbbrihjXBs2bLFXXfddW7o0KF+G/LYvXu369+/vz/wcSB0d911Vzth5DhERYoorxzwn/14++23Y4UNWB63jhPy8ssvu/HjxxeXCFE9EKUzZ860ChJRGc3Uatx0yZO8LfKjTMru7lHeVEWPnXr++edbI7VQ9IjYRo8e7ZeHIHwDBgxwy5YtayN6W7dudf369WsnmPx+7LHHfKRH3iYc+H7bbbe54cOHtwu/OajRZcCy1157LVGYAD9uvfVWf6I6At/wKRRKM45FSJLowZ49e9w999zj90mIakHl5xozESIAIFiopgiRN2VYE5qy8QFfuotURW/Tpk2+mWiRWSh6CNk3vvENH6UlEYpeHIgUokbkRhmh6FHWLbfcUpFQ0N9w9913+4OfxPTp092VV17p7rjjDvfRRx/FCprZu+++6/0nSgsjPSLESkSP4/DQQw+5VatWFZcIkS6ITxh1URe6c5CBsijThA9fuiviS030ECQiMyIwIxQ9i6pefPFFX2jSgECSkZ7mKyKFnxZVmXDw+dRTT1V0x0BUHnnkkcSmL5ErUSiC94Mf/MANHDiwNWKME2hb9uqrr/p+uffff98NHjzY+z5z5sx2UWCS6AHHctSoUcVfQqQH1zB1CLHBqPM9MbBAmZRtfuCT1a9qkpro0ST77ne/69voRih6cPDgQXfTTTe59evX+98hRG7PPvus76e7//77fdoQ8n3ggQdat40TPZrWlRw0/CvVT0fkSv8g5SC4NNFNVE3gVq9e7Z577jm//ywjQrv22mt93mvXrnWXX365FzhELxRJ/C0leh2tF6KzUJcQGaIs6nslgYKBYDH3zj47G6VRNj5YxBfqR7VIRfTYYTrfFyxYUFxykajoIUhES48//nibjlK+Ex1NmTLFC8O8efN8REjIa5BXGCWFZpEUgxsMk5dLKdHjZP7sZz/z0SD7YMeFEed33nmnVfQQsUGDBnmzZQhkKL7mXyh6HSHRE9WAa9QGLWhedibCo15+/PHHbuXKla22Zs2aNnW6EvDBmrr4ZnpRLVIRPWZc0wyMHsCo6AER3KOPPup3EDiANAUZqSXaM2FAOB5++GF/EOIgzzDS4y5BlDhnzhz/OwRRjosAGTxBgOP6MjiBEyZM8I/WmOhxfGhe458JHN9t4IF9Im2cMEdFjzJff/311uMQRc1bkTZUdpuWwnVdSR8edciMfnkG+AgwMKIzRI/6YXWtkhYXEC3iE77hY2eiz3JJRfSSiBM9A4FECG688Ua3ZMkSf5BCIQGmkdx8881+8CJ6F4mKHjA6/KUvfclNmzbNn1BOAHkkTVnhANNfh2AmwfGgHO5ENHXpl4z6ykFEuC1SNf+NuEiP7dlm3759/ncI6zSQIdKGScFc6xgvCCgXru9du3b565HuHIIFbMOGDb67CVu0aJFfv2LFCi+ACFil4JP5h6/VomqihzAgQnGDC4gRUcwzzzzjVd2Iih4Q/RH1EBWxnREnepS5bt06d+edd7rLLrvMG5FcUrSIXzTLw8GXKCZ6+MS+WF6cFKbOWKQ2d+5c7yNpkyI9fNm4caNPf+DAAfed73wn9uQSOd57771VPfEiWxAEWLOW1lUlkZjd5Ll2aYHRsiPCi35iNHv3799fURRpUA6+4SO+diaPckhd9Ah7r7rqKl/R+Vy4cGFxTcfEiV61IVRHYOKexgATPTsuO3fudNdcc43fP0Z0wwg0yX8iPaJebgIIMdvyOXLkyHYXnwmxJieLNOG5VyIoxKSzfW9c+9QX6gItH/Jh8j/XLEJHgELQ0RUNIU98xFd8rgapi15fhEe/GDhBtHoafCGC7A2+iNqAriRu6ggJdbyz0FVEdwyGYBDhMYhB/jR1ESmaughiV8BHfMXn6DhBGkj0hKhxECeL8pLmpJaDiZ4JBvnSj4cw0fRNS/Tw0aI9ykgbiZ4QNQzdJ9Rp+skQo7BfvFK6S/TwkTzwuRp6JNETokZBPJgKYk1bBhq6Qti8xcLmbZqiB/hqTdyuCHUcEj0hahTEiMEFa9p2dgDDQPQYyGDGBWLEFJPt27d7UWI5QpWW6IUDGmmP4kr0hKhREAuiL4SDeXNU9q5golcKHr1MQ/TwFZ/xPe1BPYmeEDUKAwLWN8ZnJXPz4mDKCpOTyY8nq+KMBw3S0BB8Nd+JVtNEoidEjUKEZI92Ube7Cn14zEFlLm7UWI4xby+tPwHCZ3xPewRXoidEjUKfG/1iCAfN3L4GPuN72m9ekegJUaPYs6wIR198pBGfJXpCiLKR6MUj0ROiRunp5u0nn+x3S5YsL/66CL9ZXg5q3gohKqKSgYyxYye4fv1ej7X+/d9y+/Z94tNt3LjJG5w7V+e2bNnqv586ddpNnTqjzUTipqYLPt+dO3f532vXbnCzZ8/z38sBn/G9TwxkcLCnTp3qZ20nwauWeP26GeknTZrUZpkZ/3trJ23p0qWxaULbvHmzTwukt9/kQRl8sizc5oMPPijprxB9jbSmrCxduryN6K1atcYNGTKyjSiSZt68z9+oRLpQOKNmwplEn5uyUo7oQShCbIMQRr+HaQARw5IIRS4qrGaIKI/PWD7l+psEx4x/TSNvXhfF6+7JE7jz8WJFRJX1EydObHOMCeGZ0Dl58mS3fPnnTYGoKJvxj2ylwn1my9vNg3cWsp92sXPxkC++xr1hOo4k/zgfHMeof+x/d74aTCRTyeRkRCgUrRATPROyAQMGFQTpU7dp05bCss2F/I8UrrM1rYJGPmF+iO+MGbNbX3bAuo5ED197/eRkBCRaAaLGK+HDvoVQ0Ngxq6xRi0Z65YoehL/D8lhm+XRF9DiRCAgTNxE4ThLCxJtkgWcSx40b55fzaA3/sUFZfMcP1vGbY1NqvzhRvOzU8o3DjiETRHkEiTlTH374oRch1vFmZ8SLd/VxQ+iISvwD3qXGK/bTvjOLzlHJY2gmaHEWbd6uW7ehcI1PdK+99kv31lu/coMGDXaDBw9327fv9MtPnz5TMj+sI9Hrc4+hUcEsUjMQFCoP6wzWh6KXdqQH/I4TUNKEyzvbvCWKij4QjejgPycLoSHSMygDASFsDyF9qf3iTcuIKZ9JIG6IlN1Y8A2R5a3OIZRDeZXQkX9cpNF9FT0L12W5LxxAhDqK9IB0K1eu9n1zJmAjRowu3EynFerU1sI1MN0HAmF+nYn0+sQLB8iICsYDyFQ6IgoTKqCys4ymFREIhIJWTdHrSqTHfhHJYXwvB0SGY0E5CBX/L2BwbBC90EfoSFSI8Pjvj1I+sH00DU1S9pl9NEiXtuhxTtkvmiSi98CNjzpt/XpJAlJK9AzSIHJvv/2uGz36I/8bMZw0ibrziZs/f5EXtzBtkpUSPXy0/rw0grAo1I9URM9EDYXmwqcpFlY01iMsREGIAhUojLR4rTyVM1xm1tWBjHBdGOlZJU5T9LgzUfmJujhpfA/zpSz2sxLRo4lCs5HmYyk4rlExo5zuED1EmXNezjES3Qujn9bEtWgrSkeit3DhErd163afztKagDFCe/bsOffee0PdmjXtr9FopNcRpLOmbdojt5CK6KHMRDZ0mgORzezZs1s70MFEj7c0UAnpjKc8vvNJpaRiRb+HaYCKV6rysS4qevY7zIvOecunlOhVAuKE8PNPUew7+SGyXRU9nm0Mm61JkAcW0h2ih1/4h5+i90HfnjVxrR5FQcimTYu/JhobzxfO76TC9kcSRQ+hIvqzNLaulJEuDny0pi2+p00qooeA0Wy1PgPu+iaAhokeaalA/A5FKCQUvShUvKTKB6wrR/RYHkaAXZ2yguBxDBB7O1GUE23esv8IBP8qFZIkKpyguAEM0kd9Z/to85bzgBCHd1nSsX1I9HhUIsoawOj9cGOyaC9uQINr9Z13BseKEzZhwpTCdX3BD2KY6PFJs3bixKm+aUuaceMmFq61tvlXEumFAxgd3eQ7SyqiF2JTJlDpECp5NOIIRYhKa9M64swqIRUvqfIB60hrEVVcXkRfiIMJM2m7EunFCR6YD9GBDIQw2veVJCoMXOCv9YOWYtOmTT5vu1hsICP6j3SUExW9jkjyzwYwSo0qi56HQTXEhC6XSv8C0kDkGLFllBbRY9Cif/83vejNnDmnVRQ3bGgbwZUrevjU5/4CMtq8C0GIworGDtEcokJTUfkXMCPNSA+fyJu8ECXW0U+AnyYkpUSPA1SqTy9J8AyElf3jJkA5iBDz+KLHJ0lUEBNEJe7uHMWamfSb4isRJmXznrMQyklL9DiGnMNSo8qid8CzrERQGI+o9TbsWWGsms8KpyZ6RHg0cRCYaOWnwlJpLBqgUH6THoGkUkYjJNYniV5c9BaaiR7bI27MlQP2jXwZ0STSMyHhYHdW9CgrzgfKAfZrwYIFftJudOIy/iEYSdsiYohWRwMYIZxItiEfPpk/CJQZF/lGo++QjvxDuBk80QBG34BzRD0lkqKlUa1IqjMwtQafzLdqXk/k3WXRo2IjIrxV1YbEyYeJsVZRELikvJMqZGhWORG9uIjDYB1ChB+IjQmeQYhNReXkI3Y8IUH+RFNJlV+IWoFr3Jq5TAuJa510N/hgU1Twrdr1MBXRE0L0HRhMowmJyFDfezJKp2x8wBd8wrdqI9ETImPQLUFdt/4z6nxPRHyUSdnmBz5F+7qrgURPiAxC9w8jpYiNNXW7s4+PsqxJiw/4Yl1j1UaiJ0RGofJbxIf4MMOA2QjVFB/ypgzKMsHDB3zpLiR6QmQYRIh+NBvcsKirnClSlUKeYXRJmZTdXRGeIdETQvgRU5syYoKEHjDboSuixLbkQV4mrBhl9dRsCYmeEMLDwAKTgq3piRGV0ffGI6ZEaghGqcEG1pGGtGzDthbZYeRNGT05VUaiJ4RoA4MMTIwPxc8EkAgNIaOZSprQWMY60oRCh5EXaXrDhGiJnhAiFp6S4JFNNIGmaVTIShlp2YZtyYO8egsSPSFEhyAURGn0wzH6ipAxCBEay1hHGtKyTW9EoieEyBQSPSFEppDoCSEyhURPCJEpJHpCiEwh0RNCZAqJnhAiU0j0hBCZQqInhMgUEj0hRKaQ6AkhMoVETwiRKSR6QohMIdETQmQKiZ4QIlPEih6vc5bJZLJatFwu1170WCiTyWS1aPxRUTvR4089ZDKZrBaNtzpL9GQyWWZMoieTyTJlEj2ZTJYpk+jJZLJMmURPJpNlymJFj38pl8lkslq0s2fPthc9IYSoVfQYmhAiU0j0hBCZQqInhMgUEj0hRKaQ6AkhMoVETwiRKSR6QohMIdETQmQKiZ4QIlNI9IQQmUKiJ4TIFBI9IUSmkOgJITKFRE8IUZrmJtdy/qxrzh92zWd3uebTm92Fk2tc86er3IUTH3vz31lWWOfTFNKyDdv2NiR6QoiStDR+VhC25a5x+wBX//GDLj/nBlc3+f92deP+0J0b8wfe+M4y1pGGtGzDtr0NiZ4Qoj3NjYXIba07v/nnLj/3Jpeb+Efu3Id/4PJjfs/Vjy1tpCEt27AteZAXefYGJHpCiFZaLhTE7uhCV7/8wYJoXe1yo3/XNYz93YKQ/W4hovu3rm7iNS43889c/aLbXf2yB1zDiu964zvLWEca0rIN25IHeZEnebtCGT1JVUVv8eLF7r777nP5fL64pDSke+KJJ9y2bduKS3oejgf7YMflhRdecJdcckk7u/7663XDEH2a5lNbCgL2eKGp+h9d/sPfdfUFO/fhv3G5GV9zDWtfcE0Hp7uWs7svNlkvFOp0S3NxywJ8LyxjHWlIyzZsSx7kRZ7kTRmU1VP0qOjNmjXLDRkyxDU1XezsjIpeS0uLGzFihBszZoz/HTJjxgx36aWXumHDhhWXXOT48ePupZdecldccYUXo29+85tux44dxbXxUN6DDz7ojh49WlzyOVHRKwX5XH311e0EESMPhDFcFvUd5s+f755++mn/ByZCdActF+pd0+4RLj/lv7ncBwVxKkRmdWP+sBC53emaPhnvWuqPF1NWDtuSB3mRJ3n7MgplUSZldzc9KnqI3RtvvOFeeeUVX8lD0UPwxo4d65588klXV1dX3OIie/fudbfffru74YYb2gjHli1b3HXXXeeGDh3qtyGP3bt3u/79+7v6+viDi9Dddddd7YSR4xAVKaK8csB/9uPtt9+OFTZgedw6TsjLL7/sxo8fX1wiRBVp+NQ1rHzG5T789y4/qiB2oy539XO/VYjUZhYqaHkttLIo5EWe5E0ZlEWZlI0P3UmqoodwPf/8862RWih6RGyjR4/2y0MQvgEDBrhly5a1Eb2tW7e6fv36tRNMfj/22GM+0iNvEw58v+2229zw4cO92IU0Nze3WwYse+211xKFCfDj1ltvdYcPHy4uSQbf8CkUSjOORUiS6MGePXvcPffc4/dJiGrRfG6/q1/4d65uREGARv6rQtPzP7vz2wYWorPqiRB5UwZl+TILZeMDvnQXqYrepk2bfDPRIrNQ9BCyb3zjGz5KSyIUvTgQKUSNyI0yQtGjrFtuuaUioeDv4O6++2536NCh4pL2TJ8+3V155ZXujjvucB999FGsoJm9++673n+itDDSI0KsRPQ4Dg899JBbtWpVcYkQ6dJy7kAh6vr/XN3w33G54f/K5af9mWs62vYarSaURZmUjQ/40lJ3oLi2uqQmeggSkRkRmBGKnkVVL774oi80aUAgyUhP8xWRwk+Lqkw4+Hzqqad83uWCqDzyyCOJTV8iV6JQBO8HP/iBGziwcBcsRoxxAm3LXn31Vd8v9/7777vBgwd732fOnNkuCkwSPeBYjho1qvhLiPSgn61+/t+53LCC4Az9HZefebNrPrW1uLb7oEzKxgd8waeu9B+WS2qiR5Psu9/9rjtz5kxxSfs+vYMHD7qbbrrJrV+/3v8OIXJ79tlnfT/d/fff79OGkO8DDzzQum2c6NG0NlEqB/wr1U9H5Er/IOUguDTRTVRN4FavXu2ee+45v/8sI0K79tprfd5r1651l19+uRc4RC8USfwtJXodrReiU1yodw0fP+NyQwtN2iEFwZtxs2s5s7u4svuhbHzAF3xqWP60a0mzLzGGVESPPjM63xcsWFBccpGo6CFIREuPP/54m9FJvhMdTZkyxQvDvHnzfER48uTJYoqLeYVRUmgWSTG4wb+Xl0sp0aOv8Wc/+5mPBtkHOy6MOL/zzjutooeIDRo0yJstQyBD8TX/QtHrCImeqAbntw8vRFX/1uUGFwRv0tdc82flRXhcz3QDbdiwwW3cuNF/mnG9J7WWygEf8AWf8A0fq0kqonfu3DnfDLSpJ0ZU9IAI7tFHH23tR0PYaAoyUku0Z8LAgXz44YfdkSNHfLoo5BlGegw0ECXOmTPH/w5JGshg8AQBbmxsP1kSIZ4wYYI7duxYq+hxfGhe418oejbwwD6RNk6Yo6JHma+//npif6KatyJtmj/b4nJj/ovLv/8vXW7UH7sLR5YU13QM9YFWDXWAVpfZ6dOn3fLly30LLAxkKuXC4cWuruCT963gI75Wi9Sat3HEiZ6BQCIEN954o1uyZIkXpVBIgGkkN998sx+8iB7QqOgBo8Nf+tKX3LRp07yoIHbkkTRlBcGhv67UyCzHg3IY9KCpS79k1FcOIsJtkar5b8RFemzPNvv27fO/Q1ingQyRJi0XGlzDokdd7t2CqLz/++78xgGEb8W1HcM1uW7dunbBA7+Z4UAwQ12LCyDKopAPPuEbPtYv/K73uRpUTfQ4GIhQ3OACYkQU88wzz/jJxEYoJAbRH1EPURHbGaSNih5lcmLuvPNOd9lll3kjkkuKFvGLZnk4+BLFRA+f2BfLizscU2csUps7d673kbRJkR6+0DSAAwcOuO985zs+nyhEjvfee2/sOiE6w4VDi1zd4Ctc/p2CoEy52bXUf951VA4metQZAhY+zagbzMog2uP6DutpJeATvuEjvjYdXFhcky74nKroofpXXXWVr+h8LlxYvuNxoldtOFkITNzTGGCiZ8dl586d7pprrvH7x4huGIEm+U+kR9TLTQAhZls+R44c2e7OyQnR5GSRKs2Nrn7OAy7/q992de/9O3fhk5nFFeXDtY2onTp1yjdnly5d6m3Xrl1+HTdxWi2s60r/Hr7hI77iczVeUpC66PVFePSLgRNOXk+DL0SQvcEXURs0H19biJz+o6sf+EWXn/a3ruV8rrimfEz0TOBMNMLBRiB4OH/+vBeWzoBv+Iiv+Nx8bG1xTXpI9ISocRpX/Mzl3ipEeQN/353f8VFxaWWY6NHl8vHHH7dGejzmGQUx2bx5c/FX5eAjvuIzvqeNRE+IWuVCg2up/8zlxt7oGt78osuN+p+uJXesuLIywkhv//79XjCY2RCdscE6pnUldReVAz7mP/iq9zlf8N11IjIthURPiBqlue6Iu3Bomav71RUu/8ZvuYZF/1BcUzkmekxTYdL9mjVrvMDRf22De4hIVwXPaFz8vPcZ31tO7ykuTQeJnhA1SvPxDe786jfduV8Umra//H3XtGtqcU3lIHqM3jKbgqkpiB2ix0wDhA5B5DNppkSl4Ou5N37P+37hk7YPPXQViZ4QNcqFfXNdw9R7Xe61f+Fyv/oj1/zZzuKayjHR40EEEz0Ej+Yt4jF79uxUIjwDX+sGXuV9P78p3Sc00hG9rVudmzevcjt1qpiBECJtmraNc/nh/8vV/2NB9Ib9qWvJVzY3L4RpKDRpEQybZsUnxrw8RJF1zFvt9ATlAHzNF3zG9/Mr+heXpkPXRQ/B+8IX0rMvf9m5//E/nPv+9537h39wbtq0iwJZ4pVUQoj2nN8w3J176ypX//N/4fJjbnMt5zs/DQqhYA4uzdjwuVssXEYa0nYVfMVnfG9Y+OPi0nTouugxEfHb374oVJ2xK66IF78k+43fiM+nErv++ouCambCumxZcad6KfgXRsq93V/Ro5xf+56r+8c/cPU/++eufuI9BSXp3JMSBhEdEV8p6+zTGO0o+Fo/6R7ve8Ocp4sL06Hropc2dIRSoREiEyUTq3/yT+KFsBpmZVrEafbee22FpxwLtzdDeK0MMwQ9zpdSRl5CxHB+1a/cuZ/+lsv/tCB6kx8sLu074DO+N8x8orgkHXqf6JVDZ/sQQxs58nMBeuSRz4Xnt387Xlx60kJhDA3hVLQnEji/siB6L/2Wq3/pskLU9J3i0r4DPuN7w3SJXvfAIIsJ5LhxnwtkV+2ll9qKr5kQKdO06l2X++nvu4YXC8Ix7u4uN2+7lYKv+IzvjTOeKi5MB4meEDXK+bXDXN0/XukaflyI9Ebc2qWBjO4GX/EZ3xvn/Ki4NB2qInoMX0+dOjX2XXEGr1ri9etmpJ80aVKbZWb87y2+Ac/7xaUJLXzuj/T2mzwog0+Whdt88MEHJf0Voq/RtGmcq//VV13DC7/p8gO/4lpyyVNWxo6d4Pr1ez3W+vd/q1A3Pimm/Jzjx08UGkGTXC7XsZgyyDFjxmy3c+duN2HC5A63wVd8xvfzi39RXJoOPSZ6EIoQ2yCE0e9hGrAHnZMIRS4qrGaI6MqVK1vzKdffJDhm/GsaefO6KF53T57AaNaKFSu8qLJ+4sSJbY4xr+rhsZ7Jkyf71/IYUVE24x/ZeBQoCd5PaDcP3lnIftq8KmbTky++xr1hOo4k/zgfHMeof+x/d74aTCRzYdcc1zDmbpf/h3/mcj//j675ROcmJy9dutyL3qlTp92AAYNihdGM9aSLgughrJ99dqpQH1b5PEvRUvA19+p/8L43rU73bxNSEz0EJFoBosYr4alERihoiIRV1qhFI71yRQ/C32F5LLN8uiJ6nEwEhPfsIXC8hRlhWrRokV/PSxXHjRvnl/PuPR7VoSy+4wfr+M2xKbVfnChedmr5xmHHkDdRM1OeN2B8+OGHXoRYx5udES/e1ccNoSMq8Q+Ysc8r9hFX0fO0HN7gmha/4eqeu8zlfvgvXdOWycU17dm4cVPhZh3/7stQ9BAurvk4TNhIR35xohgaaZLAV3zG9wu75heXpkPVIj2L1AwEhcrDOoP1oeilHekBv+MElDTh8s42b21Gegiig//MTEdoiPQMykBAov+NQfpS+8U7zBBTPpNA3BApu7HgGyLLW51DKIfyKqEj/xDx6L6KnqXlzGHXvHeJy/3k37r6Z/6Za5z2THFNe0qJVNi8LRXthVFeVER5x97EiVNa13cEvuIzvrecTPff2lITPTKigm3fvt1XOiIKEyqgsrOMppW9gysUtGqKXlciPfaLSA7jezkgMhwLykGoeLuswbFB9EIfoSNRIcLjvz9K+cD20TQ0Sdln9tEgXdqixzllv3jdkOglNDVc7BsbcL1rfPo3XP71/+5azsafn3IivUqIiii/p06dUWjxHHFbt253s2cnz1jAR3z1Phd8d4299NVSJmr8BSMXPk2xsKKxHmEhCkIUqEBhpMVr5amc4TKzrg5khOvCSM8qcZqix0PXVH6iLqI5vof5Uhb7WYno0Vyk2UjzsRQc16iYUU53iB6izDkv5xiJ7uX8rJdc/ge/4XLPfNFdWDemuLQtpUTPKBXlmVm0t27dBrdy5Rq/Hfla/suWfeyGDh1Z0IjkP/VuWvuh9xWf8T1tUhE9mndENnSaA5ENb12wDnQw0eM/KaiEdMZTHt/5pFJSsaLfwzRAxStV+VgXFT37HeZF57zlU0r0KgFxQvj5a0n2nfwQ2a6KHs8zhs3WJMgDC+kO0cMv/MNP0ftoPrDa5X7471zDk//U1b/3l64lJnLqSPQWLlziIzRjyZJlbtOmi/93a/14ITNnzm1NP378ZP8d69//zULd2+CXx4Fv+Iiv+IzvaZOK6CFgNFvtj7a565sAGiZ6pKUC8TsqaEYoelGoeEmVD1hXjuixPIwAuzplBcHjGCD29jZZyok2b9l/BIL/9Q1JEhVOUNwABumjvrN9tHnLeUCIw85n0rF9SPR4VCLKGsDo5TQ1uobhd7n67xWE5Kl/5S5snlZc8TmI3rRp8TfCxsbzhWt2km+aEuAgdqNHf+SnnXBdjRkzvrWuIpyI24gRo31UR/T3zjuD3e7de9ywYaPcW28Ncnv27HOrV68tXJvtBQ3f8BFf8Rnf0yYV0QuxKRPRd2tRyaMRRyhCVFqb1hFnVgmpeEmVD1hHWouo4vIi+kIcTJhJ25VIL07wwHyIDmQghNG+ryRRYeACf+P+iyDKpk2bfN7RgYzoP9JRTlT0OiLJPxvAKDWqLHqepu3zCk3G33f1jxWivbducC11bes5dRBxijZXzSZMmFK4Fg+6d98d4sXR6jECMnHi1NZ0rF+3bn3hevj8Wjl9+owbMmRkQVg3F4Rmv/vVr95zv/zlQHfoUNv/m8YnfMNHfL1Q8LkapCp60eZdCEIUVjRGNmkOUaGpqPwLmMEBJS3+RKHixVU+g3VhlIJP5E1eiBLreBEifpqQlBI9DlCpPr0kwTMQVvaPmwDlIELM44senyRRQUwQlfCvJpOwZib9pvhKhEnZ/BFzCOWkJXocQ85hqVFl0fO0NDW4hpHfcfnvXuryj/9zd37eG9wVi2t7AQVf8Anf8BFf8bkapCZ6RHg0cRCYaOWnwlJpLBqgUH6THoGkUkYjJNYniV5c9BaaiR7bI272B9vsG/kyokmkZ0KSy+U6LXqUFecD5QD7tWDBAj9pNzpxGf8QjKRtETFEq6MBjBBOJNuQD5/MHwTKjIt8o9F3SEf+IdwMnmgAo2/QfKjQAvrx1a7+kYLwPfeH7sKO0gMX3Qm+5Ao+ed9+/Mfe12qRiuhRsRGR1atXt85ZIx8mxlpFQeCS8k6qkKFZ5UT04iIOg3UIEX4gNiZ4Bn0QVFREGrHjCQnyJ5pKqvxC1ApNSwcXoqnfdvm/L4jLK/+tIC7JE4S7C3yo/9m1F30q+IaP1SQV0RNC9A1aGvOuYfTjBYH5DZd/8P909a/9uWs51vn/zugqlI0P+JJ76J+6xg8f9z5WE4meEBmDyb8NA//K5b9TEJqC5V/7s6o2J5Pwze1C2d6HgtW//ZeJk6fTRKInRAZp+fQTV//GTS53/6+7/AO/7upfvtZd2JbuXy2WgrIok7LxAV/wqTuQ6AmRUVo+3eca3v6rguhc6urvL0R93/+/3PlZrxeireSnJboKeVMGZfkyC2XjQ/OJ7vvjL4meEFnm7AnXOPJxl3/ot1z9fURdv+Hq+/25a1o3JdVnXnnSgjzJ25dRKIsyKRsfuhOJnhBZ53y9a1r0nss/c5XL3/Nrrv7egvg99Nuu/pffck0ff+haznT+T7zZljwa3rz1Yp6FvCmDspoWv+fL7m4kekIIT/OBja7h/ftd/pHfc/X3/LprKFjdfb/p8i/8F9c4+il3Ye1k13x0h2s5V9AIRljD/9zge2EZ60hDWrZhW/IgL/Ikb8qgrJ5CoieE+JymRte8Za5rGHiHyz/6r13+rl9zjXcXBKtgdfdd5nKP/3tX/6P/5up/8c1Cmm+7hnfvvWiF7yxjHWlIyzZsSx7kRZ7kXY3naStBoieEaA/it2eVaxz/Y1f/0ldd7uHfd7m7L3X1BQFr6MBIQ1q2YVvyIK+eFjtDoieEKE3+jGv+ZJ1rWjbKNX70Q9fwzr2FqO5/u/xPv+bqf3KdN/+9sIx1pCEt27Btb0OiJ4TIFBI9IUSmkOgJITKFRE8IkSkkekKITCHRE0JkComeECJTSPSEEJlCoieEyBQSPSFEppDoCSEyhURPCJEpJHpCiEwh0RNCZAqJnhAiU8SKHv/8L5PJZLVo9fX17UXv7NmzMplMVpOG8LUTvYaGBplMJqtJa2xslOjJZLLsmERPJpNlyiR6MpksUybRk8lkmTKJnkwmy5TFit6xY8dkMpmsJu3MmTPtRU8IIWoVPYYmhMgUEj0hRKaQ6AkhMoVETwiRKSR6QohMIdETQmQKiZ4QIlNI9IQQmUKiJ4TIFBI9IUSmkOgJITKFRE8IkSkkekKITCHRE0JkComeEKJLtLS0uObmZi8mTU1N3s6fP9/GbDlpSMs2PYVETwjRaRAvRK2urs6dOnXKnThxwr+o88iRI+7w4cPe+M4y1pGGtGzTU8In0RNCVAyide7cOa8XR48e9eJ26NChsoy0bMO25EFe3YlELyX27NnjHnroIX83E6JW4f8liNYQrTgh4/o/efKkTxMay1gXJ5AsIw15dwdVFz3eR//Xf/3Xbu7cucUl1Sefz7vXXnvNXX755e6yyy5zzz//vA+pgf6EWbNmuWuvvdZdcskl7pvf/KZbu3atXwecnKefftpvx/Y//OEPW7ctxdixY93AgQN7tK9CiGpBf9zp06fbiB3ihZCdPXvW/+EOYlLq+mcdaUjLNmwbCiB5UwZlVZOaEz0OLIL3wAMPOPYHwUL0WMa6FStWuAEDBni/OLiDBw92X/va1/zB507z5JNPup/85CdeONn+7rvvdoMGDSrm3pYXXnjBC2dHNmzYsOIWQvQ9qAvHjx9vFSf66Kgb9fX1PojoLGxLHuRFnpY/ZVFmtai55i37QPS2atWq4hLntm3b5v7mb/7Gr4uOHHGAb731Vp+G9TfccINbvHhxca1zb7zxhhe3OFgepo2D9RI90RehrhAcmCARGNASIlJLG/Ikb4v8KJOyuyKqSaQieozMfOUrX/HCYaxfv97ddNNNbtOmTe7666/3lZ/vSensgBJl0ay89NJL3be+9a02TU/D8qQfzeA7+axevdr9xV/8RRvR4yDefPPNbco19u3b577xjW+4nTt3+oPxyiuvuGeffdbfaQ4ePOhuu+22RGGT6IlahbqAHpgI0fSk1VQNETLImzKsCU3Z+IAvaZKK6NFMfPjhh9tU7n79+rmf//znvt1uooeaJ6XL5XJ+IMD63zgAkydPdtddd53bsWNHMfVFLB/60QyaoM8995xvovJpzVvSvv322+7qq69uJ3pEfPTDPf744613L8QO4b3qqqt8v9/s2bPbRIYhEj1Ri1D3wqiLOtxdgwxAWZRpwocvaYptKqIHCNB9993X2hdGhPTxxx/7/Ez0SqUjMiMdO2rg3FNPPeX73aJMmDDB3XHHHV4gsXvuucfnAxwkG4xAvBA9a8KGzJ8/35fPnQUQt48++sj96Z/+qRs+fLgXT4QvLkIE9emJWoM6QL1EbDDqb7UHFuKgTMo2P/ApKfiolNRED8dMWBAfRAgxiopeUjrWmxiGICxYFPKh746mbphPHDRh6dOj/85YunSp+/rXv+62bNlSXHKxiUyfni3jIA8dOrRVXKMo0hO1Bv1o1C2CD+puZ5qW1Bu2Q7jsszOCxbb4YBEfvqVBaqJHRkRGiATNVWt6RkUvKR2RHoITChNpifRGjRpVXPI5HES2ZyQ2zCcO1lEm+UGc4AE+4mt4DOKWGRI9UUsQcNigBc3LzkR4TDRm+3Xr1vn+emzjxo2+f9zqXyXggzV18S0aFHUG/EhF9ICIi+YiURXRFURFD+LSsTNxfXoIIQcsDqI8xOuWW27xdwKDYXAOFnksW7bMD1SYwCUJHnAQmL4ycuRIvz1+4E8omCESPVErcH3btBQGJivtw6OuYdSZ3bt3+3rNnDsmHfN9165dvt+eYKXSqA8hxSd8w8fOiGdIqqLH9jQ5Q5GIE724dEBf3DPPPNM6qZgm6969e4tr22MDGj/60Y/aHEj65dg+OgKMsNKEjva5hYMcpMU3ll9xxRXupZde8n7FgehF84oziZ7o7SBQBA4Y4lQu1DvSM9hI3VmzZo1bvny5n0VBUEKUx3cCHdaRhm6kpK6oJCjD/MPXrpCq6HU3+GsDIT2BIj1RCxDVWbOWG3ylkRitInQDkUPQECUz+uH4JOIjgNm8ebNPW2nTGZ/wzZq5XRlN7pOiRxiN4/QLfu9732udbiKEqBwEiQgKMelsXSISowl74MABryEIHXpCsxTho1lKNxVN30oiyRB8w0d8xefO0idFj4nE11xzjfu7v/u7NgMfQojKIOJiyhZCQv3vLHQdUS/pv0NMyNNEDuEjytu/f7+PBDsreoCP+Er+lUaLRp9u3gohugavdrIojwHAzoLoEelFRQ+RS1P08NGiPXzvDBI9ITIM9Z1+MqaF0G3UWbpL9PDRprDge6X9jyDREyKjhE1bXvXUFaLNW6IxEz26oFiehugBvloTtzMvIJXoCZFREB9r2nZ1MNAiPYSNSMy0BGFiIINoz0Swq6IXDmgw9aXSaE+iJ0RGsUfOECSEoCsgZER6iJxNVEaM7DtGOV0ZvTXwlbzwnVFciZ4Qoixs3huRWWf6xkIYYNi+fbufh8e0FSK+0Fi2detWL4xEhV0BX61frzO+S/SEyCgmHNT7roKQIKJEcjRzQ2MZRtOWsoj6ugr54DsRX6X5SfSEyCgIBsLRlYm+PQU+4zt9exI9IURZ0P+GcPD0RF8Dn/Gdfj2JnhCiLCR6Ej0hMoWatymKHqMzU6dO9RMSk5g5c6YbMWJEq5F+0qRJbZaZjRkzprWzlffhxaUJjREkg/T2mzwog0+Whdt88MEHJf0VotZIcyCju8FnfO81AxnliB6EIsQ2CGH0e5gGEDEsiVDkosJqhoiuXLmyNZ9y/S0XJmHyHx6UxVufeb+YPRzNbPIZM2b4F5ViCxYsaF3HyeNELlmyxG/PSTHwNbof2JQpUxJfs8NQPsfiww8/9Gl5z2CYJ3dL3m/Gy1rxsSNK+Qf8pgzK4m3VSf8tInoH5U5Z2bfvE9e//1uuX7/XY23s2Al+ysqQISNj14e2ceMmt2HDJjdt2kyXy+XdnDnzfd0+dep0oV7M9uUtWLDIrVu3wX+Po9dMWUmqlKFREcJQOhQ0hKfcSM/EKg7WlRvpWT5pih77N2vWLC98iARD9qNHj/avz+Zgsw6jTPpUEAkEGHibM/s6bdo0L1Sl/GEmOsJDvkmwPcccHygbsRo3bpz3kWPAd/abNKWOqVHKPy76RYsW+esHEecdh6TlTix6J2lMTg7Fiu8mgIjbvHkLCzfUaW7//gN+/eLFS93Wrdv9948/XuUF78SJTwvX4aRCM/WYz2fLlm2F62hpyegNX/G5V01ODiM1gwpCBWOdEYpQuE34PUwDVM5SFTQUOeB3nICSJlyeVvOWExCeMH4T2eEHdyZEjomaBsuj0Rr+IUil/GGipwlYEnPnzvVmFwV3dsqPRmAc61LHNEqcf9H9Zh3HmompondS7mNoiBhihqhFiYregAGDWqM6RG/hwsWtQjdt2ix3/PiJwjU530d71POk6JBtk+g1j6GREREMs7KpiDSZTKiASsCy6dOn+4mKwPruEL00Iz3SltscBMQMUSM9ZY4fP77NK3EserL9A76XEj2ONUK6cGHyhYGf7Ku9Kh+4ePE9evzSEL0Qysa3OXPmdPqdZ6L6lPvCgY6arggixEV6CN7y5SsL4pQr1IPpfh3N2kmTphZEZ3+smNq2SfSaFw6YqOEQoSeVkovfYD3CQhOL6INKFkZaVBIqabjMLBSF6HZxFhW9cF0Y6VlFr6bo8dgNzUeauzRj2cfocUFAbP+gI1Hh+BKx2c0jDpoupAmPBcQJXFqix28iZo4zQp9Gq0FUF86R9Y0lNSm7Eul99tkpN2HCZN9snTt3gU9nlBLTJNHDR+vPw/dKozxIRfRwhCjP+qboQ5o9e3Ybh6gQCAvv1aLiUykpzyIvhKA7Iz0iIMuH8soVvUrglTqIA3+OApSXhuitWLHCi0qpJgl5IPDdKXoG+2f9h3qzde+mnJeIlhK9ENaHkR7N2IaGRi+KiNuhQxf/sZBlRH00dSuN9MjbmrY9+hJRBIxmq4XIdGibABomeqSlkvGb8kJBM0LRi0LlLFVBWVeO6LE8jADTnrLCcWSggb+gNPHHj2jzlv41IrKwbw7/kkQlbgCD9Aic7YvtI59h8zZsaockCWHSsSnln0F/0cSJE9tdB6J3ETZxOa9xdCR6LGfA4siRo27YsFGFAGiuGzTofffaa790ixcvc6tWrXFDh470TVygHKK/s2fPVRzpsa01bTvbdZJa89bgzk5lw6kQ+q5YHkY5lGcVlApkTaM4M+GickYraIiJHOWQd1xeCAQjkFYhSZtmpBcneED+NHWjAxn4wokwOB5JosIABnl0NCpKuUTfcQMZROIhaUd6YKIXiq7onXDDtWgvrvWA6I0e/VGhTsdfc1u3biuI3tRC3frAi9vSpR/7EVias4zS0n+3evVaN3z4B+706TO+n48BjiQxZbpKnOiFAxilBvA6IlXRIwqhvyta2QEhonIZRB1UYASIijh//vzimnQjPXwib/Kiyc06Ii38tD6xSkSPtKX69JIEDzhplIMY8Z2Th3hER1OTRIWTRV9pKGSlIF+mlrCf3BVpclJ+9MJOQ/QYpeWYcHwoi+/liLPoeaiLiAn9ZNwY466thQuXxEZk2C9/OdDt3dt2ziZN1LfeGlS43mYU8r842LBx4+ZCi3CWW7BgceHGu7ud6CGW5PeLX7zphTEEn2xeIb6Gsx0qJTXRI8KjsiMw0bCTSkbFotkLFMpvEwc6+cNtOhK9uOgtNBM9tkegrE+NfSNfKiTRlVV+opK0RC/JPxMVfCACYhnz99avX996keF3dDvM9ocIkZtEqQGMEPIlmmWCNPnQBWHHlM+wSWzG8UmilH8mdFYW+4ioi74Bz7JyvrCuvuSzGtj0GqyrzwqnInpc8IgI/2RuI0DkY08CYAhcUt4ISVJT1MyaxohHqaiEdVRC/OBpBxM8g7sLkRIibU0w8qevi/yFyCIIAXWCSIrovCuRVNowLQWfzDd87QqpRXpCiL4NN31r5jItJNpi6wnwwaao4FsagYlETwjRij2ahsigBV2NqroCZeMDvuATvqWBRE8I0Qr9wOiA9Z+hBz0R8VEmZZsf+BQ3wNIZJHpCiDbQH85IKWJjTd3u7OOjLGvS4gO+2FhBGkj0hBDtQBgs4kN8mHfL9K80xScKeVMGZZng4QO+pIlETwgRCyJEP5oNbljUFZ3nmQbkGUaXlEnZ1RBZiZ4QoiSMmNqUERMktILpX10RJbYlD/IyYcUoq5rTxyR6QogOYWCBScHW9MSIyuh745l7IjXEpNRgA+tIQ1q2YVuL7DDypoxqD5xI9IQQZcMgA8+9huJnAkiEhpDRTCVNaCxjHWlCocPIizTdNVgi0RNCVAxPSfAMO3pB0zQqZKWMtGzDtuTRmReBdgWJnhCiS9AcpW8OASNiMx0hssP4zjLWkYa0PTH3z5DoCSEyhURPCJEpJHpCiEwh0RNCZAqJnhAiU0j0hBCZQqInhMgUEj0hRKaQ6AkhMoVETwiRKSR6QohMIdETQmQKiZ4QIlNI9IQQmSJW9Hi/lUwmk9WqtRM93nIqk8lktWi806+d6PEOe5lMJqtF47X0Ej2ZTJYZk+jJZLJMmURPJpNlyiR6MpksUybRk8lkmbJY0ZPJZLJatbNnz7YXPf6TUiaTyWrV2omeEELUKnr2VgiRKSR6QohMIdETQmQKiZ4QIlNI9IQQmUKiJ4TIFBI9IUSmkOgJITKFRE8IkSkkekKITCHRE0JkComeECJTSPSEEJlCoieEyBQSPSFEp2lpafF/nl1XV+dOnTrlTpw44Y4dO+aOHDniDh8+7I3vLGMdaUjLNmzbE0j0hBAVg2jxp9noxdGjR724HTp0qCwjLduwLXmQV3ci0RNClA3/L0G0hmjFCRnR3MmTJ32a0FjGujiBZBlpyLs7kOgJITqEV6yfPn26jdghXggZ/znBH+4gJqWarKwjDWnZhm1DASRvyqCsaiLRE0KUJJ/Pu+PHj7eKE310aEV9fb1rbm4upqoctiUP8iJPy5+yKLNaSPSEELEgSmfOnGkVJKIymqlEamlDnuRtkR9lUnZXRDUJiZ4Qoh0IA3pgIkTTk1HXaoiQQd6UYU1oysYHfEkTiZ4Qog2ITxh10ffWXYMMQFmUGUaXaYptrOjt2rVbJpNl1LZu3eY2bdrsbcuWrW7nzl2x6applEnZ5gc+xaXrjCGk7UTv2LHjMplMVpPG3MB2oldf3yCTyWQ1aY2N5yV6MpksOybRk8lkmTKJnkwmy5RJ9GQyWaudOXPWHTlyNHZdrVjmRI+Tun//gcJ+noxdL+smO3HQ1e9Z18byB3fEp5VV3Q4cOODmzp3rxo8f78aMGePmzJnjdu7cGZu2r1umRI85OkuWLHELFy4q2EJ/ouPSyVK24wddfvdalz9x2OVPFqKI05+6/OyBLveLb31u/W9z+Xnvufp83uWP7PVp6wsiKCGsvu3du8+L3ZQpU9zmzVu8zZo1uyB+Y922bdtjt+nLlhnR2717T+FEzvIn8cCBg279+g3+t4Sv+paf8Zare/GrLvfqX7jcW3e4+vWzXP69B13dPf+8YJddtHv/hcuN+L7Lb13icq//5cW0P/1zl5814GJUGJOvrOt27lydmzRpspsxY6Z/AiKfr/d29OgxXz8Qw88+OxW7bV+1TIjerl273MyZM73gcZJZdvr0GbdmzVp/siV8VbRczuV+eburu+PXLlpB4PKD7nO5kU8VxO02H+F5K3zPD/ueyw28x9Xd/ZvF9L/ucq99y9VvnBeft6zLxtMJQ4YM9a2g6DqCg+HDh/uAIbquL1vNix4nE8HjkRYTPLNTp0671avXuHnz5vkTHK6TpWSnT7q6l772uehhf/8Hru4H/8nlvn91W3vyKlf34O+1Tfujr7j6lZPi85Z12dasWeP78M6ePdduXV1dzn344Ydu5cqV7db1Zatp0duzZ4+bNm2627x5czvBM0P4OKnz5s33j6jEpZF1wT477oXrcyH7P1zdtzsw0kj0usWWL//YffTRR7HrMJq39IPHreurVrOih+DRMbtx46bYu1hojOQuW7bcR3zHj5+ITSPrpEVEL/fy9S6/bExJy71yo0Svm2zPnr1u5MiRvg5E11FviALXrl3Xbl1ftpoUPYvwNmzY2KHgmZ048albvHiJH7aX8KVo0UjvsStc7he3lrS67/0HiV43GX3bH3zwgX+TSXQdbzYZNWqUO3jwULt1fdlqTvQOHTrs+/DoqyhX8MwQO6azLF68OHa9rBOm5m2vNkZqFyxY4CZMmOBv/Lac+awso9snqWuor1rNid6+fZ+4IUOGuNGjR7slS5bGpokzBBKxHDZseMk+DlmFFm3ePvtll18yOrZZ662wLvfS/5LodaPRlz116lR/w7dlH3+8wi+rxX7umhM9wvUdO3b6OUZjx46NTRNn3OXef/99P8pLP0dcGlknLCJ6+QF3uPrda9s9jdFqTGIeeJdEr5tt8uTJbtq0aa2/p0+f0eZ3LVnNDmQwBy8qeoTsSb+5oxEhhutlKVg00vvef3C5n3y1tD12hUSvGyyXy/unL2jhjBgxwg/62Trm5tGfxzoGMkgbbtuXLVOit3TpMv94Df0UDFiEEZ1Er0oW7dOL68OLmvr0qmr04zHIN3369EITdppbsGChW79+vZ++ZWmYo8ccV/r7eGKDqI9t2DbMqy9apkRvzJixbsaMGYW7GCeTE72hdZ1Er0oWjfTe+GuXH/vjZBvzgsv9w59I9KpkJ09+5l8mwCAF/Xb0gdO1kzToxzrSMFdv0qRJPljgKY64tH3FMiV6DM3bREtC9nD+kUSvShaN9H7wx/FN2lb7n67u4X8j0auCEb0heEzn4pHMMLLryBBLXkwwZcpUH/VVsm1vM4lecZ1Er0oWFb1KTaKXmjEBediwYf6fxhDAuDQdGcJHHnHP6vYVq1nR48QicrxMgPfn7d2713fMWpOWx28WLVrs12EIICczmo+si3bunI/gYgWtHPvRda5+27L4vGUVGfNQBw8e7IUrbn05xjzYoUOHFiLFbbHr+4LVrOgxdWX8+Ale+EaN+sA/asMjNTYBk9EpW4cxP2/p0vLn9cnKt/yYH158fVScqJWyu3/T5UZ+39Wf0hMyaRiTjJmKMm7cODdx4qROGc/i8rhmX367cs2KHkYEt3Xr1lajQ9ZGn7gAeDOsraOPQ29TrpId2unyH4+Pn4xcyj4e5+oP9N2IojcaYrVixQr/Et3OGE8r8UaizjaPe4PVtOjJZLL2dvr0aT8w0Vnry4KHtRG9U6dOFXZK0Y5MJqtdk+jJZLJMmURPVj07e8blF43wb0+OXR+x/JbFLr9pwefL6uoubn9cb7WWpWftRK8W+vToc1i5clXrCNORI0fc6tWrW2ed834wXjAaNzplxvpae49Yt1uuIFrzh7j84hEuv2+Ty7317fbvzyssy39SfJfb3g0u9+53XP2RPa4+X1/YbqTLT3vd1Z/5rH3eslSMgT0G8JiCwhQuXqa7bt16/5vZDLX4Nwo1FemZmPGIzbvvvuvf74+A8clvhtv5zYPVjNbayC2v1GEb+22jubX2L1A9Ykc/cfmxP3L1u1a7/IoJF0dlFwx1uX/83/6TZfWfHnH5JaNc7uc3ubqH/7XL/fTrFwXxqf/kcs/9l7bCKEvV1q5d6x8vo45QD5jfypQU/juGNw7xrDoT9+O27atWU6KHSIViNn8+D0tPaiNmGJM0GYVizhIiyHw9XiulKK9KVojg6k8FLYjPjrvcsCf8py3Lj33B5YY/6UUxN2vgRVEsTl3JvfOAb/q2bi9LzbjON23a5OsAU7poJa1YsdJP1mdaFxOZo28n6utWc316oZjxBMbgwUNixYy7F5M0o4KI8QJS7njRvGWVmY/eChFbfnK/tuuSRO+H116M8F79C1f35FWtTeC6F/67RK8KRncPbxyiBfSrX/3KvzyXesJrpjCrN6Sp9C3kvdlqTvRKiRkPS5uYkY43rvCdE8pblhFMfvNCRYleCkYf3YSfutzbd7VdrkivVxhRHW8c4tFM/t+WJi3/lcFLCayFxCeTmfv63LzQ2ogekxaZoByXsK8YYsYJtLtUaCyPEz3eGDFhwsTWJzIkeukZYpUbdF/b5Yr0eo1xw+fJJJ47v/j25Olu1arVXvgY0CDKq7W+7XaiR7QXl7CvGGJGqN6/f/929uabb8aKnr0llpEqRrMkeumZiV5+x0qXX3vxeMeJHlFha2QXifRssKM1rSwVI3rjJaG0gHjDEH15O3bs8H171AfqR82P3p45c8Y/ohKXsK8YYlZO85ZOWv7ijqksEydO9MPzjF7NmDHT/7/G0aPH2uUtq9y86D37ZZcb9UxB2NZfXHbikMu9/3Cr6FnfX6tFIj1vGsFN3XgFPG8fYvCPfuzDh4/4aV7Ugffee883dwmCmP5VS/+I1kb0zp49WxOi11HzlhPLu/8RN14xxd2Npi0vKOAC4LXyc+fOa+3jk3Xe8ks/dPl37nf5rUv9n/7k3vy2y/W7yeXeKTR5zxavtSDKi430MEV7VTO6dxjEYIoK0d2qVasKQrfS1xHem0ewULP/kUGkh8Ul7CtWTqSHsPOPaTRrmb4Svvef7+TBH4bX0ohVj9mhna6eCI1jzHy8FcW3rexYUVgWX5Hyh/f4QY24dbJ0jUnIjN4yZYWZDdQJ6gc2f/58HwHyJ/hx2/ZVaxfpYXEJ+4oRhif1QxDhacJxH7BCBJjnbyLj1slSNbpxCAgQu+gILeto+RAEhMv7urURvbq6Oi96RDsymUxWi9bY2NhW9M6dO9e6QCaTyWrZvpDP5wshbl3sSplMJqs186JnwkfEZ2Z9faHZoIdMJpP1JovTq1DP0DfTulbRw3K5nF/ZWQGMSyeTyWRpWUd6E+qWaRm6FurcFxoaGN1g+gYdfp+Ln5ltGFqYcWhxaWUymSwtK0dzQv0yTTONQ++86JmFwhe1MIMw09DC9DKZTJa2JWlOKf0xsTNrI3pmpopmtqF9l8lkst5icTpl1l7fGtz/D0i1ZVSKlOoWAAAAAElFTkSuQmCC`


    constructor() {

    }



}
