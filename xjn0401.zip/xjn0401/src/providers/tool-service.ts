import { Injectable } from '@angular/core';
import { AlertController, Events } from 'ionic-angular';
import { ConnectService } from './connect-service';
import { Md5 } from 'ts-md5/dist/md5';

/**
 * @title ToolService
 * @description 存放工具方法的服务
 * @export
 * @class ToolService
 * @author xjn
 * @date 2017年3月10日
 */
@Injectable()
export class ToolService {

    constructor(
        public alertCtrl: AlertController,
        public events: Events,
        public connectService: ConnectService
    ) {

    }

    /**
     * @description md5加密方法
     * @param {string} field 需要加密的字段值
     * @returns {string}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月26日
     */
    public encryptByMd5(field: string): string {
        return Md5.hashStr(field).toString().toUpperCase()
    }

    /**
     * @description 截取时间
     * @param {string} time 时间
     * @returns {string}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月27日
     */
    public timeSubString(time: string): string {
        return time.substr(0, 19);
    }

    /**
     * @description 弹出警告窗口
     * @param {string} msg 弹出内容
     * @returns {void}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月6日
     */
    public showAlert(msg: string): void {
        let alert = this.alertCtrl.create({
            title: '平安租赁',
            subTitle: msg,
            buttons: ['关闭']
        });
        alert.present();
    }

    /**
     * @description 弹出单选列表
     * @param {string} title 标题
     * @param {any[]} list 列表数据
     * @param {string} eventType 传值事件命名
     * @returns {void}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月23日
     */
    public showRadio(title: string, list: any[], eventType?: string): void {
        //创建alert对象
        let alert = this.alertCtrl.create();
        //标题设置
        alert.setTitle(title);
        //生成选项列表
        list.map(item => {
            alert.addInput({
                type: 'radio',
                label: item.value,
                value: item,
                checked: false
            });
        })
        //生成cancel按钮
        alert.addButton('取消');
        //生成OK按钮
        alert.addButton({
            text: '选择',
            handler: data => {
                this.events.publish(eventType, data)  //传值给相应页面，页面中用subscribe接受
                console.log(data)
            }
        });
        //弹出alert窗口
        alert.present();
    }

    /**
     * @description 清除定时器列表
     * @returns {viod}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月24日
     */
    public clearTimeArray(): void {
        this.connectService.commonData.timeIntervalArray.map((timer, index, timeIntervalArray) => {
            clearInterval(timer);  //清除定时器
            timeIntervalArray.pop(timer);  //删除数组中的该定时器
            // console.log(timeIntervalArray);
        })
    }

    /**
     * @description
     * 将获取到的订单数据进行时间归类
     * 按照时间添加到绑定模板展示的数组displayOrders中
     * 并将当前订单时间更新至存放时间的数组orderDateExist中
     * @param {any[]} listData 订单数组
     * @returns {void}
     * @memberOf ToolService
     * @author xjn
     * @date 2017年3月13日
     */
    public setOrdersByDate(listData: any[]): void {
        let shareData = this.connectService.commonData  //变量暂存
        let date: string = '';
        //遍历订单数组
        listData.forEach(order => {
            date = order.date.substring(0, 10);  //获取该条订单的时间
            //判断该条订单的时间是否在时间数组数组（orderDateExist）中
            if (shareData.orderDateExist.indexOf(date) >= 0) {  //如果订单时间已存在，找到订单数组（displayOrders）中的该日期数组，插入订单
                shareData.displayOrders.forEach(ordersByDate => {
                    if (ordersByDate.date == date) {
                        ordersByDate.orders.push(order)
                    }
                })
            } else {  //如果订单时间不存在，新建订单对象，插入订单数组（displayOrders）；并将时间存入时间数组（orderDateExist）
                let ordersByDate: any = {
                    date: date,
                    orders: [order]
                }
                shareData.displayOrders.push(ordersByDate);
                shareData.orderDateExist.push(date);
            }
        })
        //将转换完毕的数组传递出去
        this.events.publish('getOrdersByDateComplete', shareData.orderDateExist, shareData.displayOrders);
    }

    public setClerksByStore(listData: any[]): void {
        let shareData = this.connectService.commonData  //变量暂存
        let storeName: string = '';
        //遍历订单数组
        listData.forEach(clerk => {
            storeName = clerk.storeName;
            //判断该条订单的时间是否在时间数组数组（orderDateExist）中
            if (shareData.storeExist.indexOf(storeName) >= 0) {  //如果订单时间已存在，找到订单数组（displayOrders）中的该日期数组，插入订单
                shareData.displayClerks.forEach(clerksByStore => {
                    if (clerksByStore.storeName == storeName) {
                        clerksByStore.clerks.push(clerk)
                    }
                })
            } else {  //如果订单时间不存在，新建订单对象，插入订单数组（displayOrders）；并将时间存入时间数组（orderDateExist）
                let clerksByStore: any = {
                    storeName: storeName,
                    clerks: [clerk]
                }
                shareData.displayClerks.push(clerksByStore);
                shareData.storeExist.push(storeName);
            }
        })
        //将转换完毕的数组传递出去
        this.events.publish('getClerksByStoreComplete', shareData.storeExist, shareData.displayClerks);
    }
}
