import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { AlertController, LoadingController } from 'ionic-angular';
import { ToolService } from './tool-service';
import 'rxjs/add/operator/map';
import { ConnectService } from './connect-service';

/**
 * @description http服务封装，统一处理返回结果
 * @export
 * @class HttpService
 * @author xjn
 * @date 2017年3月6日
 */
@Injectable()
export class HttpService {

    private appVersion: string = '';//APP版本
    private apiVersion: string = '';//API版本

    constructor(
        private _http: Http,
        private alertCtrl: AlertController,
        private toolService: ToolService,
        private loadingCtrl: LoadingController,
        private connectService: ConnectService
    ) { }

    /**
     * @description: post请求，统一处理异常情况
     * @param {*} param 请求参数
     * @param {*} event 上拉加载实例 or 下拉刷新实例
     * @returns {*}
     * @memberOf HttpService
     * @author xjn
     * @date 2017年3月6日
     */
    public post(param: any, event?: any, skipPresentLoading?: boolean, skipDismissLoading?: boolean): any {
        //开启加载提示符
        if (!event && !skipPresentLoading) {
            //启动加载提示符
            let loading = this.loadingCtrl.create({
                spinner: 'ios',
                content: '加载中...'
            })
            this.connectService.saveData('loading', loading)
            this.connectService.getData('loading').present();
        }
        //设置请求头
        let headers: Headers = new Headers({ 'Content-Type': 'application/json' });
        let options: RequestOptions = new RequestOptions({ headers: headers });
        //设置请求参数
        let requestData: any = {
            appVersion: this.appVersion || '20161230',
            apiVersion: this.apiVersion || '1.0',
            sessionToken: this.connectService.getData('loginStatus').userSession || '650932d734cb824518faa3d8c850a5ff',
            accountId: param.accountId || this.connectService.getData('userId'),
            accountSysRole: param.accountSysRole || '9999',
            optionsMethod: param.optionsMethod || '',
            body: JSON.stringify(param.params || {}),
        }
        //打印请求地址
        console.warn('======================发起请求==========================')
        console.warn('请求地址')
        console.log(param.url)
        //打印请求参数
        console.warn('请求参数')
        console.log(requestData)

        return new Promise((resolve, reject) => {
            this._http.post(param.url, JSON.stringify(requestData), options)
                .map(res => res.json())
                .subscribe(
                //请求成功
                res => {
                    //打印响应数据
                    console.warn('响应数据')
                    console.log(res)
                    //关闭加载提示符
                    if (!event && !skipDismissLoading) {
                        this.connectService.getData('loading').dismiss();
                    }
                    //统一处理请求结果
                    if (typeof (res) == "undefined" || res === null || typeof (res.data) == "undefined" || res.data === null) {
                        reject('请求数据异常')
                    } else {
                        if (res.code == 2000) {  //2000请求成功
                            resolve(res.data)
                        } else if (res.code == 4000 || res.code == 4001) {  //4000请求失败 4001登录超时
                            reject(res.message)
                        }
                    }
                },
                //请求失败
                err => {
                    //关闭加载提示符
                    this.connectService.getData('loading').dismiss();
                    reject('服务器错误！')
                })
        })
    }

    /**
     * @description 请求出错，弹出警告窗口
     * @param {string} err 错误信息
     * @memberOf HttpService
     * @author xjn
     * @date 2017年3月24日
     */
    public handleErr(err: string) {
        console.log(err);
        if (typeof (err) == "undefined" || err === null) {
            err = '请求数据异常';
        }
        this.toolService.showAlert(err)
        if (err == '登录超时') {
            // logout()
        }
    }
}
