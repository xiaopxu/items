import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { LoadingController } from 'ionic-angular';

/**
 * @description 全局通信及变量存取服务
 * @export
 * @class ConnectService
 * @author: xjn
 * @date: 2017年3月9日
 */
@Injectable()
export class ConnectService {

    /**
     * @description: 存放全局变量的对象
     * @type {*}
     * @memberOf ConnectService
     * @author: xjn
     * @date: 2017年3月9日
     */
    public commonData: any = {
        orderDateExist: [],
        displayOrders: [],
        storeExist: [],
        displayClerks: [],
        timeIntervalArray: [],
        loginStatus: {
            usserSession: ''
        }
    }

    constructor(
        private loadingCtrl: LoadingController
    ) { }

    /**
     * @tescription: 保存全局变量的方法
     * @param {string} key  存入的key值
     * @param {*} val  存入的数据
     * @returns {void}
     * @memberOf ConnectService
     * @author: xjn
     * @date: 2017年3月9日
     */
    public saveData(key: string, val: any): void {
        this.commonData[key] = val;
    }

    /**
     * @description: 获取全局变量的方法
     * @param {string} key  获取的key值
     * @returns {*}
     * @memberOf ConnectService
     * @author: xjn
     * @date: 2017年3月9日
     */
    public getData(key: string): any {
        return this.commonData[key];
    }

}
