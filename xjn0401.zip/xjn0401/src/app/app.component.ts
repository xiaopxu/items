import { Component, ViewChild } from '@angular/core';
import { Platform, ToastController, IonicApp, Nav } from 'ionic-angular';
import { StatusBar, Splashscreen } from 'ionic-native';
import { LoginPage } from '../pages/common-pages/login/login';

@Component({
    templateUrl: 'app.html'
})
export class MyApp {
    //指定根组件
    rootPage = LoginPage
    //判断返回键是否触发
    backButtonPressed: boolean = false;
    @ViewChild('myNav') nav: Nav;

    constructor(
        public platform: Platform,
        public ionicApp: IonicApp,
        public toastCtrl: ToastController
    ) {
        //初始化根组件
        this.rootPage = LoginPage

        platform.ready().then(() => {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            StatusBar.styleDefault();
            Splashscreen.hide();
            platform.registerBackButtonAction((): any => {  //注册返回按键事件
                // if(this.nav.getActive().name == 'LoginPage' || this.nav.getActive().name == 'ShopAssistantTabsPage'){
                //   this.showExit();
                // }
                let activeVC = this.nav.getActive();
                console.log(this.nav)
                console.log(activeVC)
                //  if(activeVC.name == 'LoginPage'){
                //    console.log(activeVC)
                //     if(!activeVC.enableBack()){
                //       this.showExit()
                //     }
                //  }else{
                //    let tabs = activeVC.instance.tabs;
                //    let activeNav = tabs.getSelected();
                //    console.log(activeVC)
                //    console.log(tabs)
                //    console.log(activeNav)
                //  }

                //  activeNav.canGoBack() ? activeNav.pop() : this.showExit()
            }, 101);
        });
    }

    //双击退出提示框，这里使用Ionic2的ToastController
    showExit() {
        if (this.backButtonPressed) this.platform.exitApp();  //当触发标志为true时，即2秒内双击返回按键则退出APP
        else {
            console.log(5)
            let toast = this.toastCtrl.create({
                message: '再按一次退出应用',
                duration: 2000,
                position: 'bottom'
            });
            toast.present();
            this.backButtonPressed = true;
            //2秒内没有再次点击返回则将触发标志标记为false
            setTimeout(() => {
                this.backButtonPressed = false;
            }, 2000)
        }
    }
}
